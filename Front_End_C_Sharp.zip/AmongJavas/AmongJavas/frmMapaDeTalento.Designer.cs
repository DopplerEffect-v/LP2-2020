﻿namespace AmongJavas
{
    partial class frmMapaDeTalento
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panelIndi = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.btnCalibracion = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnAtras = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnCerrar = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnCerrarSesion = new System.Windows.Forms.LinkLabel();
            this.txtArea = new System.Windows.Forms.TextBox();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.txtCorreo = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.btnCuadranteCalto = new System.Windows.Forms.Button();
            this.panel12 = new System.Windows.Forms.Panel();
            this.btnCuadranteBalto = new System.Windows.Forms.Button();
            this.panel11 = new System.Windows.Forms.Panel();
            this.btnCuadranteAalto = new System.Windows.Forms.Button();
            this.panel10 = new System.Windows.Forms.Panel();
            this.btnCuadranteAmedio = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.btnCuadranteBmedio = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.btnCuadranteCmedio = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.btnCuadranteCbajo = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.btnCuadranteBbajo = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnCuadranteAbajo = new System.Windows.Forms.Button();
            this.cboArea = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.dgvColaboradores = new System.Windows.Forms.DataGridView();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nombre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnCalibrar = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.txtEjeY = new System.Windows.Forms.TextBox();
            this.txtEjeX = new System.Windows.Forms.TextBox();
            this.lblMotivo = new System.Windows.Forms.Label();
            this.txtMotivo = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.panel3.SuspendLayout();
            this.panelIndi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnAtras)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel13.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvColaboradores)).BeginInit();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(119)))), ((int)(((byte)(205)))));
            this.panel3.Controls.Add(this.panelIndi);
            this.panel3.Controls.Add(this.pictureBox7);
            this.panel3.Controls.Add(this.btnCalibracion);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 182);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(249, 534);
            this.panel3.TabIndex = 25;
            // 
            // panelIndi
            // 
            this.panelIndi.BackColor = System.Drawing.Color.Cornsilk;
            this.panelIndi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelIndi.Controls.Add(this.label20);
            this.panelIndi.Controls.Add(this.label19);
            this.panelIndi.Controls.Add(this.label18);
            this.panelIndi.Controls.Add(this.label12);
            this.panelIndi.Controls.Add(this.label13);
            this.panelIndi.Controls.Add(this.label16);
            this.panelIndi.Controls.Add(this.label17);
            this.panelIndi.Location = new System.Drawing.Point(24, 109);
            this.panelIndi.Name = "panelIndi";
            this.panelIndi.Size = new System.Drawing.Size(202, 394);
            this.panelIndi.TabIndex = 72;
            // 
            // label19
            // 
            this.label19.Dock = System.Windows.Forms.DockStyle.Top;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(0, 239);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(200, 53);
            this.label19.TabIndex = 5;
            this.label19.Text = "5. Ingrese un motivo(opcional)";
            // 
            // label18
            // 
            this.label18.Dock = System.Windows.Forms.DockStyle.Top;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(0, 185);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(200, 54);
            this.label18.TabIndex = 4;
            this.label18.Text = "4. Presionar el botón Calibrar";
            // 
            // label12
            // 
            this.label12.Dock = System.Windows.Forms.DockStyle.Top;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(0, 131);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(200, 54);
            this.label12.TabIndex = 3;
            this.label12.Text = "3. Seleccionar un colaborador";
            // 
            // label13
            // 
            this.label13.Dock = System.Windows.Forms.DockStyle.Top;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(0, 73);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(200, 58);
            this.label13.TabIndex = 2;
            this.label13.Text = "2. Seleccionar un cuadrante";
            // 
            // label16
            // 
            this.label16.Dock = System.Windows.Forms.DockStyle.Top;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(0, 37);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(200, 36);
            this.label16.TabIndex = 1;
            this.label16.Text = "1. Seleccionar un área";
            // 
            // label17
            // 
            this.label17.Dock = System.Windows.Forms.DockStyle.Top;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(0, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(200, 37);
            this.label17.TabIndex = 0;
            this.label17.Text = "Indicaciones:";
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.pictureBox7.Image = global::AmongJavas.Properties.Resources.IconoCalibracion;
            this.pictureBox7.Location = new System.Drawing.Point(4, 33);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(49, 55);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 12;
            this.pictureBox7.TabStop = false;
            // 
            // btnCalibracion
            // 
            this.btnCalibracion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.btnCalibracion.FlatAppearance.BorderSize = 0;
            this.btnCalibracion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalibracion.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalibracion.ForeColor = System.Drawing.Color.White;
            this.btnCalibracion.Location = new System.Drawing.Point(0, 27);
            this.btnCalibracion.Name = "btnCalibracion";
            this.btnCalibracion.Size = new System.Drawing.Size(249, 66);
            this.btnCalibracion.TabIndex = 6;
            this.btnCalibracion.Text = "       Calibración";
            this.btnCalibracion.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(119)))), ((int)(((byte)(205)))));
            this.panel1.Controls.Add(this.btnAtras);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.lblTitulo);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1253, 182);
            this.panel1.TabIndex = 24;
            // 
            // btnAtras
            // 
            this.btnAtras.Image = global::AmongJavas.Properties.Resources.IconoAtras2;
            this.btnAtras.Location = new System.Drawing.Point(10, 38);
            this.btnAtras.Name = "btnAtras";
            this.btnAtras.Size = new System.Drawing.Size(53, 53);
            this.btnAtras.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnAtras.TabIndex = 9;
            this.btnAtras.TabStop = false;
            this.btnAtras.Click += new System.EventHandler(this.btnAtras_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.panel4.Controls.Add(this.btnCerrar);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1253, 33);
            this.panel4.TabIndex = 4;
            // 
            // btnCerrar
            // 
            this.btnCerrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.btnCerrar.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnCerrar.FlatAppearance.BorderSize = 0;
            this.btnCerrar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCerrar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCerrar.ForeColor = System.Drawing.Color.Silver;
            this.btnCerrar.Image = global::AmongJavas.Properties.Resources.Close_Icon;
            this.btnCerrar.Location = new System.Drawing.Point(1221, 0);
            this.btnCerrar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnCerrar.Name = "btnCerrar";
            this.btnCerrar.Size = new System.Drawing.Size(32, 33);
            this.btnCerrar.TabIndex = 59;
            this.btnCerrar.UseVisualStyleBackColor = false;
            this.btnCerrar.Click += new System.EventHandler(this.btnCerrar_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(119)))), ((int)(((byte)(205)))));
            this.panel2.Controls.Add(this.btnCerrarSesion);
            this.panel2.Controls.Add(this.txtArea);
            this.panel2.Controls.Add(this.txtNombre);
            this.panel2.Controls.Add(this.txtCorreo);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Location = new System.Drawing.Point(886, 29);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(365, 153);
            this.panel2.TabIndex = 1;
            // 
            // btnCerrarSesion
            // 
            this.btnCerrarSesion.AutoSize = true;
            this.btnCerrarSesion.LinkColor = System.Drawing.Color.White;
            this.btnCerrarSesion.Location = new System.Drawing.Point(235, 123);
            this.btnCerrarSesion.Name = "btnCerrarSesion";
            this.btnCerrarSesion.Size = new System.Drawing.Size(106, 20);
            this.btnCerrarSesion.TabIndex = 7;
            this.btnCerrarSesion.TabStop = true;
            this.btnCerrarSesion.Text = "Cerrar Sesion";
            this.btnCerrarSesion.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.btnCerrarSesion_LinkClicked);
            // 
            // txtArea
            // 
            this.txtArea.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.txtArea.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtArea.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtArea.Location = new System.Drawing.Point(137, 88);
            this.txtArea.Name = "txtArea";
            this.txtArea.Size = new System.Drawing.Size(204, 27);
            this.txtArea.TabIndex = 5;
            // 
            // txtNombre
            // 
            this.txtNombre.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.txtNombre.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNombre.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNombre.Location = new System.Drawing.Point(137, 16);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(204, 27);
            this.txtNombre.TabIndex = 4;
            // 
            // txtCorreo
            // 
            this.txtCorreo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.txtCorreo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCorreo.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCorreo.Location = new System.Drawing.Point(137, 52);
            this.txtCorreo.Name = "txtCorreo";
            this.txtCorreo.Size = new System.Drawing.Size(204, 27);
            this.txtCorreo.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(62, 88);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 21);
            this.label4.TabIndex = 3;
            this.label4.Text = "Area:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(62, 52);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 21);
            this.label3.TabIndex = 2;
            this.label3.Text = "Correo:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(62, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 21);
            this.label1.TabIndex = 1;
            this.label1.Text = "Nombre:";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::AmongJavas.Properties.Resources.IconoUsuario;
            this.pictureBox2.Location = new System.Drawing.Point(3, 32);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(53, 55);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::AmongJavas.Properties.Resources.IconoMenu;
            this.pictureBox1.Location = new System.Drawing.Point(4, 102);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(49, 55);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Century Gothic", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.Color.White;
            this.lblTitulo.Location = new System.Drawing.Point(59, 106);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(616, 47);
            this.lblTitulo.TabIndex = 1;
            this.lblTitulo.Text = "Calibración - Mapa de Talento";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.DimGray;
            this.label9.Location = new System.Drawing.Point(721, 548);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(26, 23);
            this.label9.TabIndex = 76;
            this.label9.Text = "C";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.DimGray;
            this.label8.Location = new System.Drawing.Point(721, 406);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(22, 23);
            this.label8.TabIndex = 75;
            this.label8.Text = "B";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.DimGray;
            this.label7.Location = new System.Drawing.Point(721, 267);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(25, 23);
            this.label7.TabIndex = 74;
            this.label7.Text = "A";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DimGray;
            this.label6.Location = new System.Drawing.Point(1131, 643);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 23);
            this.label6.TabIndex = 73;
            this.label6.Text = "Alto";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DimGray;
            this.label5.Location = new System.Drawing.Point(963, 643);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 23);
            this.label5.TabIndex = 72;
            this.label5.Text = "Medio";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DimGray;
            this.label2.Location = new System.Drawing.Point(814, 643);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 23);
            this.label2.TabIndex = 71;
            this.label2.Text = "Bajo";
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.Lime;
            this.panel13.Controls.Add(this.btnCuadranteCalto);
            this.panel13.Location = new System.Drawing.Point(1102, 513);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(107, 100);
            this.panel13.TabIndex = 70;
            // 
            // btnCuadranteCalto
            // 
            this.btnCuadranteCalto.FlatAppearance.BorderSize = 0;
            this.btnCuadranteCalto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCuadranteCalto.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCuadranteCalto.Location = new System.Drawing.Point(3, 3);
            this.btnCuadranteCalto.Name = "btnCuadranteCalto";
            this.btnCuadranteCalto.Size = new System.Drawing.Size(101, 94);
            this.btnCuadranteCalto.TabIndex = 85;
            this.btnCuadranteCalto.Text = "9";
            this.btnCuadranteCalto.UseVisualStyleBackColor = true;
            this.btnCuadranteCalto.Click += new System.EventHandler(this.btnCuadranteCalto_Click);
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.Yellow;
            this.panel12.Controls.Add(this.btnCuadranteBalto);
            this.panel12.Location = new System.Drawing.Point(1102, 372);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(107, 100);
            this.panel12.TabIndex = 69;
            // 
            // btnCuadranteBalto
            // 
            this.btnCuadranteBalto.FlatAppearance.BorderSize = 0;
            this.btnCuadranteBalto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCuadranteBalto.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCuadranteBalto.Location = new System.Drawing.Point(3, 3);
            this.btnCuadranteBalto.Name = "btnCuadranteBalto";
            this.btnCuadranteBalto.Size = new System.Drawing.Size(101, 94);
            this.btnCuadranteBalto.TabIndex = 84;
            this.btnCuadranteBalto.Text = "6";
            this.btnCuadranteBalto.UseVisualStyleBackColor = true;
            this.btnCuadranteBalto.Click += new System.EventHandler(this.btnCuadranteBalto_Click);
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.Yellow;
            this.panel11.Controls.Add(this.btnCuadranteAalto);
            this.panel11.Location = new System.Drawing.Point(1102, 227);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(107, 100);
            this.panel11.TabIndex = 68;
            // 
            // btnCuadranteAalto
            // 
            this.btnCuadranteAalto.FlatAppearance.BorderSize = 0;
            this.btnCuadranteAalto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCuadranteAalto.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCuadranteAalto.Location = new System.Drawing.Point(3, 5);
            this.btnCuadranteAalto.Name = "btnCuadranteAalto";
            this.btnCuadranteAalto.Size = new System.Drawing.Size(101, 94);
            this.btnCuadranteAalto.TabIndex = 81;
            this.btnCuadranteAalto.Text = "3";
            this.btnCuadranteAalto.UseVisualStyleBackColor = true;
            this.btnCuadranteAalto.Click += new System.EventHandler(this.btnCuadranteAalto_Click);
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.Yellow;
            this.panel10.Controls.Add(this.btnCuadranteAmedio);
            this.panel10.Location = new System.Drawing.Point(946, 227);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(107, 100);
            this.panel10.TabIndex = 67;
            // 
            // btnCuadranteAmedio
            // 
            this.btnCuadranteAmedio.FlatAppearance.BorderSize = 0;
            this.btnCuadranteAmedio.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCuadranteAmedio.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCuadranteAmedio.Location = new System.Drawing.Point(3, 3);
            this.btnCuadranteAmedio.Name = "btnCuadranteAmedio";
            this.btnCuadranteAmedio.Size = new System.Drawing.Size(101, 94);
            this.btnCuadranteAmedio.TabIndex = 80;
            this.btnCuadranteAmedio.Text = "2";
            this.btnCuadranteAmedio.UseVisualStyleBackColor = true;
            this.btnCuadranteAmedio.Click += new System.EventHandler(this.btnCuadranteAmedio_Click);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.Lime;
            this.panel9.Controls.Add(this.btnCuadranteBmedio);
            this.panel9.Location = new System.Drawing.Point(946, 372);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(107, 100);
            this.panel9.TabIndex = 66;
            // 
            // btnCuadranteBmedio
            // 
            this.btnCuadranteBmedio.FlatAppearance.BorderSize = 0;
            this.btnCuadranteBmedio.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCuadranteBmedio.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCuadranteBmedio.Location = new System.Drawing.Point(3, 3);
            this.btnCuadranteBmedio.Name = "btnCuadranteBmedio";
            this.btnCuadranteBmedio.Size = new System.Drawing.Size(101, 94);
            this.btnCuadranteBmedio.TabIndex = 83;
            this.btnCuadranteBmedio.Text = "5";
            this.btnCuadranteBmedio.UseVisualStyleBackColor = true;
            this.btnCuadranteBmedio.Click += new System.EventHandler(this.btnCuadranteBmedio_Click);
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panel8.Controls.Add(this.btnCuadranteCmedio);
            this.panel8.Location = new System.Drawing.Point(946, 513);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(107, 100);
            this.panel8.TabIndex = 65;
            // 
            // btnCuadranteCmedio
            // 
            this.btnCuadranteCmedio.FlatAppearance.BorderSize = 0;
            this.btnCuadranteCmedio.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCuadranteCmedio.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCuadranteCmedio.Location = new System.Drawing.Point(3, 3);
            this.btnCuadranteCmedio.Name = "btnCuadranteCmedio";
            this.btnCuadranteCmedio.Size = new System.Drawing.Size(101, 94);
            this.btnCuadranteCmedio.TabIndex = 86;
            this.btnCuadranteCmedio.Text = "8";
            this.btnCuadranteCmedio.UseVisualStyleBackColor = true;
            this.btnCuadranteCmedio.Click += new System.EventHandler(this.btnCuadranteCmedio_Click);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panel7.Controls.Add(this.btnCuadranteCbajo);
            this.panel7.Location = new System.Drawing.Point(788, 513);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(107, 100);
            this.panel7.TabIndex = 63;
            // 
            // btnCuadranteCbajo
            // 
            this.btnCuadranteCbajo.FlatAppearance.BorderSize = 0;
            this.btnCuadranteCbajo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCuadranteCbajo.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCuadranteCbajo.Location = new System.Drawing.Point(3, 3);
            this.btnCuadranteCbajo.Name = "btnCuadranteCbajo";
            this.btnCuadranteCbajo.Size = new System.Drawing.Size(101, 94);
            this.btnCuadranteCbajo.TabIndex = 87;
            this.btnCuadranteCbajo.Text = "7";
            this.btnCuadranteCbajo.UseVisualStyleBackColor = true;
            this.btnCuadranteCbajo.Click += new System.EventHandler(this.btnCuadranteCbajo_Click);
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.panel6.Controls.Add(this.btnCuadranteBbajo);
            this.panel6.Location = new System.Drawing.Point(788, 372);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(107, 100);
            this.panel6.TabIndex = 64;
            // 
            // btnCuadranteBbajo
            // 
            this.btnCuadranteBbajo.FlatAppearance.BorderSize = 0;
            this.btnCuadranteBbajo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCuadranteBbajo.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCuadranteBbajo.Location = new System.Drawing.Point(3, 3);
            this.btnCuadranteBbajo.Name = "btnCuadranteBbajo";
            this.btnCuadranteBbajo.Size = new System.Drawing.Size(101, 94);
            this.btnCuadranteBbajo.TabIndex = 82;
            this.btnCuadranteBbajo.Text = "4";
            this.btnCuadranteBbajo.UseVisualStyleBackColor = true;
            this.btnCuadranteBbajo.Click += new System.EventHandler(this.btnCuadranteBbajo_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Lime;
            this.panel5.Controls.Add(this.btnCuadranteAbajo);
            this.panel5.Location = new System.Drawing.Point(788, 227);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(107, 100);
            this.panel5.TabIndex = 62;
            // 
            // btnCuadranteAbajo
            // 
            this.btnCuadranteAbajo.FlatAppearance.BorderSize = 0;
            this.btnCuadranteAbajo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCuadranteAbajo.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCuadranteAbajo.Location = new System.Drawing.Point(3, 3);
            this.btnCuadranteAbajo.Name = "btnCuadranteAbajo";
            this.btnCuadranteAbajo.Size = new System.Drawing.Size(101, 94);
            this.btnCuadranteAbajo.TabIndex = 79;
            this.btnCuadranteAbajo.Text = "1";
            this.btnCuadranteAbajo.UseVisualStyleBackColor = true;
            this.btnCuadranteAbajo.Click += new System.EventHandler(this.btnCuadranteAbajo_Click);
            // 
            // cboArea
            // 
            this.cboArea.FormattingEnabled = true;
            this.cboArea.Location = new System.Drawing.Point(357, 198);
            this.cboArea.Name = "cboArea";
            this.cboArea.Size = new System.Drawing.Size(300, 28);
            this.cboArea.TabIndex = 77;
            this.cboArea.SelectedIndexChanged += new System.EventHandler(this.cboArea_SelectedIndexChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.label10.ForeColor = System.Drawing.Color.DimGray;
            this.label10.Location = new System.Drawing.Point(274, 198);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(76, 28);
            this.label10.TabIndex = 78;
            this.label10.Text = "Area:";
            // 
            // dgvColaboradores
            // 
            this.dgvColaboradores.AllowUserToAddRows = false;
            this.dgvColaboradores.AllowUserToDeleteRows = false;
            this.dgvColaboradores.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.Padding = new System.Windows.Forms.Padding(0, 5, 0, 5);
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvColaboradores.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvColaboradores.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvColaboradores.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID,
            this.Nombre});
            this.dgvColaboradores.EnableHeadersVisualStyles = false;
            this.dgvColaboradores.Location = new System.Drawing.Point(269, 286);
            this.dgvColaboradores.MultiSelect = false;
            this.dgvColaboradores.Name = "dgvColaboradores";
            this.dgvColaboradores.ReadOnly = true;
            this.dgvColaboradores.RowHeadersWidth = 62;
            this.dgvColaboradores.RowTemplate.Height = 28;
            this.dgvColaboradores.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvColaboradores.Size = new System.Drawing.Size(420, 245);
            this.dgvColaboradores.TabIndex = 79;
            this.dgvColaboradores.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvColaboradores_CellClick);
            // 
            // ID
            // 
            this.ID.DataPropertyName = "idColaborador";
            this.ID.HeaderText = "ID";
            this.ID.MinimumWidth = 8;
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            this.ID.Width = 50;
            // 
            // Nombre
            // 
            this.Nombre.DataPropertyName = "nombreColaborador";
            this.Nombre.HeaderText = "Nombre";
            this.Nombre.MinimumWidth = 8;
            this.Nombre.Name = "Nombre";
            this.Nombre.ReadOnly = true;
            this.Nombre.Width = 150;
            // 
            // btnCancelar
            // 
            this.btnCancelar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.btnCancelar.FlatAppearance.BorderSize = 0;
            this.btnCancelar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCancelar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelar.ForeColor = System.Drawing.Color.White;
            this.btnCancelar.Location = new System.Drawing.Point(506, 549);
            this.btnCancelar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(135, 35);
            this.btnCancelar.TabIndex = 80;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = false;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // btnCalibrar
            // 
            this.btnCalibrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.btnCalibrar.FlatAppearance.BorderSize = 0;
            this.btnCalibrar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCalibrar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalibrar.ForeColor = System.Drawing.Color.White;
            this.btnCalibrar.Location = new System.Drawing.Point(337, 549);
            this.btnCalibrar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnCalibrar.Name = "btnCalibrar";
            this.btnCalibrar.Size = new System.Drawing.Size(135, 35);
            this.btnCalibrar.TabIndex = 81;
            this.btnCalibrar.Text = "Calibrar";
            this.btnCalibrar.UseVisualStyleBackColor = false;
            this.btnCalibrar.Click += new System.EventHandler(this.btnCalibrar_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.DimGray;
            this.label14.Location = new System.Drawing.Point(1126, 684);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(101, 23);
            this.label14.TabIndex = 123;
            this.label14.Text = "Potencial";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.DimGray;
            this.label15.Location = new System.Drawing.Point(700, 191);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(129, 23);
            this.label15.TabIndex = 124;
            this.label15.Text = "Desempeño";
            // 
            // panel15
            // 
            this.panel15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel15.Location = new System.Drawing.Point(766, 220);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(2, 420);
            this.panel15.TabIndex = 122;
            // 
            // panel14
            // 
            this.panel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel14.Location = new System.Drawing.Point(756, 630);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(480, 2);
            this.panel14.TabIndex = 121;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.label11.ForeColor = System.Drawing.Color.DimGray;
            this.label11.Location = new System.Drawing.Point(270, 239);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(144, 28);
            this.label11.TabIndex = 125;
            this.label11.Text = "Cuadrante:";
            // 
            // txtEjeY
            // 
            this.txtEjeY.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.txtEjeY.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtEjeY.Enabled = false;
            this.txtEjeY.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEjeY.Location = new System.Drawing.Point(431, 239);
            this.txtEjeY.Name = "txtEjeY";
            this.txtEjeY.Size = new System.Drawing.Size(100, 32);
            this.txtEjeY.TabIndex = 8;
            this.txtEjeY.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtEjeX
            // 
            this.txtEjeX.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.txtEjeX.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtEjeX.Enabled = false;
            this.txtEjeX.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEjeX.Location = new System.Drawing.Point(557, 238);
            this.txtEjeX.Name = "txtEjeX";
            this.txtEjeX.Size = new System.Drawing.Size(100, 32);
            this.txtEjeX.TabIndex = 126;
            this.txtEjeX.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblMotivo
            // 
            this.lblMotivo.AutoSize = true;
            this.lblMotivo.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.lblMotivo.ForeColor = System.Drawing.Color.DimGray;
            this.lblMotivo.Location = new System.Drawing.Point(270, 597);
            this.lblMotivo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMotivo.Name = "lblMotivo";
            this.lblMotivo.Size = new System.Drawing.Size(97, 28);
            this.lblMotivo.TabIndex = 127;
            this.lblMotivo.Text = "Motivo:";
            // 
            // txtMotivo
            // 
            this.txtMotivo.Location = new System.Drawing.Point(269, 630);
            this.txtMotivo.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtMotivo.MaxLength = 500;
            this.txtMotivo.Multiline = true;
            this.txtMotivo.Name = "txtMotivo";
            this.txtMotivo.Size = new System.Drawing.Size(420, 72);
            this.txtMotivo.TabIndex = 128;
            // 
            // label20
            // 
            this.label20.Dock = System.Windows.Forms.DockStyle.Top;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(0, 292);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(200, 94);
            this.label20.TabIndex = 6;
            this.label20.Text = "6. Seleccionar el cuadrante al que se moverá el colaborador";
            // 
            // frmMapaDeTalento
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.ClientSize = new System.Drawing.Size(1253, 716);
            this.Controls.Add(this.txtMotivo);
            this.Controls.Add(this.lblMotivo);
            this.Controls.Add(this.txtEjeX);
            this.Controls.Add(this.txtEjeY);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.panel15);
            this.Controls.Add(this.panel14);
            this.Controls.Add(this.btnCalibrar);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.dgvColaboradores);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.cboArea);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.panel12);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.panel13);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.panel9);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.panel10);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmMapaDeTalento";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmMapaDeTalento";
            this.panel3.ResumeLayout(false);
            this.panelIndi.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnAtras)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel13.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvColaboradores)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Button btnCalibracion;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.LinkLabel btnCerrarSesion;
        private System.Windows.Forms.TextBox txtArea;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.TextBox txtCorreo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.PictureBox btnAtras;
        private System.Windows.Forms.ComboBox cboArea;
        private System.Windows.Forms.Button btnCuadranteCalto;
        private System.Windows.Forms.Button btnCuadranteBalto;
        private System.Windows.Forms.Button btnCuadranteAalto;
        private System.Windows.Forms.Button btnCuadranteAmedio;
        private System.Windows.Forms.Button btnCuadranteBmedio;
        private System.Windows.Forms.Button btnCuadranteCmedio;
        private System.Windows.Forms.Button btnCuadranteCbajo;
        private System.Windows.Forms.Button btnCuadranteBbajo;
        private System.Windows.Forms.Button btnCuadranteAbajo;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DataGridView dgvColaboradores;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnCalibrar;
        private System.Windows.Forms.Button btnCerrar;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtEjeY;
        private System.Windows.Forms.TextBox txtEjeX;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nombre;
        private System.Windows.Forms.Panel panelIndi;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lblMotivo;
        private System.Windows.Forms.TextBox txtMotivo;
        private System.Windows.Forms.Label label20;
    }
}