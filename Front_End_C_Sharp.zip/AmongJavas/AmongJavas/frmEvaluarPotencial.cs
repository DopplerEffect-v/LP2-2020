﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AmongJavas
{
    public partial class frmEvaluarPotencial : Form
    {
        private NotaCriterioWS.notaCriterio notaCriterio;
        private NotaCriterioWS.NotaCriterioWSClient daoNotaCriterio;
        NotaCriterioWS.notaSubCriterio notaSubCriterioSeleccionada;
        BindingList<NotaCriterioWS.notaSubCriterio> lista;
        public frmEvaluarPotencial(NotaCriterioWS.notaCriterio notaCriterio,String colaborador)
        {
            InitializeComponent();

            txtId.Text = notaCriterio.linea_criterio.criterio.id_criterio.ToString();
            txtNombre.Text = notaCriterio.linea_criterio.criterio.nombre;
            txtDescripcion.Text = notaCriterio.linea_criterio.criterio.descripcion;
            txtColaborador.Text = colaborador;
            this.notaCriterio = notaCriterio;
            daoNotaCriterio = new NotaCriterioWS.NotaCriterioWSClient();
            //Llenar dataGridView
            if (notaCriterio.notasSubcriterios != null)
            {
                lista = new BindingList<NotaCriterioWS.notaSubCriterio>(notaCriterio.notasSubcriterios);
                dgvCompetencias.AutoGenerateColumns = false;
                dgvCompetencias.DataSource = new BindingList<NotaCriterioWS.notaSubCriterio>(lista);
            }
            deshabilitaEtapa();
        }
        public void deshabilitaEtapa()
        {
            if (Program.cronograma.etapa != 1) //Si no es Evaluacion Etapa
            {
                btnGuardar.Visible = false;
                btnCancelar.Visible = false;
                dgvCompetencias.Columns[1].ReadOnly = true;
                panelIndi.Visible = false;
            }
        }
        private void btnCerrar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            double total = 0;
            double pesoTotal = 0;

            if (MessageBox.Show("¿Desea guardar las notas de los subpotenciales?", "Mensaje de confirmación", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                foreach (NotaCriterioWS.notaSubCriterio subnota in lista)
                {
                    total += subnota.notaEvaluador * subnota.subcriterio.peso;
                    pesoTotal += subnota.subcriterio.peso;
                }
                if (pesoTotal != 0)
                    notaCriterio.notaEvaluador = total / pesoTotal;
                else
                    notaCriterio.notaEvaluador = 0;
                daoNotaCriterio.actualizarNotasCriterio(notaCriterio);
                MessageBox.Show("Notas registradas", "Confirmación", MessageBoxButtons.OK);
                this.DialogResult = DialogResult.OK;
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

        private void btnVer_Click(object sender, EventArgs e)
        {
            notaSubCriterioSeleccionada = (NotaCriterioWS.notaSubCriterio)dgvCompetencias.CurrentRow.DataBoundItem;
            frmOscuro pp = new frmOscuro();
            pp.SetBounds(0, 0, this.Width, this.Height);
            pp.Show();
            frmGestionarSubpotencial panelDetalle = new frmGestionarSubpotencial(notaSubCriterioSeleccionada);
            panelDetalle.ShowDialog();
            pp.Close(); 
        }

        private void btnAtras_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }
}
