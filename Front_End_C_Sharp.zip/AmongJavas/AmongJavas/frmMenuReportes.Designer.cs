﻿namespace AmongJavas
{
    partial class frmMenuReportes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.txtPeriodo = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtEtapa = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.btnOjetivos = new System.Windows.Forms.Button();
            this.btnReportes = new System.Windows.Forms.Button();
            this.btnCalibracion = new System.Windows.Forms.Button();
            this.btnEvaluacion = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.btnPlanificacion = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnCerrar = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnCerrarSesion = new System.Windows.Forms.LinkLabel();
            this.txtArea = new System.Windows.Forms.TextBox();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.txtCorreo = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.panelMi = new System.Windows.Forms.Panel();
            this.btnGenerarMiPDI = new System.Windows.Forms.Button();
            this.btnGenerarMiRI = new System.Windows.Forms.Button();
            this.btnVerMiPDI = new System.Windows.Forms.Button();
            this.dgvMisPeriodos = new System.Windows.Forms.DataGridView();
            this.Periodo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panelRe = new System.Windows.Forms.Panel();
            this.btnGenerarRS = new System.Windows.Forms.Button();
            this.dgvResumen = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.sfdReporte = new System.Windows.Forms.SaveFileDialog();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label8 = new System.Windows.Forms.Label();
            this.cbEmpleados = new System.Windows.Forms.ComboBox();
            this.panelEv = new System.Windows.Forms.Panel();
            this.btnGenerarEvRI = new System.Windows.Forms.Button();
            this.dgvEvPeriodos = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnGenerarEvPDI = new System.Windows.Forms.Button();
            this.panel12 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.btnVerEvPDI = new System.Windows.Forms.Button();
            this.panelSolo = new System.Windows.Forms.Panel();
            this.panel3.SuspendLayout();
            this.panel17.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panelMi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMisPeriodos)).BeginInit();
            this.panel9.SuspendLayout();
            this.panelRe.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResumen)).BeginInit();
            this.panel7.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panelEv.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvEvPeriodos)).BeginInit();
            this.panel12.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(119)))), ((int)(((byte)(205)))));
            this.panel3.Controls.Add(this.panel17);
            this.panel3.Controls.Add(this.pictureBox7);
            this.panel3.Controls.Add(this.pictureBox6);
            this.panel3.Controls.Add(this.pictureBox5);
            this.panel3.Controls.Add(this.pictureBox4);
            this.panel3.Controls.Add(this.btnOjetivos);
            this.panel3.Controls.Add(this.btnReportes);
            this.panel3.Controls.Add(this.btnCalibracion);
            this.panel3.Controls.Add(this.btnEvaluacion);
            this.panel3.Controls.Add(this.pictureBox3);
            this.panel3.Controls.Add(this.btnPlanificacion);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 182);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(249, 519);
            this.panel3.TabIndex = 18;
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.txtPeriodo);
            this.panel17.Controls.Add(this.label7);
            this.panel17.Controls.Add(this.txtEtapa);
            this.panel17.Controls.Add(this.label9);
            this.panel17.Location = new System.Drawing.Point(11, 414);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(228, 95);
            this.panel17.TabIndex = 25;
            // 
            // txtPeriodo
            // 
            this.txtPeriodo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.txtPeriodo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPeriodo.Enabled = false;
            this.txtPeriodo.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPeriodo.Location = new System.Drawing.Point(83, 14);
            this.txtPeriodo.Name = "txtPeriodo";
            this.txtPeriodo.Size = new System.Drawing.Size(133, 27);
            this.txtPeriodo.TabIndex = 11;
            this.txtPeriodo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(5, 16);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 19);
            this.label7.TabIndex = 12;
            this.label7.Text = "Periodo:";
            // 
            // txtEtapa
            // 
            this.txtEtapa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.txtEtapa.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtEtapa.Enabled = false;
            this.txtEtapa.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEtapa.Location = new System.Drawing.Point(83, 52);
            this.txtEtapa.Name = "txtEtapa";
            this.txtEtapa.Size = new System.Drawing.Size(133, 27);
            this.txtEtapa.TabIndex = 8;
            this.txtEtapa.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(5, 54);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(58, 19);
            this.label9.TabIndex = 8;
            this.label9.Text = "Etapa:";
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::AmongJavas.Properties.Resources.IconoCalibracion;
            this.pictureBox7.Location = new System.Drawing.Point(12, 253);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(49, 55);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 12;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(32)))), ((int)(((byte)(40)))));
            this.pictureBox6.Image = global::AmongJavas.Properties.Resources.IconoReporte;
            this.pictureBox6.Location = new System.Drawing.Point(12, 330);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(49, 55);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 11;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::AmongJavas.Properties.Resources.IconoObjetivo;
            this.pictureBox5.Location = new System.Drawing.Point(12, 104);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(49, 55);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 10;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::AmongJavas.Properties.Resources.IconoReportes;
            this.pictureBox4.Location = new System.Drawing.Point(12, 180);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(49, 55);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 9;
            this.pictureBox4.TabStop = false;
            // 
            // btnOjetivos
            // 
            this.btnOjetivos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(119)))), ((int)(((byte)(205)))));
            this.btnOjetivos.FlatAppearance.BorderSize = 0;
            this.btnOjetivos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOjetivos.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOjetivos.ForeColor = System.Drawing.Color.White;
            this.btnOjetivos.Location = new System.Drawing.Point(0, 104);
            this.btnOjetivos.Name = "btnOjetivos";
            this.btnOjetivos.Size = new System.Drawing.Size(245, 55);
            this.btnOjetivos.TabIndex = 8;
            this.btnOjetivos.Text = "         Objetivos";
            this.btnOjetivos.UseVisualStyleBackColor = false;
            this.btnOjetivos.Click += new System.EventHandler(this.btnOjetivos_Click);
            // 
            // btnReportes
            // 
            this.btnReportes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.btnReportes.FlatAppearance.BorderSize = 0;
            this.btnReportes.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnReportes.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReportes.ForeColor = System.Drawing.Color.White;
            this.btnReportes.Location = new System.Drawing.Point(0, 325);
            this.btnReportes.Name = "btnReportes";
            this.btnReportes.Size = new System.Drawing.Size(249, 60);
            this.btnReportes.TabIndex = 7;
            this.btnReportes.Text = "        Reportes";
            this.btnReportes.UseVisualStyleBackColor = false;
            // 
            // btnCalibracion
            // 
            this.btnCalibracion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(119)))), ((int)(((byte)(205)))));
            this.btnCalibracion.FlatAppearance.BorderSize = 0;
            this.btnCalibracion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalibracion.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalibracion.ForeColor = System.Drawing.Color.White;
            this.btnCalibracion.Location = new System.Drawing.Point(0, 253);
            this.btnCalibracion.Name = "btnCalibracion";
            this.btnCalibracion.Size = new System.Drawing.Size(249, 55);
            this.btnCalibracion.TabIndex = 6;
            this.btnCalibracion.Text = "        Calibración";
            this.btnCalibracion.UseVisualStyleBackColor = false;
            this.btnCalibracion.Click += new System.EventHandler(this.btnCalibracion_Click);
            // 
            // btnEvaluacion
            // 
            this.btnEvaluacion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(119)))), ((int)(((byte)(205)))));
            this.btnEvaluacion.FlatAppearance.BorderSize = 0;
            this.btnEvaluacion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEvaluacion.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEvaluacion.ForeColor = System.Drawing.Color.White;
            this.btnEvaluacion.Location = new System.Drawing.Point(0, 180);
            this.btnEvaluacion.Name = "btnEvaluacion";
            this.btnEvaluacion.Size = new System.Drawing.Size(249, 55);
            this.btnEvaluacion.TabIndex = 5;
            this.btnEvaluacion.Text = "        Evaluación";
            this.btnEvaluacion.UseVisualStyleBackColor = false;
            this.btnEvaluacion.Click += new System.EventHandler(this.btnEvaluacion_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::AmongJavas.Properties.Resources.Icono_Planificacion1;
            this.pictureBox3.Location = new System.Drawing.Point(12, 29);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(49, 55);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 3;
            this.pictureBox3.TabStop = false;
            // 
            // btnPlanificacion
            // 
            this.btnPlanificacion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(119)))), ((int)(((byte)(205)))));
            this.btnPlanificacion.FlatAppearance.BorderSize = 0;
            this.btnPlanificacion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPlanificacion.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlanificacion.ForeColor = System.Drawing.Color.White;
            this.btnPlanificacion.Location = new System.Drawing.Point(0, 29);
            this.btnPlanificacion.Name = "btnPlanificacion";
            this.btnPlanificacion.Size = new System.Drawing.Size(245, 55);
            this.btnPlanificacion.TabIndex = 4;
            this.btnPlanificacion.Text = "         Planificacion";
            this.btnPlanificacion.UseVisualStyleBackColor = false;
            this.btnPlanificacion.Click += new System.EventHandler(this.btnPlanificacion_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(119)))), ((int)(((byte)(205)))));
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.lblTitulo);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1221, 182);
            this.panel1.TabIndex = 17;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.panel4.Controls.Add(this.btnCerrar);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1221, 33);
            this.panel4.TabIndex = 4;
            // 
            // btnCerrar
            // 
            this.btnCerrar.BackColor = System.Drawing.Color.Transparent;
            this.btnCerrar.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnCerrar.FlatAppearance.BorderSize = 0;
            this.btnCerrar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCerrar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCerrar.ForeColor = System.Drawing.Color.Silver;
            this.btnCerrar.Image = global::AmongJavas.Properties.Resources.Close_Icon;
            this.btnCerrar.Location = new System.Drawing.Point(1189, 0);
            this.btnCerrar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnCerrar.Name = "btnCerrar";
            this.btnCerrar.Size = new System.Drawing.Size(32, 33);
            this.btnCerrar.TabIndex = 64;
            this.btnCerrar.UseVisualStyleBackColor = false;
            this.btnCerrar.Click += new System.EventHandler(this.btnCerrar_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(119)))), ((int)(((byte)(205)))));
            this.panel2.Controls.Add(this.btnCerrarSesion);
            this.panel2.Controls.Add(this.txtArea);
            this.panel2.Controls.Add(this.txtNombre);
            this.panel2.Controls.Add(this.txtCorreo);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Location = new System.Drawing.Point(855, 32);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(365, 153);
            this.panel2.TabIndex = 1;
            // 
            // btnCerrarSesion
            // 
            this.btnCerrarSesion.AutoSize = true;
            this.btnCerrarSesion.LinkColor = System.Drawing.Color.White;
            this.btnCerrarSesion.Location = new System.Drawing.Point(235, 123);
            this.btnCerrarSesion.Name = "btnCerrarSesion";
            this.btnCerrarSesion.Size = new System.Drawing.Size(106, 20);
            this.btnCerrarSesion.TabIndex = 7;
            this.btnCerrarSesion.TabStop = true;
            this.btnCerrarSesion.Text = "Cerrar Sesion";
            this.btnCerrarSesion.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.btnCerrarSesion_LinkClicked);
            // 
            // txtArea
            // 
            this.txtArea.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.txtArea.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtArea.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtArea.Location = new System.Drawing.Point(137, 88);
            this.txtArea.Name = "txtArea";
            this.txtArea.Size = new System.Drawing.Size(204, 27);
            this.txtArea.TabIndex = 5;
            // 
            // txtNombre
            // 
            this.txtNombre.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.txtNombre.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNombre.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNombre.Location = new System.Drawing.Point(137, 16);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(204, 27);
            this.txtNombre.TabIndex = 4;
            // 
            // txtCorreo
            // 
            this.txtCorreo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.txtCorreo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCorreo.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCorreo.Location = new System.Drawing.Point(137, 52);
            this.txtCorreo.Name = "txtCorreo";
            this.txtCorreo.Size = new System.Drawing.Size(204, 27);
            this.txtCorreo.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(64, 88);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 21);
            this.label4.TabIndex = 3;
            this.label4.Text = "Area:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(64, 52);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 21);
            this.label3.TabIndex = 2;
            this.label3.Text = "Correo:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(62, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 21);
            this.label1.TabIndex = 1;
            this.label1.Text = "Nombre:";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::AmongJavas.Properties.Resources.IconoUsuario;
            this.pictureBox2.Location = new System.Drawing.Point(3, 32);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(53, 55);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::AmongJavas.Properties.Resources.IconoMenu;
            this.pictureBox1.Location = new System.Drawing.Point(4, 76);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(49, 55);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Century Gothic", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.Color.White;
            this.lblTitulo.Location = new System.Drawing.Point(59, 80);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(308, 47);
            this.lblTitulo.TabIndex = 1;
            this.lblTitulo.Text = "Menu Principal";
            // 
            // panelMi
            // 
            this.panelMi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.panelMi.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelMi.Controls.Add(this.btnGenerarMiPDI);
            this.panelMi.Controls.Add(this.btnGenerarMiRI);
            this.panelMi.Controls.Add(this.btnVerMiPDI);
            this.panelMi.Controls.Add(this.dgvMisPeriodos);
            this.panelMi.Controls.Add(this.panel9);
            this.panelMi.Location = new System.Drawing.Point(138, 54);
            this.panelMi.Name = "panelMi";
            this.panelMi.Size = new System.Drawing.Size(605, 293);
            this.panelMi.TabIndex = 20;
            // 
            // btnGenerarMiPDI
            // 
            this.btnGenerarMiPDI.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(63)))), ((int)(((byte)(65)))));
            this.btnGenerarMiPDI.FlatAppearance.BorderSize = 0;
            this.btnGenerarMiPDI.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGenerarMiPDI.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenerarMiPDI.ForeColor = System.Drawing.Color.White;
            this.btnGenerarMiPDI.Location = new System.Drawing.Point(245, 148);
            this.btnGenerarMiPDI.Name = "btnGenerarMiPDI";
            this.btnGenerarMiPDI.Size = new System.Drawing.Size(303, 38);
            this.btnGenerarMiPDI.TabIndex = 21;
            this.btnGenerarMiPDI.Text = "Generar Plan Desarrollo Individual";
            this.btnGenerarMiPDI.UseVisualStyleBackColor = false;
            this.btnGenerarMiPDI.Click += new System.EventHandler(this.btnGenerarMiPDI_Click);
            // 
            // btnGenerarMiRI
            // 
            this.btnGenerarMiRI.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(63)))), ((int)(((byte)(65)))));
            this.btnGenerarMiRI.FlatAppearance.BorderSize = 0;
            this.btnGenerarMiRI.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGenerarMiRI.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenerarMiRI.ForeColor = System.Drawing.Color.White;
            this.btnGenerarMiRI.Location = new System.Drawing.Point(245, 208);
            this.btnGenerarMiRI.Name = "btnGenerarMiRI";
            this.btnGenerarMiRI.Size = new System.Drawing.Size(303, 38);
            this.btnGenerarMiRI.TabIndex = 19;
            this.btnGenerarMiRI.Text = "Generar Reporte Individual";
            this.btnGenerarMiRI.UseVisualStyleBackColor = false;
            this.btnGenerarMiRI.Click += new System.EventHandler(this.btnGenerarMiRI_Click);
            // 
            // btnVerMiPDI
            // 
            this.btnVerMiPDI.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(63)))), ((int)(((byte)(65)))));
            this.btnVerMiPDI.FlatAppearance.BorderSize = 0;
            this.btnVerMiPDI.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnVerMiPDI.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerMiPDI.ForeColor = System.Drawing.Color.White;
            this.btnVerMiPDI.Location = new System.Drawing.Point(245, 85);
            this.btnVerMiPDI.Name = "btnVerMiPDI";
            this.btnVerMiPDI.Size = new System.Drawing.Size(303, 38);
            this.btnVerMiPDI.TabIndex = 20;
            this.btnVerMiPDI.Text = "Ver Plan Desarrollo Individual";
            this.btnVerMiPDI.UseVisualStyleBackColor = false;
            this.btnVerMiPDI.Click += new System.EventHandler(this.btnVerMiPDI_Click);
            // 
            // dgvMisPeriodos
            // 
            this.dgvMisPeriodos.AllowUserToAddRows = false;
            this.dgvMisPeriodos.AllowUserToDeleteRows = false;
            this.dgvMisPeriodos.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.dgvMisPeriodos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMisPeriodos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Periodo});
            this.dgvMisPeriodos.Dock = System.Windows.Forms.DockStyle.Left;
            this.dgvMisPeriodos.Location = new System.Drawing.Point(0, 45);
            this.dgvMisPeriodos.Name = "dgvMisPeriodos";
            this.dgvMisPeriodos.ReadOnly = true;
            this.dgvMisPeriodos.RowHeadersWidth = 62;
            this.dgvMisPeriodos.RowTemplate.Height = 28;
            this.dgvMisPeriodos.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgvMisPeriodos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvMisPeriodos.Size = new System.Drawing.Size(214, 246);
            this.dgvMisPeriodos.TabIndex = 16;
            this.dgvMisPeriodos.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvMisPeriodos_CellFormatting);
            // 
            // Periodo
            // 
            this.Periodo.DataPropertyName = "ano";
            this.Periodo.FillWeight = 50F;
            this.Periodo.HeaderText = "Periodo";
            this.Periodo.MinimumWidth = 8;
            this.Periodo.Name = "Periodo";
            this.Periodo.ReadOnly = true;
            this.Periodo.Width = 80;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(63)))), ((int)(((byte)(65)))));
            this.panel9.Controls.Add(this.label2);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel9.Location = new System.Drawing.Point(0, 0);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(603, 45);
            this.panel9.TabIndex = 15;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(5, 10);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(159, 28);
            this.label2.TabIndex = 3;
            this.label2.Text = "Mis Reportes";
            // 
            // panelRe
            // 
            this.panelRe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.panelRe.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelRe.Controls.Add(this.btnGenerarRS);
            this.panelRe.Controls.Add(this.dgvResumen);
            this.panelRe.Controls.Add(this.panel7);
            this.panelRe.Location = new System.Drawing.Point(640, 27);
            this.panelRe.Name = "panelRe";
            this.panelRe.Size = new System.Drawing.Size(239, 360);
            this.panelRe.TabIndex = 21;
            // 
            // btnGenerarRS
            // 
            this.btnGenerarRS.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(63)))), ((int)(((byte)(65)))));
            this.btnGenerarRS.FlatAppearance.BorderSize = 0;
            this.btnGenerarRS.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGenerarRS.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenerarRS.ForeColor = System.Drawing.Color.White;
            this.btnGenerarRS.Location = new System.Drawing.Point(60, 292);
            this.btnGenerarRS.Name = "btnGenerarRS";
            this.btnGenerarRS.Size = new System.Drawing.Size(114, 38);
            this.btnGenerarRS.TabIndex = 19;
            this.btnGenerarRS.Text = "Generar";
            this.btnGenerarRS.UseVisualStyleBackColor = false;
            this.btnGenerarRS.Click += new System.EventHandler(this.btnGenerarRS_Click);
            // 
            // dgvResumen
            // 
            this.dgvResumen.AllowUserToAddRows = false;
            this.dgvResumen.AllowUserToDeleteRows = false;
            this.dgvResumen.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.dgvResumen.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvResumen.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1});
            this.dgvResumen.Dock = System.Windows.Forms.DockStyle.Top;
            this.dgvResumen.Location = new System.Drawing.Point(0, 45);
            this.dgvResumen.Name = "dgvResumen";
            this.dgvResumen.ReadOnly = true;
            this.dgvResumen.RowHeadersWidth = 62;
            this.dgvResumen.RowTemplate.Height = 28;
            this.dgvResumen.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgvResumen.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvResumen.Size = new System.Drawing.Size(237, 230);
            this.dgvResumen.TabIndex = 16;
            this.dgvResumen.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvResumen_CellFormatting);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.FillWeight = 50F;
            this.dataGridViewTextBoxColumn1.HeaderText = "Periodo";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 150;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(63)))), ((int)(((byte)(65)))));
            this.panel7.Controls.Add(this.label5);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(237, 45);
            this.panel7.TabIndex = 15;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(5, 10);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(226, 28);
            this.label5.TabIndex = 3;
            this.label5.Text = "Reportes Resumen";
            // 
            // tabControl1
            // 
            this.tabControl1.Appearance = System.Windows.Forms.TabAppearance.Buttons;
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(277, 200);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(919, 462);
            this.tabControl1.TabIndex = 23;
            // 
            // tabPage1
            // 
            this.tabPage1.AutoScroll = true;
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.tabPage1.Controls.Add(this.panelMi);
            this.tabPage1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage1.Location = new System.Drawing.Point(4, 32);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(911, 426);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "REPORTE PERSONAL";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.cbEmpleados);
            this.tabPage2.Controls.Add(this.panelEv);
            this.tabPage2.Controls.Add(this.panelRe);
            this.tabPage2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage2.Location = new System.Drawing.Point(4, 32);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(911, 426);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "REPORTE EQUIPO";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.DimGray;
            this.label8.Location = new System.Drawing.Point(34, 30);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(162, 19);
            this.label8.TabIndex = 27;
            this.label8.Text = "Nombre Empleado:";
            // 
            // cbEmpleados
            // 
            this.cbEmpleados.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbEmpleados.FormattingEnabled = true;
            this.cbEmpleados.Location = new System.Drawing.Point(38, 54);
            this.cbEmpleados.Name = "cbEmpleados";
            this.cbEmpleados.Size = new System.Drawing.Size(255, 28);
            this.cbEmpleados.TabIndex = 28;
            this.cbEmpleados.SelectedIndexChanged += new System.EventHandler(this.cbEmpleados_SelectedIndexChanged);
            // 
            // panelEv
            // 
            this.panelEv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.panelEv.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelEv.Controls.Add(this.btnGenerarEvRI);
            this.panelEv.Controls.Add(this.dgvEvPeriodos);
            this.panelEv.Controls.Add(this.btnGenerarEvPDI);
            this.panelEv.Controls.Add(this.panel12);
            this.panelEv.Controls.Add(this.btnVerEvPDI);
            this.panelEv.Location = new System.Drawing.Point(38, 97);
            this.panelEv.Name = "panelEv";
            this.panelEv.Size = new System.Drawing.Size(572, 293);
            this.panelEv.TabIndex = 26;
            // 
            // btnGenerarEvRI
            // 
            this.btnGenerarEvRI.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(63)))), ((int)(((byte)(65)))));
            this.btnGenerarEvRI.FlatAppearance.BorderSize = 0;
            this.btnGenerarEvRI.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGenerarEvRI.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenerarEvRI.ForeColor = System.Drawing.Color.White;
            this.btnGenerarEvRI.Location = new System.Drawing.Point(242, 199);
            this.btnGenerarEvRI.Name = "btnGenerarEvRI";
            this.btnGenerarEvRI.Size = new System.Drawing.Size(303, 38);
            this.btnGenerarEvRI.TabIndex = 19;
            this.btnGenerarEvRI.Text = "Generar Reporte Individual";
            this.btnGenerarEvRI.UseVisualStyleBackColor = false;
            this.btnGenerarEvRI.Click += new System.EventHandler(this.btnGenerarEvRI_Click);
            // 
            // dgvEvPeriodos
            // 
            this.dgvEvPeriodos.AllowUserToAddRows = false;
            this.dgvEvPeriodos.AllowUserToDeleteRows = false;
            this.dgvEvPeriodos.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.dgvEvPeriodos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvEvPeriodos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn4});
            this.dgvEvPeriodos.Dock = System.Windows.Forms.DockStyle.Left;
            this.dgvEvPeriodos.Location = new System.Drawing.Point(0, 45);
            this.dgvEvPeriodos.Name = "dgvEvPeriodos";
            this.dgvEvPeriodos.ReadOnly = true;
            this.dgvEvPeriodos.RowHeadersWidth = 62;
            this.dgvEvPeriodos.RowTemplate.Height = 28;
            this.dgvEvPeriodos.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.dgvEvPeriodos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvEvPeriodos.Size = new System.Drawing.Size(214, 246);
            this.dgvEvPeriodos.TabIndex = 16;
            this.dgvEvPeriodos.CellFormatting += new System.Windows.Forms.DataGridViewCellFormattingEventHandler(this.dgvEvPeriodos_CellFormatting);
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.FillWeight = 50F;
            this.dataGridViewTextBoxColumn4.HeaderText = "Periodo";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 150;
            // 
            // btnGenerarEvPDI
            // 
            this.btnGenerarEvPDI.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(63)))), ((int)(((byte)(65)))));
            this.btnGenerarEvPDI.FlatAppearance.BorderSize = 0;
            this.btnGenerarEvPDI.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGenerarEvPDI.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenerarEvPDI.ForeColor = System.Drawing.Color.White;
            this.btnGenerarEvPDI.Location = new System.Drawing.Point(242, 139);
            this.btnGenerarEvPDI.Name = "btnGenerarEvPDI";
            this.btnGenerarEvPDI.Size = new System.Drawing.Size(303, 38);
            this.btnGenerarEvPDI.TabIndex = 24;
            this.btnGenerarEvPDI.Text = "Generar Plan Desarrollo Individual";
            this.btnGenerarEvPDI.UseVisualStyleBackColor = false;
            this.btnGenerarEvPDI.Click += new System.EventHandler(this.btnGenerarEvPDI_Click);
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(63)))), ((int)(((byte)(65)))));
            this.panel12.Controls.Add(this.label6);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel12.Location = new System.Drawing.Point(0, 0);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(570, 45);
            this.panel12.TabIndex = 15;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(5, 10);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(250, 28);
            this.label6.TabIndex = 3;
            this.label6.Text = "Reportes Empleados";
            // 
            // btnVerEvPDI
            // 
            this.btnVerEvPDI.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(63)))), ((int)(((byte)(65)))));
            this.btnVerEvPDI.FlatAppearance.BorderSize = 0;
            this.btnVerEvPDI.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnVerEvPDI.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerEvPDI.ForeColor = System.Drawing.Color.White;
            this.btnVerEvPDI.Location = new System.Drawing.Point(242, 76);
            this.btnVerEvPDI.Name = "btnVerEvPDI";
            this.btnVerEvPDI.Size = new System.Drawing.Size(303, 38);
            this.btnVerEvPDI.TabIndex = 23;
            this.btnVerEvPDI.Text = "Ver Plan Desarrollo Individual";
            this.btnVerEvPDI.UseVisualStyleBackColor = false;
            this.btnVerEvPDI.Click += new System.EventHandler(this.btnVerEvPDI_Click);
            // 
            // panelSolo
            // 
            this.panelSolo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panelSolo.Location = new System.Drawing.Point(277, 193);
            this.panelSolo.Name = "panelSolo";
            this.panelSolo.Size = new System.Drawing.Size(919, 17);
            this.panelSolo.TabIndex = 24;
            // 
            // frmMenuReportes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.ClientSize = new System.Drawing.Size(1221, 701);
            this.Controls.Add(this.panelSolo);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmMenuReportes";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmMenuReportes";
            this.panel3.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panelMi.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvMisPeriodos)).EndInit();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panelRe.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvResumen)).EndInit();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.panelEv.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvEvPeriodos)).EndInit();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Button btnOjetivos;
        private System.Windows.Forms.Button btnReportes;
        private System.Windows.Forms.Button btnCalibracion;
        private System.Windows.Forms.Button btnEvaluacion;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button btnPlanificacion;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.LinkLabel btnCerrarSesion;
        private System.Windows.Forms.TextBox txtArea;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.TextBox txtCorreo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Panel panelMi;
        private System.Windows.Forms.Button btnGenerarMiRI;
        private System.Windows.Forms.DataGridView dgvMisPeriodos;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panelRe;
        private System.Windows.Forms.Button btnGenerarRS;
        private System.Windows.Forms.DataGridView dgvResumen;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnCerrar;
        private System.Windows.Forms.SaveFileDialog sfdReporte;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Periodo;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cbEmpleados;
        private System.Windows.Forms.Panel panelEv;
        private System.Windows.Forms.Button btnGenerarEvRI;
        private System.Windows.Forms.DataGridView dgvEvPeriodos;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnGenerarMiPDI;
        private System.Windows.Forms.Button btnVerMiPDI;
        private System.Windows.Forms.Button btnGenerarEvPDI;
        private System.Windows.Forms.Button btnVerEvPDI;
        private System.Windows.Forms.Panel panelSolo;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.TextBox txtEtapa;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtPeriodo;
        private System.Windows.Forms.Label label7;
    }
}