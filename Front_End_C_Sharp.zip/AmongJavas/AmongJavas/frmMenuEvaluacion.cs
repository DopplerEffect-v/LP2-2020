﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AmongJavas
{
    public partial class frmMenuEvaluacion : Form
    {
        private frmInicioSesion panelInicioSesion;
        private ColaboradorWS.ColaboradorWSClient daoColaborador;
        public frmMenuEvaluacion(frmInicioSesion panelInicioSesion)
        {
            InitializeComponent();

            txtNombre.Enabled = false;
            txtArea.Enabled = false;
            txtCorreo.Enabled = false;
            daoColaborador = new ColaboradorWS.ColaboradorWSClient();
            this.panelInicioSesion = panelInicioSesion;
            llenarUsuario();
            deshabilitarBotones();
            deshabilitarMenus();
            deshabilitaEtapa();
        }
        public void deshabilitarBotones()
        {
            if (Program.colaborador.cuenta.permiso.permisoJefe == false)
            {
                panelEva.Visible = false;
                panelAuto.Location = new Point(360, 210);
            }
            else
            {
                panelEva.Visible = true;
                panelAuto.Location = new Point(360, 150);

            }
            if (daoColaborador.buscarJefe(Program.colaborador.idColaborador) == null)
            {
                panelAuto.Visible = false;
                panelEva.Location = new Point(360, 210);
            }
            else
            {
                panelAuto.Visible = true;
                panelEva.Location = new Point(360, 290);
            }
        }
        public void deshabilitaEtapa()
        {
            if (Program.cronograma.etapa < 1) { 
                panelNoDisponible.Visible = true;
                lblFecha.Text = Program.cronograma.FECHA_INICIO_E.ToShortDateString();
            }
            else
                panelNoDisponible.Visible = false;
            //Etapa
            switch (Program.cronograma.etapa)
            {
                case 0: txtEtapa.Text = "Planificación"; break;
                case 1: txtEtapa.Text = "Evaluación"; break;
                case 2: txtEtapa.Text = "Calibración"; break;
                case 3: txtEtapa.Text = "Reporte"; break;
                default: txtEtapa.Text = ""; break;
            }
            //Periodo
            txtPeriodo.Text = Program.periodo.fechaFin.Year.ToString();
        }
        public void deshabilitarMenus()
        {
            if (Program.colaborador.cuenta.permiso.permisoRRHH == false)
            {
                btnOjetivos.Location = new Point(0, 18);
                btnEvaluacion.Location = new Point(0, 68);
                btnReportes.Location = new Point(0, 118);
                pictureBox5.Location = new Point(10, 18);
                pictureBox4.Location = new Point(10, 68);
                pictureBox6.Location = new Point(10, 118);

                pictureBox3.Visible = false;
                pictureBox7.Visible = false;
                btnPlanificacion.Visible = false;
                btnCalibracion.Visible = false;
            }
            else
            {
                btnPlanificacion.Location = new Point(0, 18);
                btnOjetivos.Location = new Point(0, 68);
                btnEvaluacion.Location = new Point(0, 118);
                btnCalibracion.Location = new Point(0, 168);
                btnReportes.Location = new Point(0, 218);
                pictureBox3.Location = new Point(10, 18);
                pictureBox5.Location = new Point(10, 68);
                pictureBox4.Location = new Point(10, 118);
                pictureBox7.Location = new Point(10, 168);
                pictureBox6.Location = new Point(10, 218);

                pictureBox3.Visible = true;
                pictureBox7.Visible = true;
                btnPlanificacion.Visible = true;
                btnCalibracion.Visible = true;

            }
        }
        private void btnCerrarSesion_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Close();
            panelInicioSesion.Show();
        }

        private void btnPlanificacion_Click(object sender, EventArgs e)
        {
            this.Close();
            frmMenuPlanificacion panel = new frmMenuPlanificacion(panelInicioSesion);
            panel.Show();
        }

        private void btnOjetivos_Click(object sender, EventArgs e)
        {
            this.Close();
            frmMenuObjetivos panel = new frmMenuObjetivos(panelInicioSesion);
            panel.Show();
        }

        private void btnCalibracion_Click(object sender, EventArgs e)
        {
            this.Close();
            frmMenuCalibracion panel = new frmMenuCalibracion(panelInicioSesion);
            panel.Show();
        }

        private void btnReportes_Click(object sender, EventArgs e)
        {
            this.Close();
            frmMenuReportes panel = new frmMenuReportes(panelInicioSesion);
            panel.Show();
        }


        private void btnAutoEvaluarObjetivos_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmConfigurarAutoevaluacionObjetivos panelConfigurarAutoevaluacion =
                new frmConfigurarAutoevaluacionObjetivos(this.panelInicioSesion, this);

            panelConfigurarAutoevaluacion.llenarUsuario();
            panelConfigurarAutoevaluacion.Show();
        }

        private void btnAutoevaluarCompetencias_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmConfigurarAutoevaluacionCompetencias panelConfigurarAutoevaluacion =
                new frmConfigurarAutoevaluacionCompetencias(this.panelInicioSesion, this);

            panelConfigurarAutoevaluacion.llenarUsuario();
            panelConfigurarAutoevaluacion.Show();
        }

        private void btnEvaluarObjetivos_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmConfigurarEvaluacionObjetivos panelConfigurarEvaluacion =
                new frmConfigurarEvaluacionObjetivos(this.panelInicioSesion, this);

            panelConfigurarEvaluacion.llenarUsuario();
            panelConfigurarEvaluacion.Show();
        }

        private void btnEvaluarCompetencias_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmConfigurarEvaluacionCompetencias panelConfigurarEvaluacion =
                new frmConfigurarEvaluacionCompetencias(this.panelInicioSesion, this);

            panelConfigurarEvaluacion.llenarUsuario();
            panelConfigurarEvaluacion.Show();
        }

        private void btnEvaluarPotenciales_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmConfigurarEvaluacionPotenciales panelConfigurarEvaluacion =
                new frmConfigurarEvaluacionPotenciales(this.panelInicioSesion, this);

            panelConfigurarEvaluacion.llenarUsuario();
            panelConfigurarEvaluacion.Show();
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void panel7_Paint(object sender, PaintEventArgs e)
        {

        }
        public void llenarUsuario()
        {
            txtNombre.Text = Program.colaborador.nombres + " " + Program.colaborador.apellidos;
            txtArea.Text = Program.colaborador.area.nombre;
            txtCorreo.Text = Program.colaborador.correo;
        }

    }
}
