﻿using AmongJavas.CriterioWS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AmongJavas
{
    public partial class frmGestionarSubcompetencia : Form
    {
        private CriterioWS.subCriterio subcriterio;
        private Estado estado;
        private frmGestionarCompetencias panel;
        public frmGestionarSubcompetencia(Estado estado,frmGestionarCompetencias panel)
        {
            InitializeComponent();
            subcriterio = new CriterioWS.subCriterio();
            this.panel = panel;
            this.estado = estado;

            if (estado == Estado.Actualizar)
            {
                txtNombre.Text = panel.SubcriterioSeleccionado.nombre;
                txtDescripcion.Text = panel.SubcriterioSeleccionado.descripcion;
            }
            if (estado == Estado.Revisar)
            {
                btnGuardar.Visible = false;
                btnCancelar.Visible = false;
                txtNombre.Text = panel.SubcriterioSeleccionado.nombre;
                txtDescripcion.Text = panel.SubcriterioSeleccionado.descripcion;
                txtNombre.Enabled = false;
                txtDescripcion.Enabled = false;
            }

        }

        public frmGestionarSubcompetencia(NotaCriterioWS.notaSubCriterio notaSub)
        {
            InitializeComponent();

            btnGuardar.Visible = false;
            btnCancelar.Visible = false;
            txtNombre.Enabled = false;
            txtDescripcion.Enabled = false;
            txtNombre.Text = notaSub.subcriterio.nombre;
            txtDescripcion.Text = notaSub.subcriterio.descripcion;
            lblGestionSubpotencial.Text = "Detalle de subcompetencia";

        }
        private void btnCerrar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

        private bool esRepetido(String nombre)
        {
            foreach (CriterioWS.subCriterio subcr in panel.Lista)
            {
                if (subcr.nombre == txtNombre.Text)
                    return true;
            }
            return false;
        }
        private void btnGuardar_Click(object sender, EventArgs e)
        {
            //Verificacion
            if (esRepetido(txtNombre.Text))
                MessageBox.Show("Subcriterio "+txtNombre.Text+" ya existe, debe ingresar uno nuevo", "Mensaje de error", MessageBoxButtons.OK);
            else if (txtNombre.Text == "")
                MessageBox.Show("Falta ingresar el Nombre de la subcompetencia", "Mensaje de error", MessageBoxButtons.OK);
            else if (txtDescripcion.Text == "")
                MessageBox.Show("Falta ingresar la Descripcion de la subcompetencia", "Mensaje de error", MessageBoxButtons.OK);
            else if (panel.esCadenaEnBlanco(txtNombre.Text))
                MessageBox.Show("Nombre de subcompetencia no puede ser cadena en blanco", "Mensaje de error", MessageBoxButtons.OK);
            else if (panel.esCadenaEnBlanco(txtDescripcion.Text))
                MessageBox.Show("Descripcion de subcompetencia no puede ser cadena en blanco", "Mensaje de error", MessageBoxButtons.OK);
            else{ 
                subcriterio.nombre = txtNombre.Text;
                subcriterio.descripcion = txtDescripcion.Text;
                if (estado == Estado.Nuevo) {
                    subcriterio.accion = 0;
                    panel.Lista.Add(subcriterio);
                }
                else
                {
                    panel.SubcriterioSeleccionado.nombre = txtNombre.Text;
                    panel.SubcriterioSeleccionado.descripcion = txtDescripcion.Text;
                    if (panel.SubcriterioSeleccionado.accion == 3) // Si ya existia en la BD
                        panel.SubcriterioSeleccionado.accion = 1; //UPDATE
                }

                this.DialogResult = DialogResult.OK;
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
        }

        private void btnAtras_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

    }
}
