﻿namespace AmongJavas
{
    partial class frmConfigurarCronograma
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel3 = new System.Windows.Forms.Panel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.btnCofigurarPesos = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.btnCronograma = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnAtras = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnCerrar = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnCerrarSesion = new System.Windows.Forms.LinkLabel();
            this.txtArea = new System.Windows.Forms.TextBox();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.txtCorreo = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.dtpFechaNotificacionCalibracion = new System.Windows.Forms.DateTimePicker();
            this.dtpFechaFinCalibracion = new System.Windows.Forms.DateTimePicker();
            this.lblFechaNotificacionCalibracion = new System.Windows.Forms.Label();
            this.dtpFechaInicioCalibracion = new System.Windows.Forms.DateTimePicker();
            this.lblFechaFinCalibracion = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.lblFechaInicioCalibracion = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.dtpFechaNotificacionReportes = new System.Windows.Forms.DateTimePicker();
            this.dtpFechaFinReportes = new System.Windows.Forms.DateTimePicker();
            this.lblFechaNotificacionReportes = new System.Windows.Forms.Label();
            this.dtpFechaInicioReportes = new System.Windows.Forms.DateTimePicker();
            this.lblFechaFinReportes = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.lblFechaInicioReportes = new System.Windows.Forms.Label();
            this.btnActualizar = new System.Windows.Forms.Button();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel5 = new System.Windows.Forms.Panel();
            this.dtpFechaNotificacionPlanificacion = new System.Windows.Forms.DateTimePicker();
            this.dtpFechaFinPlanificacion = new System.Windows.Forms.DateTimePicker();
            this.lblFechaNotificacionPlanificacion = new System.Windows.Forms.Label();
            this.dtpFechaInicioPlanificacion = new System.Windows.Forms.DateTimePicker();
            this.lblFechaFinPlanificacion = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.lblFechaInicioPlanificacion = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel7 = new System.Windows.Forms.Panel();
            this.dtpFechaNotificacionEvaluacion = new System.Windows.Forms.DateTimePicker();
            this.dtpFechaFinEvaluacion = new System.Windows.Forms.DateTimePicker();
            this.lblFechaNotificacionEvaluacion = new System.Windows.Forms.Label();
            this.dtpFechaInicioEvaluacion = new System.Windows.Forms.DateTimePicker();
            this.lblFechaFinEvaluacion = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.lblFechaInicioEvaluacion = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnAtras)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel9.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel12.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(119)))), ((int)(((byte)(205)))));
            this.panel3.Controls.Add(this.pictureBox4);
            this.panel3.Controls.Add(this.btnCofigurarPesos);
            this.panel3.Controls.Add(this.pictureBox3);
            this.panel3.Controls.Add(this.btnCronograma);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 182);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(249, 519);
            this.panel3.TabIndex = 18;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::AmongJavas.Properties.Resources.Icono_Planificacion1;
            this.pictureBox4.Location = new System.Drawing.Point(15, 137);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(49, 55);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 11;
            this.pictureBox4.TabStop = false;
            // 
            // btnCofigurarPesos
            // 
            this.btnCofigurarPesos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(119)))), ((int)(((byte)(205)))));
            this.btnCofigurarPesos.FlatAppearance.BorderSize = 0;
            this.btnCofigurarPesos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCofigurarPesos.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCofigurarPesos.ForeColor = System.Drawing.Color.White;
            this.btnCofigurarPesos.Location = new System.Drawing.Point(0, 130);
            this.btnCofigurarPesos.Name = "btnCofigurarPesos";
            this.btnCofigurarPesos.Size = new System.Drawing.Size(249, 71);
            this.btnCofigurarPesos.TabIndex = 10;
            this.btnCofigurarPesos.Text = "           Configurar           Pesos";
            this.btnCofigurarPesos.UseVisualStyleBackColor = false;
            this.btnCofigurarPesos.Click += new System.EventHandler(this.btnCofigurarPesos_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.pictureBox3.Image = global::AmongJavas.Properties.Resources.Icono_Planificacion1;
            this.pictureBox3.Location = new System.Drawing.Point(12, 29);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(49, 55);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 3;
            this.pictureBox3.TabStop = false;
            // 
            // btnCronograma
            // 
            this.btnCronograma.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.btnCronograma.FlatAppearance.BorderSize = 0;
            this.btnCronograma.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCronograma.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCronograma.ForeColor = System.Drawing.Color.White;
            this.btnCronograma.Location = new System.Drawing.Point(0, 30);
            this.btnCronograma.Name = "btnCronograma";
            this.btnCronograma.Size = new System.Drawing.Size(249, 54);
            this.btnCronograma.TabIndex = 4;
            this.btnCronograma.Text = "        Cronograma";
            this.btnCronograma.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(119)))), ((int)(((byte)(205)))));
            this.panel1.Controls.Add(this.btnAtras);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.lblTitulo);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1221, 182);
            this.panel1.TabIndex = 17;
            // 
            // btnAtras
            // 
            this.btnAtras.Image = global::AmongJavas.Properties.Resources.IconoAtras2;
            this.btnAtras.Location = new System.Drawing.Point(10, 38);
            this.btnAtras.Name = "btnAtras";
            this.btnAtras.Size = new System.Drawing.Size(53, 53);
            this.btnAtras.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnAtras.TabIndex = 14;
            this.btnAtras.TabStop = false;
            this.btnAtras.Click += new System.EventHandler(this.btnAtras_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::AmongJavas.Properties.Resources.IconoMenu;
            this.pictureBox1.Location = new System.Drawing.Point(15, 102);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(50, 55);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Century Gothic", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.Color.White;
            this.lblTitulo.Location = new System.Drawing.Point(69, 107);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(587, 47);
            this.lblTitulo.TabIndex = 12;
            this.lblTitulo.Text = "Planificación - Configuración";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.panel4.Controls.Add(this.btnCerrar);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1221, 33);
            this.panel4.TabIndex = 4;
            // 
            // btnCerrar
            // 
            this.btnCerrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.btnCerrar.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnCerrar.FlatAppearance.BorderSize = 0;
            this.btnCerrar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCerrar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCerrar.ForeColor = System.Drawing.Color.Silver;
            this.btnCerrar.Image = global::AmongJavas.Properties.Resources.Close_Icon;
            this.btnCerrar.Location = new System.Drawing.Point(1189, 0);
            this.btnCerrar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnCerrar.Name = "btnCerrar";
            this.btnCerrar.Size = new System.Drawing.Size(32, 33);
            this.btnCerrar.TabIndex = 61;
            this.btnCerrar.UseVisualStyleBackColor = false;
            this.btnCerrar.Click += new System.EventHandler(this.btnCerrar_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(119)))), ((int)(((byte)(205)))));
            this.panel2.Controls.Add(this.btnCerrarSesion);
            this.panel2.Controls.Add(this.txtArea);
            this.panel2.Controls.Add(this.txtNombre);
            this.panel2.Controls.Add(this.txtCorreo);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Location = new System.Drawing.Point(858, 29);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(363, 153);
            this.panel2.TabIndex = 1;
            // 
            // btnCerrarSesion
            // 
            this.btnCerrarSesion.AutoSize = true;
            this.btnCerrarSesion.LinkColor = System.Drawing.Color.White;
            this.btnCerrarSesion.Location = new System.Drawing.Point(235, 123);
            this.btnCerrarSesion.Name = "btnCerrarSesion";
            this.btnCerrarSesion.Size = new System.Drawing.Size(106, 20);
            this.btnCerrarSesion.TabIndex = 7;
            this.btnCerrarSesion.TabStop = true;
            this.btnCerrarSesion.Text = "Cerrar Sesion";
            this.btnCerrarSesion.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.btnCerrarSesion_LinkClicked);
            // 
            // txtArea
            // 
            this.txtArea.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.txtArea.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtArea.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtArea.Location = new System.Drawing.Point(137, 88);
            this.txtArea.Name = "txtArea";
            this.txtArea.Size = new System.Drawing.Size(204, 27);
            this.txtArea.TabIndex = 5;
            // 
            // txtNombre
            // 
            this.txtNombre.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.txtNombre.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNombre.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNombre.Location = new System.Drawing.Point(137, 16);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(204, 27);
            this.txtNombre.TabIndex = 4;
            // 
            // txtCorreo
            // 
            this.txtCorreo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.txtCorreo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCorreo.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCorreo.Location = new System.Drawing.Point(137, 52);
            this.txtCorreo.Name = "txtCorreo";
            this.txtCorreo.Size = new System.Drawing.Size(204, 27);
            this.txtCorreo.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(62, 88);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 21);
            this.label4.TabIndex = 3;
            this.label4.Text = "Area:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(62, 52);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 21);
            this.label3.TabIndex = 2;
            this.label3.Text = "Correo:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(62, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 21);
            this.label1.TabIndex = 1;
            this.label1.Text = "Nombre:";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::AmongJavas.Properties.Resources.IconoUsuario;
            this.pictureBox2.Location = new System.Drawing.Point(3, 32);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(53, 55);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.dtpFechaNotificacionCalibracion);
            this.panel9.Controls.Add(this.dtpFechaFinCalibracion);
            this.panel9.Controls.Add(this.lblFechaNotificacionCalibracion);
            this.panel9.Controls.Add(this.dtpFechaInicioCalibracion);
            this.panel9.Controls.Add(this.lblFechaFinCalibracion);
            this.panel9.Controls.Add(this.panel10);
            this.panel9.Controls.Add(this.lblFechaInicioCalibracion);
            this.panel9.Location = new System.Drawing.Point(146, 32);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(434, 181);
            this.panel9.TabIndex = 30;
            // 
            // dtpFechaNotificacionCalibracion
            // 
            this.dtpFechaNotificacionCalibracion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpFechaNotificacionCalibracion.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFechaNotificacionCalibracion.Location = new System.Drawing.Point(228, 100);
            this.dtpFechaNotificacionCalibracion.Name = "dtpFechaNotificacionCalibracion";
            this.dtpFechaNotificacionCalibracion.Size = new System.Drawing.Size(167, 26);
            this.dtpFechaNotificacionCalibracion.TabIndex = 28;
            this.dtpFechaNotificacionCalibracion.Value = new System.DateTime(2020, 10, 19, 17, 18, 53, 0);
            this.dtpFechaNotificacionCalibracion.ValueChanged += new System.EventHandler(this.dtpFechaNotificacionCalibracion_ValueChanged);
            // 
            // dtpFechaFinCalibracion
            // 
            this.dtpFechaFinCalibracion.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpFechaFinCalibracion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpFechaFinCalibracion.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFechaFinCalibracion.Location = new System.Drawing.Point(228, 142);
            this.dtpFechaFinCalibracion.Name = "dtpFechaFinCalibracion";
            this.dtpFechaFinCalibracion.Size = new System.Drawing.Size(167, 26);
            this.dtpFechaFinCalibracion.TabIndex = 27;
            this.dtpFechaFinCalibracion.Value = new System.DateTime(2020, 10, 19, 17, 18, 53, 0);
            this.dtpFechaFinCalibracion.ValueChanged += new System.EventHandler(this.dtpFechaFinCalibracion_ValueChanged);
            // 
            // lblFechaNotificacionCalibracion
            // 
            this.lblFechaNotificacionCalibracion.AutoSize = true;
            this.lblFechaNotificacionCalibracion.BackColor = System.Drawing.Color.Transparent;
            this.lblFechaNotificacionCalibracion.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFechaNotificacionCalibracion.ForeColor = System.Drawing.Color.Black;
            this.lblFechaNotificacionCalibracion.Location = new System.Drawing.Point(3, 100);
            this.lblFechaNotificacionCalibracion.Name = "lblFechaNotificacionCalibracion";
            this.lblFechaNotificacionCalibracion.Size = new System.Drawing.Size(198, 23);
            this.lblFechaNotificacionCalibracion.TabIndex = 22;
            this.lblFechaNotificacionCalibracion.Text = "Fecha Notificacion:";
            // 
            // dtpFechaInicioCalibracion
            // 
            this.dtpFechaInicioCalibracion.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpFechaInicioCalibracion.Cursor = System.Windows.Forms.Cursors.Default;
            this.dtpFechaInicioCalibracion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpFechaInicioCalibracion.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFechaInicioCalibracion.Location = new System.Drawing.Point(228, 57);
            this.dtpFechaInicioCalibracion.Name = "dtpFechaInicioCalibracion";
            this.dtpFechaInicioCalibracion.Size = new System.Drawing.Size(167, 26);
            this.dtpFechaInicioCalibracion.TabIndex = 26;
            this.dtpFechaInicioCalibracion.Value = new System.DateTime(2020, 10, 19, 17, 18, 53, 0);
            this.dtpFechaInicioCalibracion.ValueChanged += new System.EventHandler(this.dtpFechaInicioCalibracion_ValueChanged);
            // 
            // lblFechaFinCalibracion
            // 
            this.lblFechaFinCalibracion.AutoSize = true;
            this.lblFechaFinCalibracion.BackColor = System.Drawing.Color.Transparent;
            this.lblFechaFinCalibracion.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFechaFinCalibracion.ForeColor = System.Drawing.Color.Black;
            this.lblFechaFinCalibracion.Location = new System.Drawing.Point(3, 142);
            this.lblFechaFinCalibracion.Name = "lblFechaFinCalibracion";
            this.lblFechaFinCalibracion.Size = new System.Drawing.Size(108, 23);
            this.lblFechaFinCalibracion.TabIndex = 21;
            this.lblFechaFinCalibracion.Text = "Fecha Fin:";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.panel10.Controls.Add(this.label9);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel10.Location = new System.Drawing.Point(0, 0);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(432, 50);
            this.panel10.TabIndex = 0;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(38)))), ((int)(((byte)(70)))));
            this.label9.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(2, 10);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(230, 28);
            this.label9.TabIndex = 21;
            this.label9.Text = "Etapa Calibracion:";
            // 
            // lblFechaInicioCalibracion
            // 
            this.lblFechaInicioCalibracion.AutoSize = true;
            this.lblFechaInicioCalibracion.BackColor = System.Drawing.Color.Transparent;
            this.lblFechaInicioCalibracion.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFechaInicioCalibracion.ForeColor = System.Drawing.Color.Black;
            this.lblFechaInicioCalibracion.Location = new System.Drawing.Point(3, 57);
            this.lblFechaInicioCalibracion.Name = "lblFechaInicioCalibracion";
            this.lblFechaInicioCalibracion.Size = new System.Drawing.Size(132, 23);
            this.lblFechaInicioCalibracion.TabIndex = 20;
            this.lblFechaInicioCalibracion.Text = "Fecha Inicio:";
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.panel11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel11.Controls.Add(this.dtpFechaNotificacionReportes);
            this.panel11.Controls.Add(this.dtpFechaFinReportes);
            this.panel11.Controls.Add(this.lblFechaNotificacionReportes);
            this.panel11.Controls.Add(this.dtpFechaInicioReportes);
            this.panel11.Controls.Add(this.lblFechaFinReportes);
            this.panel11.Controls.Add(this.panel12);
            this.panel11.Controls.Add(this.lblFechaInicioReportes);
            this.panel11.Location = new System.Drawing.Point(146, 32);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(434, 181);
            this.panel11.TabIndex = 31;
            // 
            // dtpFechaNotificacionReportes
            // 
            this.dtpFechaNotificacionReportes.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFechaNotificacionReportes.Location = new System.Drawing.Point(228, 100);
            this.dtpFechaNotificacionReportes.Name = "dtpFechaNotificacionReportes";
            this.dtpFechaNotificacionReportes.Size = new System.Drawing.Size(167, 26);
            this.dtpFechaNotificacionReportes.TabIndex = 28;
            this.dtpFechaNotificacionReportes.Value = new System.DateTime(2020, 10, 19, 17, 18, 53, 0);
            this.dtpFechaNotificacionReportes.ValueChanged += new System.EventHandler(this.dtpFechaNotificacionReportes_ValueChanged);
            // 
            // dtpFechaFinReportes
            // 
            this.dtpFechaFinReportes.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFechaFinReportes.Location = new System.Drawing.Point(228, 142);
            this.dtpFechaFinReportes.Name = "dtpFechaFinReportes";
            this.dtpFechaFinReportes.Size = new System.Drawing.Size(167, 26);
            this.dtpFechaFinReportes.TabIndex = 27;
            this.dtpFechaFinReportes.Value = new System.DateTime(2020, 10, 19, 17, 18, 53, 0);
            this.dtpFechaFinReportes.ValueChanged += new System.EventHandler(this.dtpFechaFinReportes_ValueChanged);
            // 
            // lblFechaNotificacionReportes
            // 
            this.lblFechaNotificacionReportes.AutoSize = true;
            this.lblFechaNotificacionReportes.BackColor = System.Drawing.Color.Transparent;
            this.lblFechaNotificacionReportes.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFechaNotificacionReportes.ForeColor = System.Drawing.Color.Black;
            this.lblFechaNotificacionReportes.Location = new System.Drawing.Point(3, 100);
            this.lblFechaNotificacionReportes.Name = "lblFechaNotificacionReportes";
            this.lblFechaNotificacionReportes.Size = new System.Drawing.Size(198, 23);
            this.lblFechaNotificacionReportes.TabIndex = 22;
            this.lblFechaNotificacionReportes.Text = "Fecha Notificacion:";
            // 
            // dtpFechaInicioReportes
            // 
            this.dtpFechaInicioReportes.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFechaInicioReportes.Location = new System.Drawing.Point(228, 57);
            this.dtpFechaInicioReportes.Name = "dtpFechaInicioReportes";
            this.dtpFechaInicioReportes.Size = new System.Drawing.Size(167, 26);
            this.dtpFechaInicioReportes.TabIndex = 26;
            this.dtpFechaInicioReportes.Value = new System.DateTime(2020, 10, 19, 17, 18, 53, 0);
            this.dtpFechaInicioReportes.ValueChanged += new System.EventHandler(this.dtpFechaInicioReportes_ValueChanged);
            // 
            // lblFechaFinReportes
            // 
            this.lblFechaFinReportes.AutoSize = true;
            this.lblFechaFinReportes.BackColor = System.Drawing.Color.Transparent;
            this.lblFechaFinReportes.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFechaFinReportes.ForeColor = System.Drawing.Color.Black;
            this.lblFechaFinReportes.Location = new System.Drawing.Point(3, 142);
            this.lblFechaFinReportes.Name = "lblFechaFinReportes";
            this.lblFechaFinReportes.Size = new System.Drawing.Size(108, 23);
            this.lblFechaFinReportes.TabIndex = 21;
            this.lblFechaFinReportes.Text = "Fecha Fin:";
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.panel12.Controls.Add(this.label19);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel12.Location = new System.Drawing.Point(0, 0);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(432, 50);
            this.panel12.TabIndex = 0;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(38)))), ((int)(((byte)(70)))));
            this.label19.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(2, 10);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(194, 28);
            this.label19.TabIndex = 21;
            this.label19.Text = "Etapa Reportes:";
            // 
            // lblFechaInicioReportes
            // 
            this.lblFechaInicioReportes.AutoSize = true;
            this.lblFechaInicioReportes.BackColor = System.Drawing.Color.Transparent;
            this.lblFechaInicioReportes.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFechaInicioReportes.ForeColor = System.Drawing.Color.Black;
            this.lblFechaInicioReportes.Location = new System.Drawing.Point(3, 57);
            this.lblFechaInicioReportes.Name = "lblFechaInicioReportes";
            this.lblFechaInicioReportes.Size = new System.Drawing.Size(132, 23);
            this.lblFechaInicioReportes.TabIndex = 20;
            this.lblFechaInicioReportes.Text = "Fecha Inicio:";
            // 
            // btnActualizar
            // 
            this.btnActualizar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.btnActualizar.FlatAppearance.BorderSize = 0;
            this.btnActualizar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnActualizar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnActualizar.ForeColor = System.Drawing.Color.White;
            this.btnActualizar.Location = new System.Drawing.Point(502, 640);
            this.btnActualizar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnActualizar.Name = "btnActualizar";
            this.btnActualizar.Size = new System.Drawing.Size(133, 35);
            this.btnActualizar.TabIndex = 44;
            this.btnActualizar.Text = "Actualizar";
            this.btnActualizar.UseVisualStyleBackColor = false;
            this.btnActualizar.Click += new System.EventHandler(this.btnActualizar_Click);
            // 
            // btnGuardar
            // 
            this.btnGuardar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.btnGuardar.FlatAppearance.BorderSize = 0;
            this.btnGuardar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGuardar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGuardar.ForeColor = System.Drawing.Color.White;
            this.btnGuardar.Location = new System.Drawing.Point(661, 640);
            this.btnGuardar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(133, 35);
            this.btnGuardar.TabIndex = 45;
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.UseVisualStyleBackColor = false;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.btnCancelar.FlatAppearance.BorderSize = 0;
            this.btnCancelar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCancelar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelar.ForeColor = System.Drawing.Color.White;
            this.btnCancelar.Location = new System.Drawing.Point(819, 640);
            this.btnCancelar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(133, 35);
            this.btnCancelar.TabIndex = 46;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = false;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Appearance = System.Windows.Forms.TabAppearance.Buttons;
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(352, 269);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(743, 278);
            this.tabControl1.TabIndex = 47;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.tabPage1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.tabPage1.Controls.Add(this.panel5);
            this.tabPage1.Location = new System.Drawing.Point(4, 32);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tabPage1.Size = new System.Drawing.Size(735, 242);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "1.PLANIFICACION";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.dtpFechaNotificacionPlanificacion);
            this.panel5.Controls.Add(this.dtpFechaFinPlanificacion);
            this.panel5.Controls.Add(this.lblFechaNotificacionPlanificacion);
            this.panel5.Controls.Add(this.dtpFechaInicioPlanificacion);
            this.panel5.Controls.Add(this.lblFechaFinPlanificacion);
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Controls.Add(this.lblFechaInicioPlanificacion);
            this.panel5.Location = new System.Drawing.Point(146, 32);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(434, 181);
            this.panel5.TabIndex = 28;
            // 
            // dtpFechaNotificacionPlanificacion
            // 
            this.dtpFechaNotificacionPlanificacion.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFechaNotificacionPlanificacion.Location = new System.Drawing.Point(228, 100);
            this.dtpFechaNotificacionPlanificacion.Name = "dtpFechaNotificacionPlanificacion";
            this.dtpFechaNotificacionPlanificacion.Size = new System.Drawing.Size(167, 26);
            this.dtpFechaNotificacionPlanificacion.TabIndex = 28;
            this.dtpFechaNotificacionPlanificacion.Value = new System.DateTime(2020, 10, 19, 17, 18, 53, 0);
            this.dtpFechaNotificacionPlanificacion.ValueChanged += new System.EventHandler(this.dtpFechaNotificacionPlanificacion_ValueChanged);
            // 
            // dtpFechaFinPlanificacion
            // 
            this.dtpFechaFinPlanificacion.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFechaFinPlanificacion.Location = new System.Drawing.Point(228, 142);
            this.dtpFechaFinPlanificacion.Name = "dtpFechaFinPlanificacion";
            this.dtpFechaFinPlanificacion.Size = new System.Drawing.Size(167, 26);
            this.dtpFechaFinPlanificacion.TabIndex = 27;
            this.dtpFechaFinPlanificacion.Value = new System.DateTime(2020, 10, 19, 17, 18, 53, 0);
            this.dtpFechaFinPlanificacion.ValueChanged += new System.EventHandler(this.dtpFechaFinPlanificacion_ValueChanged);
            // 
            // lblFechaNotificacionPlanificacion
            // 
            this.lblFechaNotificacionPlanificacion.AutoSize = true;
            this.lblFechaNotificacionPlanificacion.BackColor = System.Drawing.Color.Transparent;
            this.lblFechaNotificacionPlanificacion.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFechaNotificacionPlanificacion.ForeColor = System.Drawing.Color.Black;
            this.lblFechaNotificacionPlanificacion.Location = new System.Drawing.Point(3, 100);
            this.lblFechaNotificacionPlanificacion.Name = "lblFechaNotificacionPlanificacion";
            this.lblFechaNotificacionPlanificacion.Size = new System.Drawing.Size(198, 23);
            this.lblFechaNotificacionPlanificacion.TabIndex = 22;
            this.lblFechaNotificacionPlanificacion.Text = "Fecha Notificacion:";
            // 
            // dtpFechaInicioPlanificacion
            // 
            this.dtpFechaInicioPlanificacion.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFechaInicioPlanificacion.Location = new System.Drawing.Point(228, 57);
            this.dtpFechaInicioPlanificacion.Name = "dtpFechaInicioPlanificacion";
            this.dtpFechaInicioPlanificacion.Size = new System.Drawing.Size(167, 26);
            this.dtpFechaInicioPlanificacion.TabIndex = 26;
            this.dtpFechaInicioPlanificacion.Value = new System.DateTime(2020, 10, 19, 17, 18, 53, 0);
            this.dtpFechaInicioPlanificacion.ValueChanged += new System.EventHandler(this.dtpFechaInicioPlanificacion_ValueChanged);
            // 
            // lblFechaFinPlanificacion
            // 
            this.lblFechaFinPlanificacion.AutoSize = true;
            this.lblFechaFinPlanificacion.BackColor = System.Drawing.Color.Transparent;
            this.lblFechaFinPlanificacion.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFechaFinPlanificacion.ForeColor = System.Drawing.Color.Black;
            this.lblFechaFinPlanificacion.Location = new System.Drawing.Point(3, 142);
            this.lblFechaFinPlanificacion.Name = "lblFechaFinPlanificacion";
            this.lblFechaFinPlanificacion.Size = new System.Drawing.Size(108, 23);
            this.lblFechaFinPlanificacion.TabIndex = 21;
            this.lblFechaFinPlanificacion.Text = "Fecha Fin:";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.panel6.Controls.Add(this.label5);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(432, 50);
            this.panel6.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(38)))), ((int)(((byte)(70)))));
            this.label5.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(2, 10);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(242, 28);
            this.label5.TabIndex = 19;
            this.label5.Text = "Etapa Planificacion:";
            // 
            // lblFechaInicioPlanificacion
            // 
            this.lblFechaInicioPlanificacion.AutoSize = true;
            this.lblFechaInicioPlanificacion.BackColor = System.Drawing.Color.Transparent;
            this.lblFechaInicioPlanificacion.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFechaInicioPlanificacion.ForeColor = System.Drawing.Color.Black;
            this.lblFechaInicioPlanificacion.Location = new System.Drawing.Point(3, 57);
            this.lblFechaInicioPlanificacion.Name = "lblFechaInicioPlanificacion";
            this.lblFechaInicioPlanificacion.Size = new System.Drawing.Size(132, 23);
            this.lblFechaInicioPlanificacion.TabIndex = 20;
            this.lblFechaInicioPlanificacion.Text = "Fecha Inicio:";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.tabPage2.Controls.Add(this.panel7);
            this.tabPage2.Location = new System.Drawing.Point(4, 32);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(735, 242);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "2.EVALUACION";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.dtpFechaNotificacionEvaluacion);
            this.panel7.Controls.Add(this.dtpFechaFinEvaluacion);
            this.panel7.Controls.Add(this.lblFechaNotificacionEvaluacion);
            this.panel7.Controls.Add(this.dtpFechaInicioEvaluacion);
            this.panel7.Controls.Add(this.lblFechaFinEvaluacion);
            this.panel7.Controls.Add(this.panel8);
            this.panel7.Controls.Add(this.lblFechaInicioEvaluacion);
            this.panel7.Location = new System.Drawing.Point(146, 32);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(434, 181);
            this.panel7.TabIndex = 30;
            // 
            // dtpFechaNotificacionEvaluacion
            // 
            this.dtpFechaNotificacionEvaluacion.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFechaNotificacionEvaluacion.Location = new System.Drawing.Point(228, 100);
            this.dtpFechaNotificacionEvaluacion.Name = "dtpFechaNotificacionEvaluacion";
            this.dtpFechaNotificacionEvaluacion.Size = new System.Drawing.Size(167, 26);
            this.dtpFechaNotificacionEvaluacion.TabIndex = 28;
            this.dtpFechaNotificacionEvaluacion.Value = new System.DateTime(2020, 10, 19, 17, 18, 53, 0);
            this.dtpFechaNotificacionEvaluacion.ValueChanged += new System.EventHandler(this.dtpFechaNotificacionEvaluacion_ValueChanged);
            // 
            // dtpFechaFinEvaluacion
            // 
            this.dtpFechaFinEvaluacion.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFechaFinEvaluacion.Location = new System.Drawing.Point(228, 142);
            this.dtpFechaFinEvaluacion.Name = "dtpFechaFinEvaluacion";
            this.dtpFechaFinEvaluacion.Size = new System.Drawing.Size(167, 26);
            this.dtpFechaFinEvaluacion.TabIndex = 27;
            this.dtpFechaFinEvaluacion.Value = new System.DateTime(2020, 10, 19, 17, 18, 53, 0);
            this.dtpFechaFinEvaluacion.ValueChanged += new System.EventHandler(this.dtpFechaFinEvaluacion_ValueChanged);
            // 
            // lblFechaNotificacionEvaluacion
            // 
            this.lblFechaNotificacionEvaluacion.AutoSize = true;
            this.lblFechaNotificacionEvaluacion.BackColor = System.Drawing.Color.Transparent;
            this.lblFechaNotificacionEvaluacion.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFechaNotificacionEvaluacion.ForeColor = System.Drawing.Color.Black;
            this.lblFechaNotificacionEvaluacion.Location = new System.Drawing.Point(3, 100);
            this.lblFechaNotificacionEvaluacion.Name = "lblFechaNotificacionEvaluacion";
            this.lblFechaNotificacionEvaluacion.Size = new System.Drawing.Size(198, 23);
            this.lblFechaNotificacionEvaluacion.TabIndex = 22;
            this.lblFechaNotificacionEvaluacion.Text = "Fecha Notificacion:";
            // 
            // dtpFechaInicioEvaluacion
            // 
            this.dtpFechaInicioEvaluacion.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFechaInicioEvaluacion.Location = new System.Drawing.Point(228, 57);
            this.dtpFechaInicioEvaluacion.Name = "dtpFechaInicioEvaluacion";
            this.dtpFechaInicioEvaluacion.Size = new System.Drawing.Size(167, 26);
            this.dtpFechaInicioEvaluacion.TabIndex = 26;
            this.dtpFechaInicioEvaluacion.Value = new System.DateTime(2020, 10, 19, 17, 18, 53, 0);
            this.dtpFechaInicioEvaluacion.ValueChanged += new System.EventHandler(this.dtpFechaInicioEvaluacion_ValueChanged);
            // 
            // lblFechaFinEvaluacion
            // 
            this.lblFechaFinEvaluacion.AutoSize = true;
            this.lblFechaFinEvaluacion.BackColor = System.Drawing.Color.Transparent;
            this.lblFechaFinEvaluacion.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFechaFinEvaluacion.ForeColor = System.Drawing.Color.Black;
            this.lblFechaFinEvaluacion.Location = new System.Drawing.Point(3, 142);
            this.lblFechaFinEvaluacion.Name = "lblFechaFinEvaluacion";
            this.lblFechaFinEvaluacion.Size = new System.Drawing.Size(108, 23);
            this.lblFechaFinEvaluacion.TabIndex = 21;
            this.lblFechaFinEvaluacion.Text = "Fecha Fin:";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.panel8.Controls.Add(this.label11);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel8.Location = new System.Drawing.Point(0, 0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(432, 50);
            this.panel8.TabIndex = 0;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(38)))), ((int)(((byte)(70)))));
            this.label11.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(2, 10);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(220, 28);
            this.label11.TabIndex = 20;
            this.label11.Text = "Etapa Evaluacion:";
            // 
            // lblFechaInicioEvaluacion
            // 
            this.lblFechaInicioEvaluacion.AutoSize = true;
            this.lblFechaInicioEvaluacion.BackColor = System.Drawing.Color.Transparent;
            this.lblFechaInicioEvaluacion.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFechaInicioEvaluacion.ForeColor = System.Drawing.Color.Black;
            this.lblFechaInicioEvaluacion.Location = new System.Drawing.Point(3, 57);
            this.lblFechaInicioEvaluacion.Name = "lblFechaInicioEvaluacion";
            this.lblFechaInicioEvaluacion.Size = new System.Drawing.Size(132, 23);
            this.lblFechaInicioEvaluacion.TabIndex = 20;
            this.lblFechaInicioEvaluacion.Text = "Fecha Inicio:";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.tabPage3.Controls.Add(this.panel9);
            this.tabPage3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage3.Location = new System.Drawing.Point(4, 32);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(735, 242);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "3.CALIBRACION";
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.tabPage4.Controls.Add(this.panel11);
            this.tabPage4.Location = new System.Drawing.Point(4, 32);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(735, 242);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "4.REPORTES";
            // 
            // frmConfigurarCronograma
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.ClientSize = new System.Drawing.Size(1221, 701);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnGuardar);
            this.Controls.Add(this.btnActualizar);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmConfigurarCronograma";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmConfigurarCronograma";
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnAtras)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button btnCronograma;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.LinkLabel btnCerrarSesion;
        private System.Windows.Forms.TextBox txtArea;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.TextBox txtCorreo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button btnCofigurarPesos;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.DateTimePicker dtpFechaNotificacionCalibracion;
        private System.Windows.Forms.Label lblFechaNotificacionCalibracion;
        private System.Windows.Forms.DateTimePicker dtpFechaInicioCalibracion;
        private System.Windows.Forms.Label lblFechaFinCalibracion;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblFechaInicioCalibracion;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.DateTimePicker dtpFechaNotificacionReportes;
        private System.Windows.Forms.DateTimePicker dtpFechaFinReportes;
        private System.Windows.Forms.Label lblFechaNotificacionReportes;
        private System.Windows.Forms.DateTimePicker dtpFechaInicioReportes;
        private System.Windows.Forms.Label lblFechaFinReportes;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label lblFechaInicioReportes;
        private System.Windows.Forms.Button btnActualizar;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.PictureBox btnAtras;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnCerrar;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.DateTimePicker dtpFechaNotificacionPlanificacion;
        private System.Windows.Forms.DateTimePicker dtpFechaFinPlanificacion;
        private System.Windows.Forms.Label lblFechaNotificacionPlanificacion;
        private System.Windows.Forms.DateTimePicker dtpFechaInicioPlanificacion;
        private System.Windows.Forms.Label lblFechaFinPlanificacion;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblFechaInicioPlanificacion;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.DateTimePicker dtpFechaNotificacionEvaluacion;
        private System.Windows.Forms.DateTimePicker dtpFechaFinEvaluacion;
        private System.Windows.Forms.Label lblFechaNotificacionEvaluacion;
        private System.Windows.Forms.DateTimePicker dtpFechaInicioEvaluacion;
        private System.Windows.Forms.Label lblFechaFinEvaluacion;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblFechaInicioEvaluacion;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.DateTimePicker dtpFechaFinCalibracion;
    }
}