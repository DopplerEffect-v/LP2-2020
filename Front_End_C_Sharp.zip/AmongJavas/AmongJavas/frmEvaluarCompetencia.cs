﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AmongJavas
{
    public partial class frmEvaluarCompetencia : Form
    {
        private NotaCriterioWS.NotaCriterioWSClient daoNotaCriterio;
        private NotaCriterioWS.notaCriterio notaCriterio;
        NotaCriterioWS.notaSubCriterio notaSubCriterioSeleccionada;
        BindingList<NotaCriterioWS.notaSubCriterio> lista;
        Estado estado;
        public frmEvaluarCompetencia(Estado estado,NotaCriterioWS.notaCriterio notaCriterio,String colaborador)
        {
            InitializeComponent();
            this.estado = estado;
            if (estado==Estado.Evaluar)
                dgvCompetencias.Columns[1].DataPropertyName = "notaEvaluador";
            txtId.Text = notaCriterio.linea_criterio.criterio.id_criterio.ToString();
            txtNombre.Text = notaCriterio.linea_criterio.criterio.nombre;
            txtDescripcion.Text = notaCriterio.linea_criterio.criterio.descripcion;
            txtColaborador.Text = colaborador;
            this.notaCriterio = notaCriterio;
            daoNotaCriterio = new NotaCriterioWS.NotaCriterioWSClient();
            //Llenar dataGridView
            if (notaCriterio.notasSubcriterios != null) { 
                lista = new BindingList<NotaCriterioWS.notaSubCriterio>(notaCriterio.notasSubcriterios);
                dgvCompetencias.AutoGenerateColumns = false;
                dgvCompetencias.DataSource = new BindingList<NotaCriterioWS.notaSubCriterio>(lista);
            }
            deshabilitaEtapa();
        }
        public void deshabilitaEtapa()
        {
            if (Program.cronograma.etapa != 1) //Si no es Evaluacion Etapa
            {
                btnGuardar.Visible = false;
                btnCancelar.Visible = false;
                dgvCompetencias.Columns[1].ReadOnly = true;
                panelIndi.Visible = false;
            }
        }
        private void btnCerrar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            double total = 0;
            double pesoTotal = 0;
            if (MessageBox.Show("¿Desea guardar las notas de las subcompetencias?", "Mensaje de confirmación", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                foreach (NotaCriterioWS.notaSubCriterio subnota in lista)
                {
                    if (estado == Estado.Evaluar)
                        total += subnota.notaEvaluador * subnota.subcriterio.peso;
                    else
                        total += subnota.notaEvaluado * subnota.subcriterio.peso;
                    pesoTotal += subnota.subcriterio.peso;
                }
                //Calcula nota total del criterio
                try
                {
                    if (estado == Estado.Evaluar)
                        notaCriterio.notaEvaluador = total / pesoTotal;
                    else
                        notaCriterio.notaEvaluado = total / pesoTotal;
                }
                catch(Exception ex)
                {
                    if (estado == Estado.Evaluar)
                        notaCriterio.notaEvaluador = 0;
                    else
                        notaCriterio.notaEvaluado = 0;
                }
                    
                daoNotaCriterio.actualizarNotasCriterio(notaCriterio);
                MessageBox.Show("Notas registradas", "Confirmación", MessageBoxButtons.OK);
                this.DialogResult = DialogResult.OK;
            }

        }

        private void btnVer_Click(object sender, EventArgs e)
        {
            notaSubCriterioSeleccionada = (NotaCriterioWS.notaSubCriterio)dgvCompetencias.CurrentRow.DataBoundItem;
            frmOscuro pp = new frmOscuro();
            pp.SetBounds(0, 0, this.Width, this.Height);
            pp.Show();
            frmGestionarSubcompetencia panelDetalle = new frmGestionarSubcompetencia(notaSubCriterioSeleccionada);
            panelDetalle.ShowDialog();
            pp.Close();
        }

        private void btnAtras_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

        private void dgvCompetencias_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            
        //    if (dgvCompetencias.RowCount>0) {
        //        String anterior = dgvCompetencias.CurrentRow.Cells[1].Value.ToString();
        //        String nuevo = anterior;
        //        if (!(nuevo=="0" || nuevo == "1" || nuevo == "2" || nuevo == "3" || nuevo == "4" || nuevo == "5"))
        //            MessageBox.Show("Vamos");
        //}

        }

        private void dgvCompetencias_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {

            if (e.ColumnIndex == 1) // 1 should be your column index
            {
                int i;
                String nuevo = Convert.ToString(e.FormattedValue);
                if (!int.TryParse(nuevo, out i) ||
                    !(nuevo == "0" || nuevo == "1" || nuevo == "2" || nuevo == "3" || nuevo == "4" || nuevo == "5"))
                {
                    e.Cancel = true;
                    MessageBox.Show("Ingrese un número del 0 al 5", "Nota Incorrecta", MessageBoxButtons.OK);
                }
                else
                {
                    // the input is numeric 
                }
            }

        }
    }
}
