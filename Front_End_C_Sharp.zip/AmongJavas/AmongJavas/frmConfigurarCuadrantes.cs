﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AmongJavas
{
    public partial class frmConfigurarCuadrantes : Form
    {
        private frmMenuPlanificacion _menuPlanificacion;
        private frmInicioSesion _panelInicioSesion;
        private EjesCuadranteWS.EjeCuadranteWSClient ejeDao;
        EjesCuadranteWS.ejesCuadrante eje;
        BindingList<EjesCuadranteWS.ejesCuadrante> lista;
        public frmConfigurarCuadrantes(Estado estado, frmMenuPlanificacion _menuPlanificacion,
            frmInicioSesion _panelInicioSesion)
        {
            InitializeComponent();
            establecerComponentes(estado);
            ejeDao = new EjesCuadranteWS.EjeCuadranteWSClient();
            this._menuPlanificacion = _menuPlanificacion;
            this._panelInicioSesion = _panelInicioSesion;

            txtNombre.Enabled = false;
            txtArea.Enabled = false;
            txtCorreo.Enabled = false;
            //carga cuadrantes
            try
            {
                lista = new BindingList<EjesCuadranteWS.ejesCuadrante>(ejeDao.listarEjesCuadrante(Program.periodo.id_Periodo));
            }catch(Exception ex) {
                lista = new BindingList<EjesCuadranteWS.ejesCuadrante>();
            }
            foreach(EjesCuadranteWS.ejesCuadrante eje in lista)
            {
                if (eje.ejex == "MEDIO" && eje.ejey == "B")
                {
                    txtLimiteInfY.Text = eje.limiteInferiorY.ToString();
                    txtLimiteSupY.Text = eje.limiteSuperiorY.ToString();
                    txtLimiteInfX.Text = eje.limiteInferiorX.ToString();
                    txtLimiteSupX.Text = eje.limiteSuperiorX.ToString();
                }
            }
            deshabilitaEtapa();

        }
        public void deshabilitaEtapa()
        {
            if (Program.cronograma.etapa != 0)
            {
                btnActualizar.Visible = false;
                btnGuardar.Visible = false;
                btnCancelar.Visible = false;
            }
        }
        void establecerComponentes(Estado estado)
        {
            switch (estado)
            {
                case Estado.Inicial:
                    txtLimiteInfX.Enabled = false;
                    txtLimiteSupX.Enabled = false;
                    txtLimiteInfY.Enabled = false;
                    txtLimiteSupY.Enabled = false;

                    habilitaBoton(btnActualizar, true);
                    habilitaBoton(btnGuardar, false);
                    habilitaBoton(btnCancelar, false);

                    break;

                case Estado.Actualizar:

                    txtLimiteInfX.Enabled = true;
                    txtLimiteSupX.Enabled = true;
                    txtLimiteInfY.Enabled = true;
                    txtLimiteSupY.Enabled = true;

                    habilitaBoton(btnActualizar, false);
                    habilitaBoton(btnGuardar, true);
                    habilitaBoton(btnCancelar, true);

                    break;
            }
        }
        private void habilitaBoton(Button boton, bool estado)
        {
            boton.Enabled = estado;
            if (estado == true)
                boton.BackColor = Color.FromArgb(46, 44, 51);
            if (estado == false)
                boton.BackColor = Color.FromArgb(246, 245, 247);

        }
        private void btnAtras_Click(object sender, EventArgs e)
        {
            this.Hide();
            _menuPlanificacion.Show();
        }

        private void btnCerrarSesion_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            _panelInicioSesion.Show();
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            establecerComponentes(Estado.Actualizar);
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                double infX,infY,supX,supY;
                infY = Double.Parse(txtLimiteInfY.Text);
                supY = Double.Parse(txtLimiteSupY.Text);
                infX = Double.Parse(txtLimiteInfX.Text);
                supX = Double.Parse(txtLimiteSupX.Text);
                if (!(infY<supY && infY>0 && supY < 100)){
                    MessageBox.Show("Limites del eje de Desempeño son incorrectos", "Mensaje de error", MessageBoxButtons.OK);
                }
                else if (!(infX < supX && infX > 0 && supX < 100))
                {
                    MessageBox.Show("Limites del eje de Potencial son incorrectos", "Mensaje de error", MessageBoxButtons.OK);
                }
                else if (MessageBox.Show("¿Desea registrar los Cuadrantes?", "Mensaje de confirmación", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    foreach (EjesCuadranteWS.ejesCuadrante eje in lista)
                    {
                        if (eje.ejey == "A")
                        {
                            eje.limiteInferiorY = Double.Parse(txtLimiteSupY.Text);
                            eje.limiteSuperiorY = 100;
                        }
                        else if (eje.ejey == "B")
                        {
                            eje.limiteInferiorY = Double.Parse(txtLimiteInfY.Text);
                            eje.limiteSuperiorY = Double.Parse(txtLimiteSupY.Text);
                        }
                        else if (eje.ejey == "C")
                        {
                            eje.limiteInferiorY = 0;
                            eje.limiteSuperiorY = Double.Parse(txtLimiteInfY.Text);
                        }
                        if (eje.ejex == "BAJO")
                        {
                            eje.limiteInferiorX = 0;
                            eje.limiteSuperiorX = Double.Parse(txtLimiteInfX.Text);
                        }
                        else if (eje.ejex == "MEDIO")
                        {
                            eje.limiteInferiorX = Double.Parse(txtLimiteInfX.Text);
                            eje.limiteSuperiorX = Double.Parse(txtLimiteSupX.Text);
                        }
                        else if (eje.ejex == "ALTO")
                        {
                            eje.limiteInferiorX = Double.Parse(txtLimiteSupX.Text);
                            eje.limiteSuperiorX = 100;
                        }
                        ejeDao.actualizarEjesCuadrante(eje);
                    }

                    MessageBox.Show("Cuadrantes registrados", "Confirmación", MessageBoxButtons.OK);
                    establecerComponentes(Estado.Inicial);
                }
            }catch{
                MessageBox.Show("Utilice números positivos dentro del rango de 0 a 100", "Manesaje de Error", MessageBoxButtons.OK);
            }
            
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            establecerComponentes(Estado.Inicial);
        }

        private void btnCupos_Click(object sender, EventArgs e)
        {
            this.Hide();

            frmConfigurarCuposMapaTalento panelConfCupos =
                new frmConfigurarCuposMapaTalento(Estado.Inicial,this._menuPlanificacion, this._panelInicioSesion);

            panelConfCupos.llenarUsuario();
            panelConfCupos.Show();
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        public void llenarUsuario()
        {
            txtNombre.Text = Program.colaborador.nombres + " " + Program.colaborador.apellidos;
            txtArea.Text = Program.colaborador.area.nombre;
            txtCorreo.Text = Program.colaborador.correo;
        }

        private void frmConfigurarCuadrantes_Load(object sender, EventArgs e)
        {

        }

        private void txtLimiteSupY_TextChanged(object sender, EventArgs e)
        {
            double numInf;
            double numSup;
            try
            {
                numInf = Double.Parse(txtLimiteInfY.Text);
                numSup = Double.Parse(txtLimiteSupY.Text);
                if (numInf > numSup) {
                    txtLimiteInfY.ForeColor = Color.Red;
                    txtLimiteSupY.ForeColor = Color.Red;
                }
                else
                {
                    txtLimiteInfY.ForeColor = Color.Black;
                    txtLimiteSupY.ForeColor = Color.Black;
                }

                if (numSup >= 100)
                    txtLimiteSupY.ForeColor = Color.Red;

            }
            catch (Exception ex)
            {
                txtLimiteSupY.ForeColor = Color.Red;
            }
        }

        private void txtLimiteInfY_TextChanged(object sender, EventArgs e)
        {
            double numInf;
            double numSup;
            try
            {
                numInf = Double.Parse(txtLimiteInfY.Text);
                numSup = Double.Parse(txtLimiteSupY.Text);
                
                if (numInf > numSup)
                {
                    txtLimiteInfY.ForeColor = Color.Red;
                    txtLimiteSupY.ForeColor = Color.Red;
                }
                else
                {
                    txtLimiteInfY.ForeColor = Color.Black;
                    txtLimiteSupY.ForeColor = Color.Black;
                }
                if (numInf <= 0)
                    txtLimiteInfY.ForeColor = Color.Red;

            }
            catch (Exception ex)
            {
                txtLimiteInfY.ForeColor = Color.Red;
            }
        }

        private void txtLimiteInfX_TextChanged(object sender, EventArgs e)
        {
            double numInf;
            double numSup;
            try
            {
                numInf = Double.Parse(txtLimiteInfX.Text);
                numSup = Double.Parse(txtLimiteSupX.Text);

                if (numInf > numSup)
                {
                    txtLimiteInfX.ForeColor = Color.Red;
                    txtLimiteSupX.ForeColor = Color.Red;
                }
                else
                {
                    txtLimiteInfX.ForeColor = Color.Black;
                    txtLimiteSupX.ForeColor = Color.Black;
                }
                if (numInf <= 0)
                    txtLimiteInfX.ForeColor = Color.Red;

            }
            catch (Exception ex)
            {
                txtLimiteInfX.ForeColor = Color.Red;
            }
        }

        private void txtLimiteSupX_TextChanged(object sender, EventArgs e)
        {
            double numInf;
            double numSup;
            try
            {
                numInf = Double.Parse(txtLimiteInfX.Text);
                numSup = Double.Parse(txtLimiteSupX.Text);
                if (numInf > numSup)
                {
                    txtLimiteInfX.ForeColor = Color.Red;
                    txtLimiteSupX.ForeColor = Color.Red;
                }
                else
                {
                    txtLimiteInfX.ForeColor = Color.Black;
                    txtLimiteSupX.ForeColor = Color.Black;
                }

                if (numSup >= 100)
                    txtLimiteSupX.ForeColor = Color.Red;

            }
            catch (Exception ex)
            {
                txtLimiteSupX.ForeColor = Color.Red;
            }
        }
    }
}
