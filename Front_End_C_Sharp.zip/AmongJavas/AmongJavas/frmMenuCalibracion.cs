﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AmongJavas
{
    public partial class frmMenuCalibracion : Form
    {
        private frmInicioSesion panelInicioSesion;
        private AreaWS.AreaWSClient daoArea;
        private AreaWS.area area;
        private EvaluacionTotalWS.EvaluacionTotalWSClient daoEvaluacion;
        private BindingList<EvaluacionTotalWS.evaluacionTotal> listaTotal;
        private BindingList<EvaluacionTotalWS.evaluacionTotal> listaA;
        private BindingList<EvaluacionTotalWS.evaluacionTotal> listaB;
        private BindingList<EvaluacionTotalWS.evaluacionTotal> listaC;
        private CuadranteWS.CuadranteWSClient daoCuadrante;
        public frmMenuCalibracion(frmInicioSesion panelInicioSesion)
        {
            InitializeComponent();

            txtNombre.Enabled = false;
            txtArea.Enabled = false;
            txtCorreo.Enabled = false;
            daoArea = new AreaWS.AreaWSClient();
            daoEvaluacion = new EvaluacionTotalWS.EvaluacionTotalWSClient();
            daoCuadrante = new CuadranteWS.CuadranteWSClient();
            this.panelInicioSesion = panelInicioSesion;
            llenarTabla();
            llenarUsuario();
            deshabilitarMenus();
            deshabilitaEtapa();
        }
        public void deshabilitaEtapa()
        {
            if (Program.cronograma.etapa < 2)   //Si aun no esta disponible
            {
                panelNoDisponible.Visible = true;
                lblFecha.Text = Program.cronograma.FECHA_INICIO_C.ToShortDateString();
            }
            else
                panelNoDisponible.Visible = false;

            if (Program.cronograma.etapa == 3)//Etapa de reporte
            {
                habilitaBoton(btnPreCalibrarArea,false);
                habilitaBoton(btnPrecalibrarTodasAreas,false);
            }
            else
            {
                habilitaBoton(btnPreCalibrarArea, true);
                habilitaBoton(btnPrecalibrarTodasAreas, true);
            }
            //Etapa
            switch (Program.cronograma.etapa)
            {
                case 0: txtEtapa.Text = "Planificación"; break;
                case 1: txtEtapa.Text = "Evaluación"; break;
                case 2: txtEtapa.Text = "Calibración"; break;
                case 3: txtEtapa.Text = "Reporte"; break;
                default: txtEtapa.Text = ""; break;
            }
            //Periodo
            txtPeriodo.Text = Program.periodo.fechaFin.Year.ToString();
        }
        private void habilitaBoton(Button boton, bool estado)
        {
            boton.Enabled = estado;
            if (estado == true)
                boton.BackColor = Color.FromArgb(46, 44, 51);
            if (estado == false)
                boton.BackColor = Color.FromArgb(246, 245, 247);

        }
        public void llenarTabla() 
        {
            dgvMisObjetivos.AutoGenerateColumns = false;
            try {
                dgvMisObjetivos.DataSource = new BindingList<AreaWS.area>
                  (daoArea.listarArea().ToArray());
            }catch(Exception ex)
            {
                dgvMisObjetivos.DataSource = null;
            }
                
        }
        public void deshabilitarMenus()
        {
            if (Program.colaborador.cuenta.permiso.permisoRRHH == false)
            {
                btnOjetivos.Location = new Point(0, 18);
                btnEvaluacion.Location = new Point(0, 68);
                btnReportes.Location = new Point(0, 118);
                pictureBox5.Location = new Point(10, 18);
                pictureBox4.Location = new Point(10, 68);
                pictureBox6.Location = new Point(10, 118);

                pictureBox3.Visible = false;
                pictureBox7.Visible = false;
                btnPlanificacion.Visible = false;
                btnCalibracion.Visible = false;
            }
            else
            {
                btnPlanificacion.Location = new Point(0, 18);
                btnOjetivos.Location = new Point(0, 68);
                btnEvaluacion.Location = new Point(0, 118);
                btnCalibracion.Location = new Point(0, 168);
                btnReportes.Location = new Point(0, 218);
                pictureBox3.Location = new Point(10, 18);
                pictureBox5.Location = new Point(10, 68);
                pictureBox4.Location = new Point(10, 118);
                pictureBox7.Location = new Point(10, 168);
                pictureBox6.Location = new Point(10, 218);

                pictureBox3.Visible = true;
                pictureBox7.Visible = true;
                btnPlanificacion.Visible = true;
                btnCalibracion.Visible = true;

            }
        }
        private void btnCerrarSesion_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Close();
            panelInicioSesion.Show();
        }

        private void btnPlanificacion_Click(object sender, EventArgs e)
        {
            this.Close();
            frmMenuPlanificacion panel = new frmMenuPlanificacion(panelInicioSesion);
            panel.Show();
        }

        private void btnOjetivos_Click(object sender, EventArgs e)
        {
            this.Close();
            frmMenuObjetivos panel = new frmMenuObjetivos(panelInicioSesion);
            panel.Show();
        }

        private void btnReportes_Click(object sender, EventArgs e)
        {
            this.Close();
            frmMenuReportes panel = new frmMenuReportes(panelInicioSesion);
            panel.Show();
        }

        private void btnEvaluacion_Click(object sender, EventArgs e)
        {
            this.Close();
            frmMenuEvaluacion panel = new frmMenuEvaluacion(panelInicioSesion);
            panel.Show();
        }

        private void btnVerMapaTalento_Click(object sender, EventArgs e)
        {
            frmMapaDeTalento panelMapaTalento =
                new frmMapaDeTalento(panelInicioSesion, this, Estado.Inicial);

            this.Hide();
            panelMapaTalento.llenarUsuario();
            panelMapaTalento.Show();
        }

        private void btnCalibrar_Click(object sender, EventArgs e)
        {
            frmMapaDeTalento panelMapaTalento =
                new frmMapaDeTalento(panelInicioSesion, this, Estado.Actualizar);

            this.Hide();
            panelMapaTalento.llenarUsuario();
            panelMapaTalento.Show();
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnPrecalibrarTodasAreas_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Desea realizar precalibración a todas las áreas?\nEste proceso es irreversible", "Mensaje de confirmación", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                BindingList<AreaWS.area> listaAreas = new BindingList<AreaWS.area> (daoArea.listarArea());
                foreach (AreaWS.area area in listaAreas)
                    precalibrarArea(area.id_Area);
                MessageBox.Show("Precalibración realizada a todas las áreas", "Confirmación", MessageBoxButtons.OK);
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
        public void llenarUsuario()
        {
            txtNombre.Text = Program.colaborador.nombres + " " + Program.colaborador.apellidos;
            txtArea.Text = Program.colaborador.area.nombre;
            txtCorreo.Text = Program.colaborador.correo;
        }

        private void precalibrarArea(int idArea)
        {
            int cuposA=0, cuposB=0;
            try
            {
                listaTotal = new BindingList<EvaluacionTotalWS.evaluacionTotal>(daoEvaluacion.listar_evaluaciones_Por_Area_Ordenado(idArea,Program.periodo.id_Periodo));
                listaA = new BindingList<EvaluacionTotalWS.evaluacionTotal>();
                listaB = new BindingList<EvaluacionTotalWS.evaluacionTotal>();
                listaC = new BindingList<EvaluacionTotalWS.evaluacionTotal>();

                foreach (EvaluacionTotalWS.evaluacionTotal eva in listaTotal)
                {
                    //Añade a la lista que pertenece
                    if (eva.calibracionAutomatica.ejes.ejey == "A")
                        listaA.Add(eva);
                    if (eva.calibracionAutomatica.ejes.ejey == "B")
                        listaB.Add(eva);
                    if (eva.calibracionAutomatica.ejes.ejey == "C")
                        listaC.Add(eva);
                }

                //Obtener cupos
                BindingList<CuadranteWS.cuadrante> listaCuadrantes = new BindingList<CuadranteWS.cuadrante>(daoCuadrante.listarCuadrante(idArea));
                foreach (CuadranteWS.cuadrante cuadrante in listaCuadrantes)
                {
                    if (cuadrante.ejes.ejey == "A" && cuadrante.ejes.ejex == "BAJO")
                        cuposA = cuadrante.cupos;
                    if (cuadrante.ejes.ejey == "B" && cuadrante.ejes.ejex == "BAJO")
                        cuposB = cuadrante.cupos;
                }
                //Calibra listaA
                BindingList<EvaluacionTotalWS.evaluacionTotal> listaConcatena = new BindingList<EvaluacionTotalWS.evaluacionTotal>();
                foreach (EvaluacionTotalWS.evaluacionTotal eva in listaA)
                {
                    if (cuposA > 0)
                        cuposA--;
                    else
                    {
                        //Agrego a lista auxiliar
                        listaConcatena.Add(eva);
                    }
                }
                //Concatena
                foreach (EvaluacionTotalWS.evaluacionTotal eva in listaB)
                    listaConcatena.Add(eva);

                CuadranteWS.cuadrante cuad;
                foreach (EvaluacionTotalWS.evaluacionTotal eva in listaConcatena)
                {
                    if (cuposB > 0) { 
                        cuposB--;
                        //Cambio cuadrante a B
                        eva.calibracionAutomatica.ejes.ejey = "B";
                    }
                    else
                    {
                        //Cambio cuadrante a C
                        eva.calibracionAutomatica.ejes.ejey = "C";
                    }
                    //Obtiene cuadrantes
                    foreach (CuadranteWS.cuadrante cuadrante in listaCuadrantes)
                    {
                        if (cuadrante.ejes.ejey == eva.calibracionAutomatica.ejes.ejey && cuadrante.ejes.ejex == eva.calibracionAutomatica.ejes.ejex)
                            eva.calibracionAutomatica.id_cuadrante = cuadrante.id_cuadrante;
                    }
                    daoEvaluacion.actualizarCortoEvaluacion(eva);
                }


            }
            catch(Exception ex)
            {

            }
        }
        private void ordenaLista(BindingList<EvaluacionTotalWS.evaluacionTotal> lista) 
        {
            EvaluacionTotalWS.evaluacionTotal temp;
            for (int i=0; i < lista.Count; i++)
            {
                for (int j = 1; j < lista.Count - 1; j++)
                {
                    if (lista[i].notaCompEvaluador < lista[j].notaCompEvaluador)
                    {
                        temp = lista[i];
                        lista[j] = lista[i];
                        lista[i] = temp;
                    }
                }
            }
        }
        private void btnPreCalibrarArea_Click(object sender, EventArgs e)
        {
            if (dgvMisObjetivos.RowCount > 0)
            {
                area = (AreaWS.area)dgvMisObjetivos.CurrentRow.DataBoundItem;
                if (MessageBox.Show("¿Desea realizar el precalibrado al área "+area.nombre+"?", "Mensaje de confirmación", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    precalibrarArea(area.id_Area);
                    MessageBox.Show("Precalibración realizada con éxito", "Confirmación", MessageBoxButtons.OK);
                }
            }
        }

    }
}
