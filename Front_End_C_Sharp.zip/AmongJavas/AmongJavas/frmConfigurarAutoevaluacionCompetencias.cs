﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AmongJavas
{
    public partial class frmConfigurarAutoevaluacionCompetencias : Form
    {
        private frmInicioSesion panelInicioSesion;
        private frmMenuEvaluacion menuEvaluacion;
        private NotaCriterioWS.NotaCriterioWSClient daoNota;
        private NotaCriterioWS.notaCriterio notaSeleccionada;
        public frmConfigurarAutoevaluacionCompetencias(frmInicioSesion panelInicioSesion, frmMenuEvaluacion menuEvaluacion)
        {
            InitializeComponent();
            this.panelInicioSesion = panelInicioSesion;
            this.menuEvaluacion = menuEvaluacion;
            daoNota = new NotaCriterioWS.NotaCriterioWSClient();
            llenarTabla();
            deshabilitaEtapa();
        }
        public void deshabilitaEtapa()
        {
            if (Program.cronograma.etapa != 1) //No es etapa Evaluacion
            {
                panelIndi.Visible = false;
            }
        }
        private void llenarTabla()
        {
            dgvCompetencias.AutoGenerateColumns = false;
            if (daoNota.listarNotaPorColaborador(Program.colaborador.idColaborador, 1) != null)
                dgvCompetencias.DataSource = new BindingList<NotaCriterioWS.notaCriterio>
                    (daoNota.listarNotaPorColaborador(Program.colaborador.idColaborador, 1).ToArray());
            else
                dgvCompetencias.DataSource = null;
        }
        private void btnAtras_Click(object sender, EventArgs e)
        {
            this.menuEvaluacion.Show();
            this.Close();
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnCerrarSesion_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.panelInicioSesion.Show();
            this.Close();
        }

        private void btnEvaluarObjetivos_Click(object sender, EventArgs e)
        {
            frmConfigurarAutoevaluacionObjetivos panelVecino =
                new frmConfigurarAutoevaluacionObjetivos(this.panelInicioSesion, this.menuEvaluacion);

            panelVecino.llenarUsuario();
            panelVecino.Show();
            this.Close();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {

            if (dgvCompetencias.RowCount > 0)
            {
                notaSeleccionada = (NotaCriterioWS.notaCriterio)dgvCompetencias.CurrentRow.DataBoundItem;
                frmOscuro pp = new frmOscuro();
                pp.SetBounds(0, 0, this.Width, this.Height);
                pp.Show();
                frmEvaluarCompetencia panelEvaluacion = new frmEvaluarCompetencia(Estado.Autoevaluar,notaSeleccionada,Program.colaborador.nombreCompleto);
                if (panelEvaluacion.ShowDialog() == DialogResult.OK)
                {

                }
                llenarTabla();
                pp.Close();
            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Desea registrar la Autoevaluación?", "Mensaje de confirmación", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                MessageBox.Show("Autoevaluación registrada", "Confirmación", MessageBoxButtons.OK);
            }
        }
        public void llenarUsuario()
        {
            txtNombre.Text = Program.colaborador.nombres + " " + Program.colaborador.apellidos;
            txtArea.Text = Program.colaborador.area.nombre;
            txtCorreo.Text = Program.colaborador.correo;
        }
    }
}
