﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AmongJavas
{
    public partial class frmMenuObjetivos : Form
    {

        private frmInicioSesion panelInicioSesion;
        private ObjetivoWS.ObjetivoWSClient daoObjetivo;
        private ColaboradorWS.ColaboradorWSClient daoColaborador;
        private ObjetivoWS.objetivo objetivoSeleccionado;
        private CorreosWS.CorreosWSClient daoCorreo;
        public frmMenuObjetivos(frmInicioSesion panelInicioSesion)
        {
            InitializeComponent();

            txtNombre.Enabled = false;
            txtArea.Enabled = false;
            txtCorreo.Enabled = false;

            this.panelInicioSesion = panelInicioSesion;
            daoObjetivo = new ObjetivoWS.ObjetivoWSClient();
            daoColaborador = new ColaboradorWS.ColaboradorWSClient();
            daoCorreo = new CorreosWS.CorreosWSClient();
            objetivoSeleccionado = null;
            habilitaBoton(btnEliminar, false);
            llenarUsuario();
            llenarTablaMisObjetivos();
            llenarEmpleados();
            deshabilitarBotones();
            deshabilitarMenus();
            deshabilitaEtapa();
        }
        public void deshabilitaEtapa()
        {
            if (Program.cronograma.etapa != 0)
            {
                btnAñadir.Visible = false;
                btnEliminar.Visible = false;
                btnFinalizarMis.Visible = false;
                btnFinalizarRev.Visible = false;
                btnRevisar.Text = "Ver";
            }
            else
            {
                btnAñadir.Visible = true;
                btnEliminar.Visible = true;
                btnFinalizarMis.Visible = true;
                btnFinalizarRev.Visible = true;
                btnRevisar.Text = "Revisar";
            }
            //Etapa
            switch (Program.cronograma.etapa)
            {
                case 0: txtEtapa.Text = "Planificación"; break;
                case 1: txtEtapa.Text = "Evaluación"; break;
                case 2: txtEtapa.Text = "Calibración"; break;
                case 3: txtEtapa.Text = "Reporte"; break;
                default: txtEtapa.Text = ""; break;
            }
            //Periodo
            txtPeriodo.Text = Program.periodo.fechaFin.Year.ToString();
        }
        public void llenarTablaMisObjetivos()
        {
            dgvMisObjetivos.AutoGenerateColumns = false;

            if (daoObjetivo.listarPorColaborador_Y_Periodo(Program.colaborador.idColaborador, Program.periodo.id_Periodo, "") != null) { 
                dgvMisObjetivos.DataSource = new BindingList<ObjetivoWS.objetivo>
                    (daoObjetivo.listarPorColaborador_Y_Periodo(Program.colaborador.idColaborador, Program.periodo.id_Periodo, "").ToArray());
            }
            else
                dgvMisObjetivos.DataSource = null;

        }
        public void llenarEmpleados()
        {
            ObjetivoWS.colaborador cc;
            cbEmpleados.ValueMember = "idColaborador";
            cbEmpleados.DisplayMember = "nombreCompleto";
            cbEmpleados.DataSource = daoColaborador.listar_subordinados(Program.colaborador.idColaborador);
        }
        public void deshabilitarBotones()
        {
            if (Program.colaborador.cuenta.permiso.permisoJefe == false)
            {
                panelRev.Visible = false;
                panelMis.Height = 320;
            }
            else
            {
                panelRev.Visible = true;
                panelMis.Height = 156;
            }
            if (daoColaborador.buscarJefe(Program.colaborador.idColaborador) == null)
            {
                panelMis.Visible = false;
                panelRev.Location = new Point(220, 130);
                panelRev.Height = 320;
                dgvRevisar.Height = 265;
            }
            else
            {
                panelMis.Visible = true;
                panelRev.Location = new Point(220, 290);
                panelRev.Height = 156;
                dgvRevisar.Height = 101;
            }
               
        }
        public void deshabilitarMenus()
        {
            if (Program.colaborador.cuenta.permiso.permisoRRHH == false)
            {
                btnOjetivos.Location = new Point(0, 18);
                btnEvaluacion.Location = new Point(0,68);
                btnReportes.Location = new Point(0, 118);
                pictureBox5.Location = new Point(10, 18);
                pictureBox4.Location = new Point(10, 68);
                pictureBox6.Location = new Point(10, 118);

                pictureBox3.Visible = false;
                pictureBox7.Visible = false;
                btnPlanificacion.Visible = false;
                btnCalibracion.Visible = false;
            }
            else
            {
                btnPlanificacion.Location = new Point(0, 18);
                btnOjetivos.Location = new Point(0, 68);
                btnEvaluacion.Location = new Point(0, 118);
                btnCalibracion.Location = new Point(0, 168);
                btnReportes.Location = new Point(0, 218);
                pictureBox3.Location = new Point(10, 18);
                pictureBox5.Location = new Point(10, 68);
                pictureBox4.Location = new Point(10, 118);
                pictureBox7.Location = new Point(10, 168);
                pictureBox6.Location = new Point(10, 218);

                pictureBox3.Visible = true;
                pictureBox7.Visible = true;
                btnPlanificacion.Visible = true;
                btnCalibracion.Visible = true;

            }
        }
        private void llenarTablarevisar()
        {
            if (cbEmpleados.DataSource != null)
            {
                ColaboradorWS.colaborador cola = (ColaboradorWS.colaborador)cbEmpleados.SelectedItem;
                dgvRevisar.AutoGenerateColumns = false;
                if (daoObjetivo.listarPorColaborador_Y_Periodo(cola.idColaborador, Program.periodo.id_Periodo, "") != null)
                {
                    BindingList<ObjetivoWS.objetivo> listaObjetivos, listaTemp;
                    listaTemp = new BindingList<ObjetivoWS.objetivo>(daoObjetivo.listarPorColaborador_Y_Periodo(cola.idColaborador, Program.periodo.id_Periodo, "").ToArray());
                    listaObjetivos = new BindingList<ObjetivoWS.objetivo>();
                    foreach (ObjetivoWS.objetivo obj in listaTemp)
                    {
                        if (obj.estado > 0)
                            listaObjetivos.Add(obj);
                    }
                    dgvRevisar.DataSource = listaObjetivos;
                }
                else
                    dgvRevisar.DataSource = null;
            }
            else
                dgvRevisar.DataSource = null;

        }
        private void btnPlanificacion_Click(object sender, EventArgs e)
        {
            this.Close();
            frmMenuPlanificacion panel = new frmMenuPlanificacion(panelInicioSesion);
            panel.Show();
        }

        private void btnCerrarSesion_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Close();
            panelInicioSesion.Show();
           
        }

        private void btnEvaluacion_Click(object sender, EventArgs e)
        {
            this.Close();
            frmMenuEvaluacion panel = new frmMenuEvaluacion(panelInicioSesion);
            panel.Show();
        }

        private void btnCalibracion_Click(object sender, EventArgs e)
        {
            this.Close();
            frmMenuCalibracion panel = new frmMenuCalibracion(panelInicioSesion);
            panel.Show();
        }

        private void btnReportes_Click(object sender, EventArgs e)
        {
            this.Close();
            frmMenuReportes panel = new frmMenuReportes(panelInicioSesion);
            panel.Show();
        }

        private void btnAñadir_Click(object sender, EventArgs e)
        {
            frmOscuro pp = new frmOscuro();
            pp.SetBounds(0, 0, this.Width, this.Height);
            pp.Show();
            frmGestionarObjetivos panelGestionarObjetivos = new frmGestionarObjetivos(AmongJavas.Estado.Nuevo);
            if (panelGestionarObjetivos.ShowDialog() == DialogResult.OK)
            {

            }
            llenarTablaMisObjetivos();
            pp.Close();
        }

        private void btnVerObjetivo_Click(object sender, EventArgs e)
        {
            if (dgvMisObjetivos.RowCount > 0)
            {
                objetivoSeleccionado = (ObjetivoWS.objetivo)dgvMisObjetivos.CurrentRow.DataBoundItem;
                frmOscuro pp = new frmOscuro();
                pp.SetBounds(0, 0, this.Width, this.Height);
                pp.Show();
                frmGestionarObjetivos panelGestionarObjetivos = new frmGestionarObjetivos(AmongJavas.Estado.Inicial, objetivoSeleccionado);
                if (panelGestionarObjetivos.ShowDialog() == DialogResult.OK)
                {

                }
                llenarTablaMisObjetivos();
                pp.Close();
            }
        }

        private void btnRevisar_Click(object sender, EventArgs e)
        {
            if (dgvRevisar.RowCount > 0)
            {
                objetivoSeleccionado = (ObjetivoWS.objetivo)dgvRevisar.CurrentRow.DataBoundItem;
                ColaboradorWS.colaborador cola = (ColaboradorWS.colaborador)cbEmpleados.SelectedItem;
                frmOscuro pp = new frmOscuro();
                pp.SetBounds(0, 0, this.Width, this.Height);
                pp.Show();
                frmGestionarObjetivos panelGestionarObjetivos;
                if (Program.cronograma.etapa==0)
                    panelGestionarObjetivos = new frmGestionarObjetivos(AmongJavas.Estado.Revisar,objetivoSeleccionado, cola.nombreCompleto);
                else
                    panelGestionarObjetivos = new frmGestionarObjetivos(AmongJavas.Estado.Inicial, objetivoSeleccionado, cola.nombreCompleto);
                if (panelGestionarObjetivos.ShowDialog() == DialogResult.OK)
                {

                }
                llenarTablarevisar();
                pp.Close();
            }
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dgvMisObjetivos.RowCount > 0)
            {
                objetivoSeleccionado = (ObjetivoWS.objetivo)dgvMisObjetivos.CurrentRow.DataBoundItem;
                if (objetivoSeleccionado.estado==1 || objetivoSeleccionado.estado==3)
                    MessageBox.Show("No se puede eliminar un objetivo con estado "+objetivoSeleccionado.etiqueta, "Confirmación", MessageBoxButtons.OK);
                else
                if (MessageBox.Show("¿Desea eliminar el Objetivo?", "Mensaje de confirmación", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    daoObjetivo.eliminarObjetivo(objetivoSeleccionado);
                    llenarTablaMisObjetivos();
                    MessageBox.Show("Objetivo eliminado", "Confirmación", MessageBoxButtons.OK);
                    habilitaBoton(btnEliminar, false);
                    dgvMisObjetivos.ClearSelection();
                }
            }
        }

        private void habilitaBoton(Button boton, bool estado)
        {
            boton.Enabled = estado;
            if (estado == true)
                boton.BackColor = Color.FromArgb(46, 44, 51);
            if (estado == false)
                boton.BackColor = Color.FromArgb(246, 245, 247);

        }
        public void llenarUsuario()
        {
            txtNombre.Text = Program.colaborador.nombres + " " + Program.colaborador.apellidos;
            txtArea.Text = Program.colaborador.area.nombre;
            txtCorreo.Text = Program.colaborador.correo;
        }

        private void cbEmpleados_SelectedIndexChanged(object sender, EventArgs e)
        {
            llenarTablarevisar();
        }

        private void btnFinalizarRev_Click(object sender, EventArgs e)
        {
            
            
            ColaboradorWS.colaborador subordinado = (ColaboradorWS.colaborador)cbEmpleados.SelectedItem;
            if (MessageBox.Show("¿Desea terminar la revisión?\nSe enviará un correo a " + subordinado.nombres+" "+subordinado.apellidos ,
                "Mensaje de confirmación", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                int numApro = 0, numDesa = 0;
                String sA = "s",sD="s";
                BindingList<ObjetivoWS.objetivo> lista;
                lista = (BindingList<ObjetivoWS.objetivo>)dgvRevisar.DataSource;
                foreach (ObjetivoWS.objetivo objetivo in lista)
                {
                    if (objetivo.estado == 2)
                        numDesa++;
                    if (objetivo.estado == 1)
                        numApro++;
                }
                if (numApro == 1)
                    sA = "";
                if (numDesa == 1)
                    sD = "";
                String titulo = "Revisión de Objetivos";
                String correo = "Estimado Sr / Sra " + subordinado.nombreCompleto + ",\n\n" +
                    "Se le notifica que el Sr/ Sra " + Program.colaborador.nombreCompleto + " finalizó con la revisión de sus objetivos formulados. En total, hay " + numApro.ToString() + " objetivo" + sA + " aprobado" + sA + " y " + numDesa.ToString() + " objetivo" + sD + " denegado" + sD + ".";
                if (numDesa > 0)
                    correo += " Se le solicita la revisión de dichos objetivos para que puedan ser nuevamente evaluados por su jefe.";
                correo += "\n\nAsimismo, a manera de recordatorio, se le comunica que la etapa de Planificación de Objetivos tiene como fecha límite el día " + Program.cronograma.FECHA_FIN_P.ToShortDateString()+ ".\n\n" +
                    "Por favor tomar las medidas y decisiones responsablemente.\n\n" +
                    "ATTE\n\n" +
                    "Área de Gestión de Recursos Humanos\n";
                daoCorreo.enviarNotificacion(subordinado.correo, titulo, correo);
                //daoCorreo.enviarNotificacion("a20170910@pucp.edu.pe", titulo, correo);
                MessageBox.Show("Revisión enviada", "Confirmación", MessageBoxButtons.OK);
            }
        }

        private void btnFinalizarMis_Click(object sender, EventArgs e)
        {
            ColaboradorWS.colaborador jefe = daoColaborador.buscarJefe(Program.colaborador.idColaborador);
            if (MessageBox.Show("¿Desea terminar el ingreso de objetivos?\nSe enviará un correo a " + jefe.nombres + " " + jefe.apellidos,
                "Mensaje de confirmación", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                int num = 0;
                BindingList<ObjetivoWS.objetivo> lista;
                lista = (BindingList<ObjetivoWS.objetivo>)dgvMisObjetivos.DataSource;
                foreach (ObjetivoWS.objetivo objetivo in lista)
                {
                    if (objetivo.estado == 0) {
                        objetivo.estado = 3;
                        daoObjetivo.actualizarObjetivo(objetivo);
                        num++;
                    }
                }
                if (num > 0)
                {
                    String titulo = "Formulación de Objetivos";
                    String correo = "Estimado Sr/ Sra " + jefe.nombreCompleto +",\n\n" +
                        "Se le notifica que el Sr/ Sra " + Program.colaborador.nombreCompleto + " finalizó con el planteamiento/ corrección de sus objetivos. En total, hay " + num.ToString() + " objetivos disponibles para su revisión.\n\n" +
                        "Asimismo, a manera de recordatorio, se le comunica que la etapa de Planificación de Objetivos tiene como fecha límite el día "+Program.cronograma.FECHA_FIN_P.Date.ToShortDateString()+".\n\n" +
                        "Por favor tomar las medidas y decisiones responsablemente.\n\n" +
                        "ATTE\n\n" +
                        "Área de Gestión de Recursos Humanos\n";
                    daoCorreo.enviarNotificacion(jefe.correo, titulo, correo);
                    //daoCorreo.enviarNotificacion("a20170910@pucp.edu.pe", titulo, correo);
                    MessageBox.Show("Notificación de Objetivos enviados", "Confirmación", MessageBoxButtons.OK);
                    llenarTablaMisObjetivos();
                }
                else
                {
                    MessageBox.Show("Usted no tiene objetivos por revisar", "Mensaje Error", MessageBoxButtons.OK);
                }
            }
        }

        private void dgvMisObjetivos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            objetivoSeleccionado = (ObjetivoWS.objetivo)dgvMisObjetivos.CurrentRow.DataBoundItem;
            if (objetivoSeleccionado.estado == 1 || objetivoSeleccionado.estado == 3)
                habilitaBoton(btnEliminar, false);
            else
                habilitaBoton(btnEliminar, true);
        }
    }
}
