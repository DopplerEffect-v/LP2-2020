﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AmongJavas
{
    public partial class frmGestionarObjetivos : Form
    {
        private ObjetivoWS.ObjetivoWSClient daoObjetivo;
        private ObjetivoWS.objetivo objetivo;
        private Estado estado;
        private double nota;
        private double notaAuto;
        public frmGestionarObjetivos(Estado estado)
        {
            InitializeComponent();
            this.estado = estado;
            daoObjetivo = new ObjetivoWS.ObjetivoWSClient();
            objetivo = new ObjetivoWS.objetivo();
            establecerComponentesInicial(estado);
            establecerComponentes(estado);
        }

        public frmGestionarObjetivos(Estado estado,ObjetivoWS.objetivo objetivo)
        {
            InitializeComponent();
            this.estado = estado;
            daoObjetivo = new ObjetivoWS.ObjetivoWSClient();
            this.objetivo = objetivo;
            establecerComponentesInicial(estado);
            establecerComponentes(estado);

            if (estado != Estado.Nuevo)
            {
                txtId.Text = objetivo.idObjetivo.ToString();
                txtDescripcion.Text = objetivo.descripcion;
                txtMeta.Text = objetivo.meta.ToString();
                txtUnidades.Text = objetivo.unidad_meta;
                txtObservaciones.Text = objetivo.observaciones;
                if (objetivo.estado == 0)
                    cbGenerado.Checked = true;
                else if (objetivo.estado == 1)
                    cbAprobado.Checked = true;
                else if (objetivo.estado == 2)
                    cbDenegado.Checked = true;
            }
            deshabilitaEtapa();
        }
        public frmGestionarObjetivos(Estado estado, ObjetivoWS.objetivo objetivo,String colaborador)
        {
            InitializeComponent();
            this.estado = estado;
            daoObjetivo = new ObjetivoWS.ObjetivoWSClient();
            this.objetivo = objetivo;
            txtColaborador.Visible = true;
            txtColaborador.Text = colaborador;
            label3.Visible = true;
            establecerComponentesInicial(estado);
            if (estado==Estado.Revisar)
                establecerComponentes(Estado.Inicial);
            else
                establecerComponentes(estado);

            if (estado != Estado.Nuevo)
            {
                txtId.Text = objetivo.idObjetivo.ToString();
                txtDescripcion.Text = objetivo.descripcion;
                txtMeta.Text = objetivo.meta.ToString();
                txtUnidades.Text = objetivo.unidad_meta;
                txtObservaciones.Text = objetivo.observaciones;
                if (objetivo.estado == 0 || objetivo.estado == 3)
                    cbGenerado.Checked = true;
                else if (objetivo.estado == 1)
                    cbAprobado.Checked = true;
                else if (objetivo.estado == 2)
                    cbDenegado.Checked = true;
            }
            deshabilitaEtapa();
        }
        public void deshabilitaEtapa()
        {
            if (!(Program.cronograma.etapa == 1 && (estado==Estado.Evaluar || estado==Estado.Autoevaluar))) //
                if (Program.cronograma.etapa != 0) //Si no es etapa de planificacion
                {
                    btnEditar.Visible = false;
                    btnGuardar.Visible = false;
                    btnCancelar.Visible = true;
                    btnCancelar.Text = "Cerrar";
                    txtLogroEvaluador.Enabled = false;
                    txtLogroPersonal.Enabled = false;
                }
        }

        
        public void establecerComponentesInicial(Estado estado)
        {
            switch (estado)
            {
                case Estado.Nuevo:
                    //btnCancelar.Visible = false;
                    btnEditar.Visible = false;

                    lblEstado.Visible = false;
                    lblLogro.Visible = false;
                    lblLogroPer.Visible = false;
                    lblNota.Visible = false;
                    lblNotaAuto.Visible = false;
                    txtLogroEvaluador.Visible = false;
                    txtLogroPersonal.Visible = false;
                    txtNota.Visible = false;
                    txtNotaAuto.Visible = false;

                    cbGenerado.Visible = false;
                    cbAprobado.Visible = false;
                    cbDenegado.Visible = false;

                    this.Height = this.Height - 50;
                    btnEditar.Location = new Point(btnEditar.Location.X, btnEditar.Location.Y - 50);
                    btnGuardar.Location = new Point(btnGuardar.Location.X, btnGuardar.Location.Y - 50);
                    btnCancelar.Location = new Point(btnCancelar.Location.X, btnCancelar.Location.Y - 50);
                    break;

                case Estado.Inicial:
                    lblEstado.Visible = true;
                    lblLogro.Visible = false;
                    lblLogroPer.Visible = false;
                    lblNota.Visible = false;
                    lblNotaAuto.Visible = false;
                    txtLogroEvaluador.Visible = false;
                    txtLogroPersonal.Visible = false;
                    txtNota.Visible = false;
                    txtNotaAuto.Visible = false;
                    if (objetivo.estado == 1 || objetivo.estado == 3) //aprobado o enviado
                    {
                        btnEditar.Visible = false;
                        btnGuardar.Visible = false;
                        btnCancelar.Visible = true;
                        btnCancelar.Text = "Cerrar";
                    }
                    cbGenerado.Enabled = false;
                    cbAprobado.Enabled = false;
                    cbDenegado.Enabled = false;
                    this.Height = this.Height - 50;
                    btnEditar.Location = new Point(btnEditar.Location.X, btnEditar.Location.Y - 50);
                    btnGuardar.Location = new Point(btnGuardar.Location.X, btnGuardar.Location.Y - 50);
                    btnCancelar.Location = new Point(btnCancelar.Location.X, btnCancelar.Location.Y - 50);
                    break;

                case Estado.Actualizar:
                    lblEstado.Visible = false;
                    lblLogro.Visible = false;
                    lblLogroPer.Visible = false;
                    lblNota.Visible = false;
                    lblNotaAuto.Visible = false;
                    txtLogroEvaluador.Visible = false;
                    txtLogroPersonal.Visible = false;
                    txtNota.Visible = false;
                    txtNotaAuto.Visible = false;

                    cbGenerado.Visible = false;
                    cbAprobado.Visible = false;
                    cbDenegado.Visible = false;

                    this.Height = this.Height - 50;
                    btnEditar.Location = new Point(btnEditar.Location.X, btnEditar.Location.Y - 50);
                    btnGuardar.Location = new Point(btnGuardar.Location.X, btnGuardar.Location.Y - 50);
                    btnCancelar.Location = new Point(btnCancelar.Location.X, btnCancelar.Location.Y - 50);
                    break;

                case Estado.Revisar:
                    //btnCancelar.Visible = false;

                    lblLogro.Visible = false;
                    lblLogroPer.Visible = false;
                    lblNota.Visible = false;
                    lblNotaAuto.Visible = false;
                    txtLogroEvaluador.Visible = false;
                    txtLogroPersonal.Visible = false;
                    txtNota.Visible = false;
                    txtNotaAuto.Visible = false;
                    if (objetivo.estado == 1 || objetivo.estado == 2) //aprobado o denegado
                    {
                        btnEditar.Visible = false;
                        btnGuardar.Visible = false;
                        btnCancelar.Visible = true;
                        btnCancelar.Text = "Cerrar";
                    }
                    this.Height = this.Height - 50;
                    btnEditar.Location = new Point(btnEditar.Location.X, btnEditar.Location.Y - 50);
                    btnGuardar.Location = new Point(btnGuardar.Location.X, btnGuardar.Location.Y - 50);
                    btnCancelar.Location = new Point(btnCancelar.Location.X, btnCancelar.Location.Y - 50);
                    break;

                case Estado.Autoevaluar:
                    lblEstado.Visible = false;
                    cbGenerado.Visible = false;
                    cbAprobado.Visible = false;
                    cbDenegado.Visible = false;

                    txtLogroEvaluador.Visible = false;
                    txtNota.Visible = false;
                    lblNota.Visible = false;
                    lblLogro.Visible = false;

                    lblUnidad.Location = new Point(lblNota.Location.X, lblMeta.Location.Y);
                    lblMedida.Location = new Point(lblNota.Location.X, lblCantidad.Location.Y);
                    txtUnidades.Location = new Point(txtNota.Location.X, txtMeta.Location.Y);

                    habilitaBoton(btnEditar, false);
                    btnEditar.Visible = false;
                    habilitaBoton(btnGuardar, true);
                    habilitaBoton(btnCancelar, true);

                    this.Height = this.Height - 60;
                    btnEditar.Location = new Point(btnEditar.Location.X, btnEditar.Location.Y - 60);
                    btnGuardar.Location = new Point(btnGuardar.Location.X, btnGuardar.Location.Y - 60);
                    btnCancelar.Location = new Point(btnCancelar.Location.X, btnCancelar.Location.Y - 60);

                    lblLogroPer.Location = new Point(lblLogroPer.Location.X, lblLogroPer.Location.Y - 40);
                    txtLogroPersonal.Location = new Point(txtLogroPersonal.Location.X, txtLogroPersonal.Location.Y - 40);
                    lblNotaAuto.Location = new Point(lblNotaAuto.Location.X, lblNotaAuto.Location.Y - 40);
                    txtNotaAuto.Location = new Point(txtNotaAuto.Location.X, txtNotaAuto.Location.Y - 40);

                    txtLogroPersonal.Text = objetivo.logroEvaluado.ToString();
                    break;

                case Estado.Evaluar:
                    lblEstado.Visible = false;
                    cbGenerado.Visible = false;
                    cbAprobado.Visible = false;
                    cbDenegado.Visible = false;

                    txtLogroPersonal.Visible = false;
                    txtNotaAuto.Visible = false;
                    lblNotaAuto.Visible = false;
                    lblLogroPer.Visible = false;

                    lblUnidad.Location = new Point(lblNota.Location.X, lblMeta.Location.Y);
                    lblMedida.Location = new Point(lblNota.Location.X, lblCantidad.Location.Y);
                    txtUnidades.Location = new Point(txtNota.Location.X, txtMeta.Location.Y);

                    habilitaBoton(btnEditar, false);
                    btnEditar.Visible = false;
                    habilitaBoton(btnGuardar, true);
                    habilitaBoton(btnCancelar, true);

                    this.Height = this.Height - 60;
                    btnEditar.Location = new Point(btnEditar.Location.X, btnEditar.Location.Y - 60);
                    btnGuardar.Location = new Point(btnGuardar.Location.X, btnGuardar.Location.Y - 60);
                    btnCancelar.Location = new Point(btnCancelar.Location.X, btnCancelar.Location.Y - 60);

                    lblLogro.Location = new Point(lblLogro.Location.X, lblLogro.Location.Y - 70);
                    txtLogroEvaluador.Location = new Point(txtLogroEvaluador.Location.X, txtLogroEvaluador.Location.Y - 70);
                    lblNota.Location = new Point(lblNota.Location.X, lblNota.Location.Y - 70);
                    txtNota.Location = new Point(txtNota.Location.X, txtNota.Location.Y - 70);

                    txtLogroEvaluador.Text = objetivo.logroEvaluador.ToString();
                    break;
            }
        }
        public void establecerComponentes(Estado estado)
        {
            switch (estado)
            {
                case Estado.Nuevo:
                    txtId.Enabled = false;
                    txtDescripcion.Enabled = true;
                    txtObservaciones.Enabled = false;
                    txtMeta.Enabled = true;
                    txtUnidades.Enabled = true;

                    habilitaBoton(btnEditar, false);
                    habilitaBoton(btnGuardar, true);

                    break;

                case Estado.Inicial:
                    txtId.Enabled = false;
                    txtDescripcion.Enabled = false;
                    txtObservaciones.Enabled = false;
                    txtMeta.Enabled = false;
                    txtUnidades.Enabled = false;

                    habilitaBoton(btnEditar, true);
                    habilitaBoton(btnGuardar, false);
                    //habilitaBoton(btnCancelar, false);
                    break;

                case Estado.Actualizar:
                    txtId.Enabled = false;
                    txtDescripcion.Enabled = true;
                    txtObservaciones.Enabled = false;
                    txtMeta.Enabled = true;
                    txtUnidades.Enabled = true;
                    if (estado == Estado.Revisar) {
                        cbGenerado.Enabled = true;
                        cbAprobado.Enabled = true;
                        cbDenegado.Enabled = true;
                    }

                    habilitaBoton(btnEditar, false);
                    habilitaBoton(btnGuardar,  true);
                    //habilitaBoton(btnCancelar, true);
                    break;

                case Estado.Revisar:
                    txtId.Enabled = false;
                    txtDescripcion.Enabled = false;
                    txtObservaciones.Enabled = true;
                    txtMeta.Enabled = false;
                    txtUnidades.Enabled = false;
                    cbAprobado.Enabled = true;
                    cbDenegado.Enabled = true;

                    habilitaBoton(btnEditar,false);
                    habilitaBoton(btnGuardar, true);
                    break;

                case Estado.Autoevaluar:
                    txtId.Enabled = false;
                    txtDescripcion.Enabled = false;
                    txtObservaciones.Enabled = false;
                    txtMeta.Enabled = false;
                    txtUnidades.Enabled = false;
                    txtLogroEvaluador.Enabled = false;
                    txtLogroPersonal.Enabled = true;
                    txtNota.Enabled = false;
                    txtNotaAuto.Enabled = false;

                    habilitaBoton(btnEditar, false);
                    habilitaBoton(btnGuardar, true);
                    //habilitaBoton(btnCancelar, true);
                    break;

                case Estado.Evaluar:
                    txtId.Enabled = false;
                    txtDescripcion.Enabled = false;
                    txtObservaciones.Enabled = false;
                    txtMeta.Enabled = false;
                    txtUnidades.Enabled = false;
                    txtLogroEvaluador.Enabled = true;
                    txtLogroPersonal.Enabled = false;
                    txtNota.Enabled = false;
                    txtNotaAuto.Enabled = false;

                    habilitaBoton(btnEditar,false);
                    habilitaBoton(btnGuardar, true);
                    //habilitaBoton(btnCancelar, true);

                    break;

            }
        }
        private void habilitaBoton(Button boton,bool estado)
        {
            boton.Enabled = estado;
            if (estado == true)
                boton.BackColor = Color.FromArgb(46,44,51);
            if (estado == false)
                boton.BackColor = Color.FromArgb(246, 245, 247);

        }
        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (objetivo.estado == 1)
            {
                MessageBox.Show("Este objetivo ya fue aprobado", "Mensaje de confirmación", MessageBoxButtons.OK);
            }
            else if (objetivo.estado == 3)
            {
                establecerComponentes(Estado.Revisar);
            }
            else {
                establecerComponentes(Estado.Actualizar);
                //estado = Estado.Actualizar;
            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (estado == Estado.Autoevaluar || estado == Estado.Evaluar)
                this.DialogResult = DialogResult.OK;

            if (estado == Estado.Nuevo) {
                //Verificacion
                if (txtDescripcion.Text == "")
                    MessageBox.Show("Falta ingresar la Descripcion", "Mensaje de error", MessageBoxButtons.OK);
                else if (txtMeta.Text == "")
                    MessageBox.Show("Falta ingresar la Meta", "Mensaje de error", MessageBoxButtons.OK);
                else if (txtUnidades.Text == "")
                    MessageBox.Show("Falta ingresar las unidades", "Mensaje de error", MessageBoxButtons.OK);
                else 
                if (MessageBox.Show("¿Desea registrar el Objetivo?", "Mensaje de confirmación", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    try {
                        objetivo.descripcion = txtDescripcion.Text;
                        objetivo.meta = Double.Parse(txtMeta.Text);
                        objetivo.unidad_meta = txtUnidades.Text;
                        ObjetivoWS.evaluacionTotal eva = new ObjetivoWS.evaluacionTotal();
                        eva.idEvaluacion = Program.evaluacion.idEvaluacion;
                        objetivo.evaluacion = eva;
                        daoObjetivo.insertarObjetivo(objetivo);
                        MessageBox.Show("Objetivo registrado", "Confirmación", MessageBoxButtons.OK);
                        this.DialogResult = DialogResult.OK;
                        //establecerComponentes(Estado.Inicial);
                    }catch(Exception ex)
                    {
                        MessageBox.Show("La meta debe ser un valor numérico", "Mensaje de Error", MessageBoxButtons.OK);
                    }
                }
            }
            else if (estado == Estado.Actualizar || estado == Estado.Inicial)
            {
                //Verificacion
                if (txtDescripcion.Text == "")
                    MessageBox.Show("Falta ingresar la Descripcion", "Mensaje de error", MessageBoxButtons.OK);
                else if (txtMeta.Text == "")
                    MessageBox.Show("Falta ingresar la Meta", "Mensaje de error", MessageBoxButtons.OK);
                else if (txtUnidades.Text == "")
                    MessageBox.Show("Falta ingresar las unidades", "Mensaje de error", MessageBoxButtons.OK);
                else
                if (MessageBox.Show("¿Desea modificar el Objetivo?", "Mensaje de confirmación", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    try { 
                        objetivo.descripcion = txtDescripcion.Text;
                        objetivo.meta = Double.Parse(txtMeta.Text);
                        objetivo.unidad_meta = txtUnidades.Text;
                        if (objetivo.estado == 2)
                            objetivo.estado = 0;
                        daoObjetivo.actualizarObjetivo(objetivo);
                        MessageBox.Show("Objetivo modificado", "Confirmación", MessageBoxButtons.OK);
                        this.DialogResult = DialogResult.OK;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("La meta debe ser un valor numérico", "Mensaje de Error", MessageBoxButtons.OK);
                    }
                }
            }
            else if (estado == Estado.Revisar)
            {
                //Verificacion
                if (txtObservaciones.Text == "")
                    MessageBox.Show("Falta ingresar las Observaciones", "Mensaje de error", MessageBoxButtons.OK);
                else
                if (MessageBox.Show("¿Desea confirmar la revisión?", "Mensaje de confirmación", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    objetivo.observaciones = txtObservaciones.Text;
                    if (cbAprobado.Checked)
                        objetivo.estado = 1;
                    else if (cbDenegado.Checked)
                        objetivo.estado = 2;
                    
                    daoObjetivo.actualizarObjetivo(objetivo);
                    MessageBox.Show("Revisión de objetivo realizada", "Confirmación", MessageBoxButtons.OK);
                    this.DialogResult = DialogResult.OK;
                }
            }
            else if (estado == Estado.Evaluar)
            {
                //Verificacion
                if (txtLogroEvaluador.Text == "")
                    MessageBox.Show("Falta ingresar el logro", "Mensaje de error", MessageBoxButtons.OK);
                else
                if (MessageBox.Show("¿Desea guardar el logro?", "Mensaje de confirmación", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    try {
                        objetivo.logroEvaluador = Double.Parse(txtLogroEvaluador.Text);
                        objetivo.porcentajeEvaluador = nota;
                        daoObjetivo.actualizarObjetivo(objetivo);
                        MessageBox.Show("Evaluación de objetivo realizada", "Confirmación", MessageBoxButtons.OK);
                        this.DialogResult = DialogResult.OK;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("El logro debe ser un valor numérico", "Mensaje de Error", MessageBoxButtons.OK);
                    }
                }
            }
            else if (estado == Estado.Autoevaluar)
            {
                //Verificacion
                if (txtLogroPersonal.Text == "")
                    MessageBox.Show("Falta ingresar el logro", "Mensaje de error", MessageBoxButtons.OK);
                else
                if (MessageBox.Show("¿Desea guardar el logro?", "Mensaje de confirmación", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    try { 
                    objetivo.logroEvaluado = Double.Parse(txtLogroPersonal.Text);
                    objetivo.porcentajeEvaluado = notaAuto;
                    daoObjetivo.actualizarObjetivo(objetivo);
                    MessageBox.Show("Evaluación de objetivo realizada", "Confirmación", MessageBoxButtons.OK);
                    this.DialogResult = DialogResult.OK;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("El logro debe ser un valor numérico", "Mensaje de Error", MessageBoxButtons.OK);
                    }
                }
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            //if (estado == Estado.Autoevaluar || estado == Estado.Evaluar || estado == Estado.Nuevo)
            this.DialogResult = DialogResult.Cancel;
            establecerComponentes(Estado.Inicial);
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

        private void btnAtras_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

        private void cbAprobado_CheckedChanged(object sender, EventArgs e)
        {
            if (cbAprobado.Checked == true)
            {
                cbGenerado.Checked = false;
                cbDenegado.Checked = false;
            }
        }

        private void cbDenegado_CheckedChanged(object sender, EventArgs e)
        {
            if (cbDenegado.Checked == true)
            {
                cbGenerado.Checked = false;
                cbAprobado.Checked = false;
            }
        }

        private void cbGenerado_CheckedChanged(object sender, EventArgs e)
        {
            if (cbGenerado.Checked == true)
            {
                cbDenegado.Checked = false;
                cbAprobado.Checked = false;
            }
        }

        private void txtLogroPersonal_TextChanged(object sender, EventArgs e)
        {
            double num;
            try
            {
                num = Double.Parse(txtLogroPersonal.Text);
                if (num > objetivo.meta)
                    num = objetivo.meta;
                notaAuto = num / objetivo.meta;
                txtNotaAuto.Text = Math.Round(notaAuto*100, 2).ToString() + " %";
            }
            catch
            {

            }
        }

        private void txtLogroEvaluador_TextChanged(object sender, EventArgs e)
        {
            double num;
            try
            {
                num = Double.Parse(txtLogroEvaluador.Text);
                if (num > objetivo.meta)
                    num = objetivo.meta;
                nota = num / objetivo.meta;
                txtNota.Text = Math.Round(nota*100,2).ToString() + " %";
            }
            catch
            {

            }
        }
    }
}
