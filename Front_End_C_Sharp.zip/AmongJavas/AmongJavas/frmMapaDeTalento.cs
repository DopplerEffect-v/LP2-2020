﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AmongJavas
{
    public partial class frmMapaDeTalento : Form
    {

        private frmInicioSesion panelInicioSesion;
        private frmMenuCalibracion menuCalibracion;
        private AreaWS.AreaWSClient daoArea;
        private CuadranteWS.CuadranteWSClient daoCuadrante;
        private EvaluacionTotalWS.EvaluacionTotalWSClient daoEvaluacion;
        private BindingList<EvaluacionTotalWS.evaluacionTotal> listaTotal;
        private BindingList<EvaluacionTotalWS.evaluacionTotal> listaAbajo;
        private BindingList<EvaluacionTotalWS.evaluacionTotal> listaAmedio;
        private BindingList<EvaluacionTotalWS.evaluacionTotal> listaAalto;
        private BindingList<EvaluacionTotalWS.evaluacionTotal> listaBbajo;
        private BindingList<EvaluacionTotalWS.evaluacionTotal> listaBmedio;
        private BindingList<EvaluacionTotalWS.evaluacionTotal> listaBalto;
        private BindingList<EvaluacionTotalWS.evaluacionTotal> listaCbajo;
        private BindingList<EvaluacionTotalWS.evaluacionTotal> listaCmedio;
        private BindingList<EvaluacionTotalWS.evaluacionTotal> listaCalto;
        private BindingList<EvaluacionTotalWS.evaluacionTotal> listaSeleccionada;
        private String listaSelX;
        private String listaSelY;
        private EvaluacionTotalWS.cuadrante cuadrante;
        private EvaluacionTotalWS.evaluacionTotal evaluacionSeleccionada;
        private BindingList<CuadranteWS.cuadrante> listaCuadrantes;
        private Estado estado;

        public frmMapaDeTalento(frmInicioSesion panelInicioSesion,frmMenuCalibracion menuCalibracion,Estado estado)
        {
            InitializeComponent();
            this.panelInicioSesion = panelInicioSesion;
            this.menuCalibracion = menuCalibracion;
            
            txtNombre.Enabled = false;
            txtCorreo.Enabled = false;
            txtArea.Enabled = false;
            this.estado = Estado.Inicial;
            establecerComponentes(this.estado);
            daoEvaluacion = new EvaluacionTotalWS.EvaluacionTotalWSClient();
            daoCuadrante = new CuadranteWS.CuadranteWSClient();
            //Llena combobox
            cboArea.ValueMember = "id_Area";
            cboArea.DisplayMember = "nombre";
            daoArea = new AreaWS.AreaWSClient();
            cboArea.DataSource = daoArea.listarArea();
            deshabilitaEtapa();
        }
        public void deshabilitaEtapa()
        {
            if (Program.cronograma.etapa == 3)
            {
                btnCalibrar.Visible = false;
                btnCancelar.Visible = false;
                panelIndi.Visible = false;
                txtMotivo.Visible = false;
                lblMotivo.Visible = false;
            }
        }
        public void llenarTabla()
        {
            if (listaSeleccionada != null)
            {
                dgvColaboradores.AutoGenerateColumns = false;
                dgvColaboradores.DataSource = listaSeleccionada.ToArray();
                dgvColaboradores.ClearSelection();
            }
            else {
                txtEjeX.Text = "";
                txtEjeY.Text = "";
                dgvColaboradores.DataSource = null;
            }
        }
        private void habilitaBoton(Button boton, bool estado)
        {
            boton.Enabled = estado;
            if (estado == true)
                boton.BackColor = Color.FromArgb(46, 44, 51);
            if (estado == false)
                boton.BackColor = Color.FromArgb(246, 245, 247);

        }
        public void establecerComponentes(Estado estado)
        {
            switch (estado)
            {
                case Estado.Inicial:
                    txtMotivo.Enabled = false;
                    habilitaBoton(btnCalibrar,false);
                    habilitaBoton(btnCancelar,false);
                    break;

                case Estado.Nuevo:
                    habilitaBoton(btnCalibrar, true);
                    habilitaBoton(btnCancelar, false);
                    break;

                case Estado.Actualizar:
                    txtMotivo.Enabled = true;
                    habilitaBoton(btnCalibrar, false);
                    habilitaBoton(btnCancelar, true);
                    break;
            }
        }

        private void btnAtras_Click(object sender, EventArgs e)
        {
            this.Hide();
            menuCalibracion.Show();
        }

        private void btnCerrarSesion_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            this.panelInicioSesion.Show();
        }

        private void btnCalibrar_Click(object sender, EventArgs e)
        {
            estado = Estado.Actualizar;
            establecerComponentes(estado);
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        public void llenarUsuario()
        {
            txtNombre.Text = Program.colaborador.nombres + " " + Program.colaborador.apellidos;
            txtArea.Text = Program.colaborador.area.nombre;
            txtCorreo.Text = Program.colaborador.correo;
        }

        private void generaMapaTalento()
        {
            if (cboArea.DataSource != null)
            {
                AreaWS.area area = (AreaWS.area)cboArea.SelectedItem;
                listaAbajo = new BindingList<EvaluacionTotalWS.evaluacionTotal>();
                listaAmedio = new BindingList<EvaluacionTotalWS.evaluacionTotal>();
                listaAalto = new BindingList<EvaluacionTotalWS.evaluacionTotal>();
                listaBbajo = new BindingList<EvaluacionTotalWS.evaluacionTotal>();
                listaBmedio = new BindingList<EvaluacionTotalWS.evaluacionTotal>();
                listaBalto = new BindingList<EvaluacionTotalWS.evaluacionTotal>();
                listaCbajo = new BindingList<EvaluacionTotalWS.evaluacionTotal>();
                listaCmedio = new BindingList<EvaluacionTotalWS.evaluacionTotal>();
                listaCalto = new BindingList<EvaluacionTotalWS.evaluacionTotal>();
                listaCuadrantes = new BindingList<CuadranteWS.cuadrante>(daoCuadrante.listarCuadrante(area.id_Area));

                try
                {
                    listaTotal = new BindingList<EvaluacionTotalWS.evaluacionTotal>(daoEvaluacion.listar_calibracion(area.id_Area));
                    foreach (EvaluacionTotalWS.evaluacionTotal eva in listaTotal)
                    {
                        //Obtiene cuadrante
                        if (eva.calibrado == null) //Si aun no ha sido calibrado
                            cuadrante = eva.calibracionAutomatica;
                        else
                            cuadrante = eva.calibrado;
                        //Añade a la lista que pertenece
                        if (cuadrante.ejes.ejey == "A" && cuadrante.ejes.ejex == "BAJO")
                            listaAbajo.Add(eva);
                        if (cuadrante.ejes.ejey == "A" && cuadrante.ejes.ejex == "MEDIO")
                            listaAmedio.Add(eva);
                        if (cuadrante.ejes.ejey == "A" && cuadrante.ejes.ejex == "ALTO")
                            listaAalto.Add(eva);
                        if (cuadrante.ejes.ejey == "B" && cuadrante.ejes.ejex == "BAJO")
                            listaBbajo.Add(eva);
                        if (cuadrante.ejes.ejey == "B" && cuadrante.ejes.ejex == "MEDIO")
                            listaBmedio.Add(eva);
                        if (cuadrante.ejes.ejey == "B" && cuadrante.ejes.ejex == "ALTO")
                            listaBalto.Add(eva);
                        if (cuadrante.ejes.ejey == "C" && cuadrante.ejes.ejex == "BAJO")
                            listaCbajo.Add(eva);
                        if (cuadrante.ejes.ejey == "C" && cuadrante.ejes.ejex == "MEDIO")
                            listaCmedio.Add(eva);
                        if (cuadrante.ejes.ejey == "C" && cuadrante.ejes.ejex == "ALTO")
                            listaCalto.Add(eva);

                    }
                }
                catch (Exception ex)
                {

                }
                //Coloca numero de elementos
                btnCuadranteAalto.Text = listaAalto.Count.ToString();
                btnCuadranteAmedio.Text = listaAmedio.Count.ToString();
                btnCuadranteAbajo.Text = listaAbajo.Count.ToString();
                btnCuadranteBalto.Text = listaBalto.Count.ToString();
                btnCuadranteBmedio.Text = listaBmedio.Count.ToString();
                btnCuadranteBbajo.Text = listaBbajo.Count.ToString();
                btnCuadranteCalto.Text = listaCalto.Count.ToString();
                btnCuadranteCmedio.Text = listaCmedio.Count.ToString();
                btnCuadranteCbajo.Text = listaCbajo.Count.ToString();
            }
        }
        private void cboArea_SelectedIndexChanged(object sender, EventArgs e)
        {
            estado = Estado.Inicial;
            establecerComponentes(estado);
            generaMapaTalento();
            dgvColaboradores.DataSource = null;
        }

        private int buscaIdCuadrante(String x, String y)
        {
            foreach (CuadranteWS.cuadrante cuadrante in listaCuadrantes)
            {
                if (cuadrante.ejes.ejex == x && cuadrante.ejes.ejey == y)
                {
                    return cuadrante.id_cuadrante;
                }
            }
            return 0;
        }
        private void presionaCuadrante(BindingList<EvaluacionTotalWS.evaluacionTotal> lista,String ejeX, String ejeY)
        {
            if (estado == Estado.Inicial)
            {
                listaSeleccionada = lista;
                listaSelX = ejeX;
                listaSelY = ejeY;
                txtEjeX.Text = ejeX;
                txtEjeY.Text = ejeY;
                establecerComponentes(estado);
            }
            else if (estado == Estado.Actualizar)
            {
                if (MessageBox.Show("¿Desea calibrar a " + evaluacionSeleccionada.nombreColaborador + " al cuadrante "+ejeY+"-"+ejeX+"?", "Mensaje de confirmación", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    String x, y;
                    int idC = buscaIdCuadrante(ejeX, ejeY);
                    evaluacionSeleccionada.calibrado = new EvaluacionTotalWS.cuadrante();
                    evaluacionSeleccionada.calibrado.id_cuadrante = idC;
                    if (txtMotivo.Text=="")
                        evaluacionSeleccionada.observacionesCalibracion = "No se ingresó ningún comentario al respecto.";
                    else
                        evaluacionSeleccionada.observacionesCalibracion = txtMotivo.Text;
                    daoEvaluacion.actualizarCortoEvaluacion(evaluacionSeleccionada);
                    MessageBox.Show("Calibración realizada", "Mensaje de confirmación", MessageBoxButtons.OK);
                    estado = Estado.Inicial;
                    establecerComponentes(estado);
                    generaMapaTalento();
                    if (listaSelX == "BAJO" && listaSelY == "A") listaSeleccionada = listaAbajo;
                    if (listaSelX == "MEDIO" && listaSelY == "A") listaSeleccionada = listaAmedio;
                    if (listaSelX == "ALTO" && listaSelY == "A") listaSeleccionada = listaAalto;
                    if (listaSelX == "BAJO" && listaSelY == "B") listaSeleccionada = listaBbajo;
                    if (listaSelX == "MEDIO" && listaSelY == "B") listaSeleccionada = listaBmedio;
                    if (listaSelX == "ALTO" && listaSelY == "B") listaSeleccionada = listaBalto;
                    if (listaSelX == "BAJO" && listaSelY == "C") listaSeleccionada = listaCbajo;
                    if (listaSelX == "MEDIO" && listaSelY == "C") listaSeleccionada = listaCmedio;
                    if (listaSelX == "ALTO" && listaSelY == "C") listaSeleccionada = listaCalto;
                    txtMotivo.Text = "";
                }
            }
            llenarTabla();
        }
        private void btnCuadranteAbajo_Click(object sender, EventArgs e)
        {
            presionaCuadrante(listaAbajo, "BAJO", "A");
        }

        private void btnCuadranteAmedio_Click(object sender, EventArgs e)
        {
            presionaCuadrante(listaAmedio,"MEDIO","A");
        }

        private void btnCuadranteAalto_Click(object sender, EventArgs e)
        {
            presionaCuadrante(listaAalto,"ALTO","A");
        }

        private void btnCuadranteBbajo_Click(object sender, EventArgs e)
        {
            presionaCuadrante(listaBbajo, "BAJO", "B");
        }

        private void btnCuadranteBmedio_Click(object sender, EventArgs e)
        {
            presionaCuadrante(listaBmedio, "MEDIO", "B");
        }

        private void btnCuadranteBalto_Click(object sender, EventArgs e)
        {
            presionaCuadrante(listaBalto, "ALTO", "B");
        }

        private void btnCuadranteCbajo_Click(object sender, EventArgs e)
        {
            presionaCuadrante(listaCbajo, "BAJO", "C");
        }

        private void btnCuadranteCmedio_Click(object sender, EventArgs e)
        {
            presionaCuadrante(listaCmedio, "MEDIO", "C");
        }

        private void btnCuadranteCalto_Click(object sender, EventArgs e)
        {
            presionaCuadrante(listaCalto, "ALTO", "C");
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            estado = Estado.Inicial;
            establecerComponentes(estado);
        }

        private void dgvColaboradores_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            evaluacionSeleccionada = (EvaluacionTotalWS.evaluacionTotal)dgvColaboradores.CurrentRow.DataBoundItem;
            establecerComponentes(Estado.Nuevo);
        }
    }
}
