﻿namespace AmongJavas
{
    partial class frmMenuEvaluacion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelAuto = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.btnAutoevaluarCompetencias = new System.Windows.Forms.Button();
            this.btnAutoEvaluarObjetivos = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnCerrar = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnCerrarSesion = new System.Windows.Forms.LinkLabel();
            this.txtArea = new System.Windows.Forms.TextBox();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.txtCorreo = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.panelEva = new System.Windows.Forms.Panel();
            this.btnEvaluarPotenciales = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.btnEvaluarCompetencias = new System.Windows.Forms.Button();
            this.btnEvaluarObjetivos = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.txtEtapa = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.btnOjetivos = new System.Windows.Forms.Button();
            this.btnReportes = new System.Windows.Forms.Button();
            this.btnCalibracion = new System.Windows.Forms.Button();
            this.btnEvaluacion = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.btnPlanificacion = new System.Windows.Forms.Button();
            this.panelNoDisponible = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.lblFecha = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtPeriodo = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.panelAuto.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panelEva.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel17.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panelNoDisponible.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelAuto
            // 
            this.panelAuto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.panelAuto.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelAuto.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelAuto.Controls.Add(this.panel9);
            this.panelAuto.Controls.Add(this.btnAutoevaluarCompetencias);
            this.panelAuto.Controls.Add(this.btnAutoEvaluarObjetivos);
            this.panelAuto.Location = new System.Drawing.Point(542, 211);
            this.panelAuto.Name = "panelAuto";
            this.panelAuto.Size = new System.Drawing.Size(359, 182);
            this.panelAuto.TabIndex = 22;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(63)))), ((int)(((byte)(65)))));
            this.panel9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel9.Controls.Add(this.label2);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel9.Location = new System.Drawing.Point(0, 0);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(357, 49);
            this.panel9.TabIndex = 15;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(25, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(193, 28);
            this.label2.TabIndex = 3;
            this.label2.Text = "AutoEvaluacion";
            // 
            // btnAutoevaluarCompetencias
            // 
            this.btnAutoevaluarCompetencias.BackColor = System.Drawing.Color.Transparent;
            this.btnAutoevaluarCompetencias.FlatAppearance.BorderSize = 0;
            this.btnAutoevaluarCompetencias.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAutoevaluarCompetencias.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAutoevaluarCompetencias.ForeColor = System.Drawing.Color.DimGray;
            this.btnAutoevaluarCompetencias.Location = new System.Drawing.Point(30, 115);
            this.btnAutoevaluarCompetencias.Name = "btnAutoevaluarCompetencias";
            this.btnAutoevaluarCompetencias.Size = new System.Drawing.Size(308, 38);
            this.btnAutoevaluarCompetencias.TabIndex = 14;
            this.btnAutoevaluarCompetencias.Text = "Autoevaluar Competencias";
            this.btnAutoevaluarCompetencias.UseVisualStyleBackColor = false;
            this.btnAutoevaluarCompetencias.Click += new System.EventHandler(this.btnAutoevaluarCompetencias_Click);
            // 
            // btnAutoEvaluarObjetivos
            // 
            this.btnAutoEvaluarObjetivos.BackColor = System.Drawing.Color.Transparent;
            this.btnAutoEvaluarObjetivos.FlatAppearance.BorderSize = 0;
            this.btnAutoEvaluarObjetivos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAutoEvaluarObjetivos.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAutoEvaluarObjetivos.ForeColor = System.Drawing.Color.DimGray;
            this.btnAutoEvaluarObjetivos.Location = new System.Drawing.Point(30, 67);
            this.btnAutoEvaluarObjetivos.Name = "btnAutoEvaluarObjetivos";
            this.btnAutoEvaluarObjetivos.Size = new System.Drawing.Size(308, 38);
            this.btnAutoEvaluarObjetivos.TabIndex = 13;
            this.btnAutoEvaluarObjetivos.Text = "Autoevaluar Objetivos";
            this.btnAutoEvaluarObjetivos.UseVisualStyleBackColor = false;
            this.btnAutoEvaluarObjetivos.Click += new System.EventHandler(this.btnAutoEvaluarObjetivos_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(119)))), ((int)(((byte)(205)))));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.lblTitulo);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1221, 182);
            this.panel1.TabIndex = 20;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.panel4.Controls.Add(this.btnCerrar);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1221, 33);
            this.panel4.TabIndex = 4;
            // 
            // btnCerrar
            // 
            this.btnCerrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.btnCerrar.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnCerrar.FlatAppearance.BorderSize = 0;
            this.btnCerrar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCerrar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCerrar.ForeColor = System.Drawing.Color.Silver;
            this.btnCerrar.Image = global::AmongJavas.Properties.Resources.Close_Icon;
            this.btnCerrar.Location = new System.Drawing.Point(1189, 0);
            this.btnCerrar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnCerrar.Name = "btnCerrar";
            this.btnCerrar.Size = new System.Drawing.Size(32, 33);
            this.btnCerrar.TabIndex = 61;
            this.btnCerrar.UseVisualStyleBackColor = false;
            this.btnCerrar.Click += new System.EventHandler(this.btnCerrar_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(119)))), ((int)(((byte)(205)))));
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel2.Controls.Add(this.btnCerrarSesion);
            this.panel2.Controls.Add(this.txtArea);
            this.panel2.Controls.Add(this.txtNombre);
            this.panel2.Controls.Add(this.txtCorreo);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Location = new System.Drawing.Point(858, 29);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(365, 153);
            this.panel2.TabIndex = 1;
            // 
            // btnCerrarSesion
            // 
            this.btnCerrarSesion.AutoSize = true;
            this.btnCerrarSesion.BackColor = System.Drawing.Color.Transparent;
            this.btnCerrarSesion.ForeColor = System.Drawing.Color.DimGray;
            this.btnCerrarSesion.LinkColor = System.Drawing.Color.White;
            this.btnCerrarSesion.Location = new System.Drawing.Point(235, 123);
            this.btnCerrarSesion.Name = "btnCerrarSesion";
            this.btnCerrarSesion.Size = new System.Drawing.Size(106, 20);
            this.btnCerrarSesion.TabIndex = 7;
            this.btnCerrarSesion.TabStop = true;
            this.btnCerrarSesion.Text = "Cerrar Sesion";
            this.btnCerrarSesion.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.btnCerrarSesion_LinkClicked);
            // 
            // txtArea
            // 
            this.txtArea.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.txtArea.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtArea.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtArea.Location = new System.Drawing.Point(137, 88);
            this.txtArea.Name = "txtArea";
            this.txtArea.Size = new System.Drawing.Size(204, 27);
            this.txtArea.TabIndex = 5;
            // 
            // txtNombre
            // 
            this.txtNombre.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.txtNombre.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNombre.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNombre.Location = new System.Drawing.Point(137, 16);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(204, 27);
            this.txtNombre.TabIndex = 4;
            // 
            // txtCorreo
            // 
            this.txtCorreo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.txtCorreo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCorreo.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCorreo.Location = new System.Drawing.Point(137, 52);
            this.txtCorreo.Name = "txtCorreo";
            this.txtCorreo.Size = new System.Drawing.Size(204, 27);
            this.txtCorreo.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(62, 88);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 21);
            this.label4.TabIndex = 3;
            this.label4.Text = "Area:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(62, 51);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 21);
            this.label3.TabIndex = 2;
            this.label3.Text = "Correo:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(62, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 21);
            this.label1.TabIndex = 1;
            this.label1.Text = "Nombre:";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = global::AmongJavas.Properties.Resources.IconoUsuario;
            this.pictureBox2.Location = new System.Drawing.Point(3, 32);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(53, 55);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::AmongJavas.Properties.Resources.IconoMenu;
            this.pictureBox1.Location = new System.Drawing.Point(4, 76);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(49, 55);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.BackColor = System.Drawing.Color.Transparent;
            this.lblTitulo.Font = new System.Drawing.Font("Century Gothic", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.Color.White;
            this.lblTitulo.Location = new System.Drawing.Point(59, 80);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(308, 47);
            this.lblTitulo.TabIndex = 1;
            this.lblTitulo.Text = "Menu Principal";
            // 
            // panelEva
            // 
            this.panelEva.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.panelEva.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelEva.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelEva.Controls.Add(this.btnEvaluarPotenciales);
            this.panelEva.Controls.Add(this.panel7);
            this.panelEva.Controls.Add(this.btnEvaluarCompetencias);
            this.panelEva.Controls.Add(this.btnEvaluarObjetivos);
            this.panelEva.Location = new System.Drawing.Point(542, 444);
            this.panelEva.Name = "panelEva";
            this.panelEva.Size = new System.Drawing.Size(359, 206);
            this.panelEva.TabIndex = 23;
            // 
            // btnEvaluarPotenciales
            // 
            this.btnEvaluarPotenciales.BackColor = System.Drawing.Color.Transparent;
            this.btnEvaluarPotenciales.FlatAppearance.BorderSize = 0;
            this.btnEvaluarPotenciales.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEvaluarPotenciales.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEvaluarPotenciales.ForeColor = System.Drawing.Color.DimGray;
            this.btnEvaluarPotenciales.Location = new System.Drawing.Point(30, 150);
            this.btnEvaluarPotenciales.Name = "btnEvaluarPotenciales";
            this.btnEvaluarPotenciales.Size = new System.Drawing.Size(308, 38);
            this.btnEvaluarPotenciales.TabIndex = 16;
            this.btnEvaluarPotenciales.Text = "Evaluar Potenciales";
            this.btnEvaluarPotenciales.UseVisualStyleBackColor = false;
            this.btnEvaluarPotenciales.Click += new System.EventHandler(this.btnEvaluarPotenciales_Click);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(63)))), ((int)(((byte)(65)))));
            this.panel7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel7.Controls.Add(this.label5);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(357, 49);
            this.panel7.TabIndex = 15;
            this.panel7.Paint += new System.Windows.Forms.PaintEventHandler(this.panel7_Paint);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(25, 11);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(318, 28);
            this.label5.TabIndex = 3;
            this.label5.Text = "Evaluacion colaboradores";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // btnEvaluarCompetencias
            // 
            this.btnEvaluarCompetencias.BackColor = System.Drawing.Color.Transparent;
            this.btnEvaluarCompetencias.FlatAppearance.BorderSize = 0;
            this.btnEvaluarCompetencias.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEvaluarCompetencias.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEvaluarCompetencias.ForeColor = System.Drawing.Color.DimGray;
            this.btnEvaluarCompetencias.Location = new System.Drawing.Point(30, 103);
            this.btnEvaluarCompetencias.Name = "btnEvaluarCompetencias";
            this.btnEvaluarCompetencias.Size = new System.Drawing.Size(308, 38);
            this.btnEvaluarCompetencias.TabIndex = 14;
            this.btnEvaluarCompetencias.Text = "Evaluar Competencias";
            this.btnEvaluarCompetencias.UseVisualStyleBackColor = false;
            this.btnEvaluarCompetencias.Click += new System.EventHandler(this.btnEvaluarCompetencias_Click);
            // 
            // btnEvaluarObjetivos
            // 
            this.btnEvaluarObjetivos.BackColor = System.Drawing.Color.Transparent;
            this.btnEvaluarObjetivos.FlatAppearance.BorderSize = 0;
            this.btnEvaluarObjetivos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEvaluarObjetivos.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEvaluarObjetivos.ForeColor = System.Drawing.Color.DimGray;
            this.btnEvaluarObjetivos.Location = new System.Drawing.Point(30, 55);
            this.btnEvaluarObjetivos.Name = "btnEvaluarObjetivos";
            this.btnEvaluarObjetivos.Size = new System.Drawing.Size(308, 38);
            this.btnEvaluarObjetivos.TabIndex = 13;
            this.btnEvaluarObjetivos.Text = "Evaluar Objetivos";
            this.btnEvaluarObjetivos.UseVisualStyleBackColor = false;
            this.btnEvaluarObjetivos.Click += new System.EventHandler(this.btnEvaluarObjetivos_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(119)))), ((int)(((byte)(205)))));
            this.panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel3.Controls.Add(this.panel17);
            this.panel3.Controls.Add(this.pictureBox7);
            this.panel3.Controls.Add(this.pictureBox6);
            this.panel3.Controls.Add(this.pictureBox5);
            this.panel3.Controls.Add(this.pictureBox4);
            this.panel3.Controls.Add(this.btnOjetivos);
            this.panel3.Controls.Add(this.btnReportes);
            this.panel3.Controls.Add(this.btnCalibracion);
            this.panel3.Controls.Add(this.btnEvaluacion);
            this.panel3.Controls.Add(this.pictureBox3);
            this.panel3.Controls.Add(this.btnPlanificacion);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 182);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(249, 519);
            this.panel3.TabIndex = 21;
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.txtPeriodo);
            this.panel17.Controls.Add(this.label8);
            this.panel17.Controls.Add(this.txtEtapa);
            this.panel17.Controls.Add(this.label9);
            this.panel17.Location = new System.Drawing.Point(11, 414);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(228, 95);
            this.panel17.TabIndex = 13;
            // 
            // txtEtapa
            // 
            this.txtEtapa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.txtEtapa.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtEtapa.Enabled = false;
            this.txtEtapa.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEtapa.Location = new System.Drawing.Point(83, 52);
            this.txtEtapa.Name = "txtEtapa";
            this.txtEtapa.Size = new System.Drawing.Size(133, 27);
            this.txtEtapa.TabIndex = 8;
            this.txtEtapa.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(5, 54);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(58, 19);
            this.label9.TabIndex = 8;
            this.label9.Text = "Etapa:";
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox7.Image = global::AmongJavas.Properties.Resources.IconoCalibracion;
            this.pictureBox7.Location = new System.Drawing.Point(12, 253);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(49, 55);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 12;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox6.Image = global::AmongJavas.Properties.Resources.IconoReporte;
            this.pictureBox6.Location = new System.Drawing.Point(12, 326);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(49, 55);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 11;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox5.Image = global::AmongJavas.Properties.Resources.IconoObjetivo;
            this.pictureBox5.Location = new System.Drawing.Point(12, 104);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(49, 55);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 10;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(32)))), ((int)(((byte)(40)))));
            this.pictureBox4.Image = global::AmongJavas.Properties.Resources.IconoReportes;
            this.pictureBox4.Location = new System.Drawing.Point(12, 180);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(49, 55);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 9;
            this.pictureBox4.TabStop = false;
            // 
            // btnOjetivos
            // 
            this.btnOjetivos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(119)))), ((int)(((byte)(205)))));
            this.btnOjetivos.FlatAppearance.BorderSize = 0;
            this.btnOjetivos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOjetivos.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOjetivos.ForeColor = System.Drawing.Color.White;
            this.btnOjetivos.Location = new System.Drawing.Point(0, 104);
            this.btnOjetivos.Name = "btnOjetivos";
            this.btnOjetivos.Size = new System.Drawing.Size(245, 55);
            this.btnOjetivos.TabIndex = 8;
            this.btnOjetivos.Text = "         Objetivos";
            this.btnOjetivos.UseVisualStyleBackColor = false;
            this.btnOjetivos.Click += new System.EventHandler(this.btnOjetivos_Click);
            // 
            // btnReportes
            // 
            this.btnReportes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(119)))), ((int)(((byte)(205)))));
            this.btnReportes.FlatAppearance.BorderSize = 0;
            this.btnReportes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReportes.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReportes.ForeColor = System.Drawing.Color.White;
            this.btnReportes.Location = new System.Drawing.Point(0, 326);
            this.btnReportes.Name = "btnReportes";
            this.btnReportes.Size = new System.Drawing.Size(249, 55);
            this.btnReportes.TabIndex = 7;
            this.btnReportes.Text = "        Reportes";
            this.btnReportes.UseVisualStyleBackColor = false;
            this.btnReportes.Click += new System.EventHandler(this.btnReportes_Click);
            // 
            // btnCalibracion
            // 
            this.btnCalibracion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(119)))), ((int)(((byte)(205)))));
            this.btnCalibracion.FlatAppearance.BorderSize = 0;
            this.btnCalibracion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCalibracion.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalibracion.ForeColor = System.Drawing.Color.White;
            this.btnCalibracion.Location = new System.Drawing.Point(0, 253);
            this.btnCalibracion.Name = "btnCalibracion";
            this.btnCalibracion.Size = new System.Drawing.Size(249, 58);
            this.btnCalibracion.TabIndex = 6;
            this.btnCalibracion.Text = "        Calibración";
            this.btnCalibracion.UseVisualStyleBackColor = false;
            this.btnCalibracion.Click += new System.EventHandler(this.btnCalibracion_Click);
            // 
            // btnEvaluacion
            // 
            this.btnEvaluacion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.btnEvaluacion.FlatAppearance.BorderSize = 0;
            this.btnEvaluacion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEvaluacion.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEvaluacion.ForeColor = System.Drawing.Color.White;
            this.btnEvaluacion.Location = new System.Drawing.Point(0, 180);
            this.btnEvaluacion.Name = "btnEvaluacion";
            this.btnEvaluacion.Size = new System.Drawing.Size(249, 55);
            this.btnEvaluacion.TabIndex = 5;
            this.btnEvaluacion.Text = "        Evaluación";
            this.btnEvaluacion.UseVisualStyleBackColor = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = global::AmongJavas.Properties.Resources.Icono_Planificacion1;
            this.pictureBox3.Location = new System.Drawing.Point(12, 29);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(49, 55);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 3;
            this.pictureBox3.TabStop = false;
            // 
            // btnPlanificacion
            // 
            this.btnPlanificacion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(119)))), ((int)(((byte)(205)))));
            this.btnPlanificacion.FlatAppearance.BorderSize = 0;
            this.btnPlanificacion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPlanificacion.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPlanificacion.ForeColor = System.Drawing.Color.White;
            this.btnPlanificacion.Location = new System.Drawing.Point(0, 29);
            this.btnPlanificacion.Name = "btnPlanificacion";
            this.btnPlanificacion.Size = new System.Drawing.Size(245, 55);
            this.btnPlanificacion.TabIndex = 4;
            this.btnPlanificacion.Text = "         Planificacion";
            this.btnPlanificacion.UseVisualStyleBackColor = false;
            this.btnPlanificacion.Click += new System.EventHandler(this.btnPlanificacion_Click);
            // 
            // panelNoDisponible
            // 
            this.panelNoDisponible.Controls.Add(this.label7);
            this.panelNoDisponible.Controls.Add(this.lblFecha);
            this.panelNoDisponible.Controls.Add(this.label6);
            this.panelNoDisponible.Location = new System.Drawing.Point(294, 186);
            this.panelNoDisponible.Name = "panelNoDisponible";
            this.panelNoDisponible.Size = new System.Drawing.Size(884, 500);
            this.panelNoDisponible.TabIndex = 24;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(182, 262);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(234, 46);
            this.label7.TabIndex = 2;
            this.label7.Text = "fecha Inicio:";
            this.label7.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblFecha
            // 
            this.lblFecha.AutoSize = true;
            this.lblFecha.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFecha.Location = new System.Drawing.Point(500, 262);
            this.lblFecha.Name = "lblFecha";
            this.lblFecha.Size = new System.Drawing.Size(118, 46);
            this.lblFecha.TabIndex = 1;
            this.lblFecha.Text = "fecha";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(198, 149);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(465, 55);
            this.label6.TabIndex = 0;
            this.label6.Text = "Etapa no disponible";
            // 
            // txtPeriodo
            // 
            this.txtPeriodo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.txtPeriodo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPeriodo.Enabled = false;
            this.txtPeriodo.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPeriodo.Location = new System.Drawing.Point(83, 14);
            this.txtPeriodo.Name = "txtPeriodo";
            this.txtPeriodo.Size = new System.Drawing.Size(133, 27);
            this.txtPeriodo.TabIndex = 11;
            this.txtPeriodo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(5, 16);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(72, 19);
            this.label8.TabIndex = 12;
            this.label8.Text = "Periodo:";
            // 
            // frmMenuEvaluacion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1221, 701);
            this.Controls.Add(this.panelNoDisponible);
            this.Controls.Add(this.panelEva);
            this.Controls.Add(this.panelAuto);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmMenuEvaluacion";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmMenuEvaluacion";
            this.panelAuto.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panelEva.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panelNoDisponible.ResumeLayout(false);
            this.panelNoDisponible.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelAuto;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Button btnAutoevaluarCompetencias;
        private System.Windows.Forms.Button btnAutoEvaluarObjetivos;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Button btnOjetivos;
        private System.Windows.Forms.Button btnReportes;
        private System.Windows.Forms.Button btnCalibracion;
        private System.Windows.Forms.Button btnEvaluacion;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button btnPlanificacion;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.LinkLabel btnCerrarSesion;
        private System.Windows.Forms.TextBox txtArea;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.TextBox txtCorreo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Panel panelEva;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnEvaluarCompetencias;
        private System.Windows.Forms.Button btnEvaluarObjetivos;
        private System.Windows.Forms.Button btnEvaluarPotenciales;
        private System.Windows.Forms.Button btnCerrar;
        private System.Windows.Forms.Panel panelNoDisponible;
        private System.Windows.Forms.Label lblFecha;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.TextBox txtEtapa;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtPeriodo;
        private System.Windows.Forms.Label label8;
    }
}