﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AmongJavas
{
    public partial class frmConfigurarCuposMapaTalento : Form
    {

        private frmMenuPlanificacion _menuPlanificacion;
        private frmInicioSesion _panelInicioSesion;
        private AreaWS.AreaWSClient daoArea;
        private CuadranteWS.CuadranteWSClient daoCuadrante;
        BindingList<CuadranteWS.cuadrante> lista;
        private EvaluacionTotalWS.EvaluacionTotalWSClient daoEvaluacion;
        private BindingList<EvaluacionTotalWS.evaluacionTotal> listaTotal;
        private int cantidad;

        public frmConfigurarCuposMapaTalento(Estado estado, frmMenuPlanificacion _menuPlanificacion,
            frmInicioSesion _panelInicioSesion)
        {
            InitializeComponent();
            establecerComponentes(estado);

            this._menuPlanificacion = _menuPlanificacion;
            this._panelInicioSesion = _panelInicioSesion;

            txtNombre.Enabled = false;
            txtArea.Enabled = false;
            txtCorreo.Enabled = false;

            daoCuadrante = new CuadranteWS.CuadranteWSClient();
            daoEvaluacion = new EvaluacionTotalWS.EvaluacionTotalWSClient();
            //Llena combobox
            cboArea.ValueMember = "id_Area";
            cboArea.DisplayMember = "nombre";
            daoArea = new AreaWS.AreaWSClient();
            cboArea.DataSource = daoArea.listarArea();
            deshabilitaEtapa();
        }
        public void deshabilitaEtapa()
        {
            if (Program.cronograma.etapa != 0)
            {
                btnActualizar.Visible = false;
                btnGuardar.Visible = false;
                btnCancelar.Visible = false;
            }
        }
        void establecerComponentes(Estado estado)
        {
            switch (estado)
            {
                case Estado.Inicial:

                    txtCuposA.Enabled = false;
                    txtCuposB.Enabled = false;

                    habilitaBoton(btnActualizar, true);
                    habilitaBoton(btnGuardar, false);
                    habilitaBoton(btnCancelar, false);

                    break;

                case Estado.Actualizar:

                    txtCuposA.Enabled = true;
                    txtCuposB.Enabled = true;

                    habilitaBoton(btnActualizar, false);
                    habilitaBoton(btnGuardar, true);
                    habilitaBoton(btnCancelar, true);

                    break;
            }
        }
        private void habilitaBoton(Button boton, bool estado)
        {
            boton.Enabled = estado;
            if (estado == true)
                boton.BackColor = Color.FromArgb(46, 44, 51);
            if (estado == false)
                boton.BackColor = Color.FromArgb(246, 245, 247);

        }
        private void btnAtras_Click(object sender, EventArgs e)
        {
            this.Hide();
            _menuPlanificacion.Show();
        }


        private void btnCerrarSesion_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            _panelInicioSesion.Show();
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            establecerComponentes(Estado.Actualizar);
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            int cupoA, cupoB, cupoC;
            try {
                cupoA = Int32.Parse(txtCuposA.Text);
                cupoB = Int32.Parse(txtCuposB.Text);
                if (cupoA<0)
                    MessageBox.Show("Los cupos de A no pueden ser negativos", "Mensaje de error", MessageBoxButtons.OK);
                else if (cupoB < 0)
                    MessageBox.Show("Los cupos de B no pueden ser negativos", "Mensaje de error", MessageBoxButtons.OK);
                else if (cupoA > cantidad)
                    MessageBox.Show("Los cupos de A no pueden ser mayor a la cantidad de colaboradores del Area", "Mensaje de error", MessageBoxButtons.OK);
                else if (cupoB > cantidad)
                    MessageBox.Show("Los cupos de B no pueden ser mayor a la cantidad de colaboradores del Area", "Mensaje de error", MessageBoxButtons.OK);
                else if (cupoA+cupoB > cantidad)
                    MessageBox.Show("La suma de cupos de A y B no pueden ser mayor a la cantidad de colaboradores del Area", "Mensaje de error", MessageBoxButtons.OK);
                else if (MessageBox.Show("¿Desea registrar los Cupos?", "Mensaje de confirmación", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    foreach (CuadranteWS.cuadrante cuadrante in lista)
                    {
                        if (cuadrante.ejes.ejey == "A" && cuadrante.ejes.ejex == "BAJO")
                        {
                            cuadrante.cupos = Int32.Parse(txtCuposA.Text);
                        }
                        if (cuadrante.ejes.ejey == "B" && cuadrante.ejes.ejex == "BAJO")
                        {
                            cuadrante.cupos = Int32.Parse(txtCuposB.Text);
                        }
                        daoCuadrante.actualizarCuadrante(cuadrante);
                    }
                    MessageBox.Show("Cupos registrados", "Confirmación", MessageBoxButtons.OK);
                    establecerComponentes(Estado.Inicial);
                }
            }
            catch
            {
                MessageBox.Show("Debe ingresar números", "Mensaje de error", MessageBoxButtons.OK);
            }
            
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            establecerComponentes(Estado.Inicial);
        }

        private void btnConfigurarCuadrantes_Click(object sender, EventArgs e)
        {
            frmConfigurarCuadrantes panelConfigurarCuadrantes =
                new frmConfigurarCuadrantes(Estado.Inicial, _menuPlanificacion, _panelInicioSesion);

            this.Hide();
            panelConfigurarCuadrantes.llenarUsuario();
            panelConfigurarCuadrantes.Show();
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnCupos_Click(object sender, EventArgs e)
        {

        }

        public void llenarUsuario()
        {
            txtNombre.Text = Program.colaborador.nombres + " " + Program.colaborador.apellidos;
            txtArea.Text = Program.colaborador.area.nombre;
            txtCorreo.Text = Program.colaborador.correo;
        }

        private void cboArea_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboArea.DataSource != null)
            {
                establecerComponentes(Estado.Inicial);
                AreaWS.area area = (AreaWS.area)cboArea.SelectedItem;

                //Cuento cantidad colaboradores
                try
                {
                    listaTotal = new BindingList<EvaluacionTotalWS.evaluacionTotal>(daoEvaluacion.listar_calibracion(area.id_Area));
                    txtCantidad.Text = listaTotal.Count().ToString();
                    cantidad = listaTotal.Count();
                }
                catch (Exception ex)
                {
                    txtCantidad.Text = "0";
                    cantidad = 0;
                }
                //Listo los cuadrantes
                lista = new BindingList<CuadranteWS.cuadrante>(daoCuadrante.listarCuadrante(area.id_Area));
                foreach (CuadranteWS.cuadrante cuadrante in lista)
                {
                    if (cuadrante.ejes.ejey=="A" && cuadrante.ejes.ejex=="BAJO")
                    {
                        txtCuposA.Text = cuadrante.cupos.ToString();
                    }
                    if (cuadrante.ejes.ejey == "B" && cuadrante.ejes.ejex == "BAJO")
                    {
                        txtCuposB.Text = cuadrante.cupos.ToString();
                    }
                }
            }

        }

        private void txtCuposA_TextChanged(object sender, EventArgs e)
        {
            int num,num2=0;

            try { num2 = Int32.Parse(txtCuposB.Text); }
            catch(Exception ex){ }

            try
            {
                num = Int32.Parse(txtCuposA.Text);
                if (num<0 || num>cantidad || num+num2>cantidad)
                    txtCuposA.ForeColor = Color.Red;
                else
                    txtCuposA.ForeColor = Color.Black;
            }
            catch
            {
                txtCuposA.ForeColor = Color.Red;
            }
        }

        private void txtCuposB_TextChanged(object sender, EventArgs e)
        {
            int num,num2 = 0;

            try { num2 = Int32.Parse(txtCuposA.Text); }
            catch (Exception ex) { }

            try
            {
                num = Int32.Parse(txtCuposB.Text);
                if (num < 0 || num > cantidad || num + num2 > cantidad)
                    txtCuposB.ForeColor = Color.Red;
                else
                    txtCuposB.ForeColor = Color.Black;
            }
            catch
            {
                txtCuposB.ForeColor = Color.Red;
            }
        }
    }
}
