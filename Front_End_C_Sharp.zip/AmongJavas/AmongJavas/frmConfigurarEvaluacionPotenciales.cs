﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AmongJavas
{
    public partial class frmConfigurarEvaluacionPotenciales : Form
    {
        private frmInicioSesion panelInicioSesion;
        private frmMenuEvaluacion menuEvaluacion;
        private ColaboradorWS.ColaboradorWSClient daoColaborador;
        private NotaCriterioWS.NotaCriterioWSClient daoNotaCriterio;
        private NotaCriterioWS.notaCriterio criterioSeleccionado;
        public frmConfigurarEvaluacionPotenciales(frmInicioSesion panelInicioSesion, frmMenuEvaluacion menuEvaluacion)
        {
            InitializeComponent();
            this.panelInicioSesion = panelInicioSesion;
            this.menuEvaluacion = menuEvaluacion;
            daoColaborador = new ColaboradorWS.ColaboradorWSClient();
            daoNotaCriterio = new NotaCriterioWS.NotaCriterioWSClient();
            //Llena el combobox
            ColaboradorWS.colaborador cc;
            cbEmpleado.ValueMember = "idColaborador";
            cbEmpleado.DisplayMember = "nombreCompleto";
            cbEmpleado.DataSource = daoColaborador.listar_subordinados(Program.colaborador.idColaborador);
            llenarTabla();
            deshabilitaEtapa();
        }
        public void deshabilitaEtapa()
        {
            if (Program.cronograma.etapa != 1) //No es etapa Evaluacion
            {
                panelIndi.Visible = false;
            }
        }
        private void llenarTabla()
        {
            if (cbEmpleado.DataSource != null)
            {
                ColaboradorWS.colaborador cola = (ColaboradorWS.colaborador)cbEmpleado.SelectedItem;
                dgvCompetencias.AutoGenerateColumns = false;
                if (daoNotaCriterio.listarNotaPorColaborador(cola.idColaborador,2) != null)
                    dgvCompetencias.DataSource = new BindingList<NotaCriterioWS.notaCriterio>
                        (daoNotaCriterio.listarNotaPorColaborador(cola.idColaborador,2).ToArray());
                else
                    dgvCompetencias.DataSource = null;
            }
            else
                dgvCompetencias.DataSource = null;
        }
        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnCerrarSesion_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.panelInicioSesion.Show();
            this.Close();
        }

        private void btnAtras_Click(object sender, EventArgs e)
        {
            this.menuEvaluacion.Show();
            this.Close();
        }

        private void btnEvaluarCompetencias_Click(object sender, EventArgs e)
        {
            frmConfigurarEvaluacionCompetencias panelVecino =
                new frmConfigurarEvaluacionCompetencias(this.panelInicioSesion, this.menuEvaluacion);

            panelVecino.llenarUsuario();
            panelVecino.Show();
            this.Close();
        }

        private void btnEvaluarObjetivos_Click(object sender, EventArgs e)
        {
            frmConfigurarEvaluacionObjetivos panelVecino =
                new frmConfigurarEvaluacionObjetivos(this.panelInicioSesion, this.menuEvaluacion);

            panelVecino.llenarUsuario();
            panelVecino.Show();
            this.Close();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (dgvCompetencias.RowCount > 0)
            {
                criterioSeleccionado = (NotaCriterioWS.notaCriterio)dgvCompetencias.CurrentRow.DataBoundItem;
                frmOscuro pp = new frmOscuro();
                pp.SetBounds(0, 0, this.Width, this.Height);
                pp.Show();
                ColaboradorWS.colaborador cola = (ColaboradorWS.colaborador)cbEmpleado.SelectedItem;
                frmEvaluarPotencial panelGestionarPotenciales = new frmEvaluarPotencial(criterioSeleccionado,cola.nombreCompleto);
                if (panelGestionarPotenciales.ShowDialog() == DialogResult.OK)
                {

                }
                llenarTabla();
                pp.Close();
            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Desea registrar la Evaluación?", "Mensaje de confirmación", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                MessageBox.Show("Evaluación registrada", "Confirmación", MessageBoxButtons.OK);
            }
        }

        public void llenarUsuario()
        {
            txtNombre.Text = Program.colaborador.nombres + " " + Program.colaborador.apellidos;
            txtArea.Text = Program.colaborador.area.nombre;
            txtCorreo.Text = Program.colaborador.correo;
        }

        private void cbEmpleado_SelectedIndexChanged(object sender, EventArgs e)
        {
            llenarTabla();
        }
    }
}
