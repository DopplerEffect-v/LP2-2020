﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AmongJavas
{
    public partial class frmConfigurarCronograma : Form
    {
        private frmInicioSesion panelInicioSesion;
        private frmMenuPlanificacion menuPlanificacion;
        private CronogramaWS.CronogramaWSClient daoCronograma;
        public frmConfigurarCronograma(frmInicioSesion panelInicioSesion, frmMenuPlanificacion menuPlanificacion)
        {
            InitializeComponent();

            txtNombre.Enabled = false;
            txtArea.Enabled = false;
            txtCorreo.Enabled = false;

            this.panelInicioSesion = panelInicioSesion;
            this.menuPlanificacion = menuPlanificacion;
            daoCronograma = new CronogramaWS.CronogramaWSClient();
            establecerComponentes(Estado.Inicial);

            dtpFechaInicioPlanificacion.Value = Program.cronograma.FECHA_INICIO_P;
            dtpFechaFinPlanificacion.Value = Program.cronograma.FECHA_FIN_P;
            dtpFechaNotificacionPlanificacion.Value= Program.cronograma.FECHA_NOTIFICACION_P;


            dtpFechaInicioEvaluacion.Value= Program.cronograma.FECHA_INICIO_E;
            dtpFechaFinEvaluacion.Value= Program.cronograma.FECHA_FIN_E;
            dtpFechaNotificacionEvaluacion.Value= Program.cronograma.FECHA_NOTIFICACION_E;

            dtpFechaInicioCalibracion.Value= Program.cronograma.FECHA_INICIO_C;
            dtpFechaFinCalibracion.Value= Program.cronograma.FECHA_FIN_C;
            dtpFechaNotificacionCalibracion.Value= Program.cronograma.FECHA_NOTIFICACION_C;

            dtpFechaInicioReportes.Value= Program.cronograma.FECHA_INICIO_R;
            dtpFechaFinReportes.Value= Program.cronograma.FECHA_FIN_R;
            dtpFechaNotificacionReportes.Value= Program.cronograma.FECHA_NOTIFICACION_R;
            deshabilitaEtapa();
        }
        public void deshabilitaEtapa()
        {
            if (Program.cronograma.etapa != 0)
            {
                btnActualizar.Visible = false;
                btnGuardar.Visible = false;
                btnCancelar.Visible = false;
            }
        }
        public void establecerComponentes(Estado estado)
        {
            switch (estado)
            {
               case Estado.Inicial:
                    dtpFechaInicioEvaluacion.Enabled = false;
                    dtpFechaInicioCalibracion.Enabled = false;
                    dtpFechaInicioPlanificacion.Enabled = false;
                    dtpFechaInicioReportes.Enabled = false;

                    dtpFechaFinCalibracion.Enabled = false;
                    dtpFechaFinEvaluacion.Enabled = false;
                    dtpFechaFinPlanificacion.Enabled = false;
                    dtpFechaFinReportes.Enabled = false;

                    dtpFechaNotificacionCalibracion.Enabled = false;
                    dtpFechaNotificacionEvaluacion.Enabled = false;
                    dtpFechaNotificacionPlanificacion.Enabled = false;
                    dtpFechaNotificacionReportes.Enabled = false;
                    
                    habilitaBoton(btnGuardar, false);
                    habilitaBoton(btnCancelar, false);
                    habilitaBoton(btnActualizar, true);
                    break;

                case Estado.Actualizar:
                    dtpFechaInicioEvaluacion.Enabled = true;
                    dtpFechaInicioCalibracion.Enabled = true;
                    dtpFechaInicioPlanificacion.Enabled = true;
                    dtpFechaInicioReportes.Enabled = true;

                    dtpFechaFinCalibracion.Enabled = true;
                    dtpFechaFinEvaluacion.Enabled = true;
                    dtpFechaFinPlanificacion.Enabled = true;
                    dtpFechaFinReportes.Enabled = true;

                    dtpFechaNotificacionCalibracion.Enabled = true;
                    dtpFechaNotificacionEvaluacion.Enabled = true;
                    dtpFechaNotificacionPlanificacion.Enabled = true;
                    dtpFechaNotificacionReportes.Enabled = true;

                    habilitaBoton(btnGuardar,true);
                    habilitaBoton(btnCancelar, true);
                    habilitaBoton(btnActualizar, false);
                    break;
            }
        }
        private void habilitaBoton(Button boton, bool estado)
        {
            boton.Enabled = estado;
            if (estado == true)
                boton.BackColor = Color.FromArgb(46, 44, 51);
            if (estado == false)
                boton.BackColor = Color.FromArgb(246, 245, 247);

        }
        private void btnAtras_Click(object sender, EventArgs e)
        {
            this.Hide();
            this.menuPlanificacion.Show();
        }

        private void btnCerrarSesion_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            this.panelInicioSesion.Show();
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            establecerComponentes(Estado.Actualizar);
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (VerificaFechas() < 12)
                MessageBox.Show("Rango de Fechas incorrecto\nVerifique fechas en rojo", "Mensaje de error", MessageBoxButtons.OK);
            else
            if (MessageBox.Show("¿Desea registrar el Cronograma?", "Mensaje de confirmación", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Program.cronograma.FECHA_INICIO_P = dtpFechaInicioPlanificacion.Value;
                Program.cronograma.FECHA_INICIO_PSpecified = true;
                Program.cronograma.FECHA_FIN_P = dtpFechaFinPlanificacion.Value;
                Program.cronograma.FECHA_FIN_PSpecified = true;
                Program.cronograma.FECHA_NOTIFICACION_P = dtpFechaNotificacionPlanificacion.Value;
                Program.cronograma.FECHA_NOTIFICACION_PSpecified = true;

                Program.cronograma.FECHA_INICIO_E = dtpFechaInicioEvaluacion.Value;
                Program.cronograma.FECHA_INICIO_ESpecified = true;
                Program.cronograma.FECHA_FIN_E = dtpFechaFinEvaluacion.Value;
                Program.cronograma.FECHA_FIN_ESpecified = true;
                Program.cronograma.FECHA_NOTIFICACION_E = dtpFechaNotificacionEvaluacion.Value;
                Program.cronograma.FECHA_NOTIFICACION_ESpecified = true;

                Program.cronograma.FECHA_INICIO_C = dtpFechaInicioCalibracion.Value;
                Program.cronograma.FECHA_INICIO_CSpecified = true;
                Program.cronograma.FECHA_FIN_C = dtpFechaFinCalibracion.Value;
                Program.cronograma.FECHA_FIN_CSpecified = true;
                Program.cronograma.FECHA_NOTIFICACION_C = dtpFechaNotificacionCalibracion.Value;
                Program.cronograma.FECHA_NOTIFICACION_CSpecified = true;

                Program.cronograma.FECHA_INICIO_R = dtpFechaInicioReportes.Value;
                Program.cronograma.FECHA_INICIO_RSpecified = true;
                Program.cronograma.FECHA_FIN_R = dtpFechaFinReportes.Value;
                Program.cronograma.FECHA_FIN_RSpecified = true;
                Program.cronograma.FECHA_NOTIFICACION_R = dtpFechaNotificacionReportes.Value;
                Program.cronograma.FECHA_NOTIFICACION_RSpecified = true;

                daoCronograma.actualizarCronograma(Program.cronograma);
                MessageBox.Show("Cronograma registrado", "Confirmación", MessageBoxButtons.OK);
                establecerComponentes(Estado.Inicial);
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            establecerComponentes(Estado.Inicial);
        }

        private void btnCofigurarPesos_Click(object sender, EventArgs e)
        {
            frmConfigurarPesosEvaluacion panelConfigurarPesosEvaluacion =
                new frmConfigurarPesosEvaluacion(this.panelInicioSesion, this.menuPlanificacion);

            panelConfigurarPesosEvaluacion.llenarUsuario();
            panelConfigurarPesosEvaluacion.Show();
            this.Close();
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        public void llenarUsuario()
        {
            txtNombre.Text = Program.colaborador.nombres + " " + Program.colaborador.apellidos;
            txtArea.Text = Program.colaborador.area.nombre;
            txtCorreo.Text = Program.colaborador.correo;
        }

        private int VerificaFechas()
        {
            int valIniP = 1, valIniE = 1, valIniC = 1, valIniR = 1,
                valFinP = 1, valFinE = 1, valFinC = 1, valFinR = 1,
                valNotP = 1, valNotE = 1, valNotC = 1, valNotR = 1;
            //PlaIni - PlaFin(EvaIni)
            if (DateTime.Compare(dtpFechaFinPlanificacion.Value, dtpFechaInicioPlanificacion.Value) <= 0)
            {
                valIniP = 0; valFinP = 0; valIniE = 0;
            }
            //EvaIni - EvaFin(CalIni)
            if (DateTime.Compare(dtpFechaFinEvaluacion.Value, dtpFechaInicioEvaluacion.Value) <= 0)
            {
                valIniE = 0; valFinE = 0; valIniC = 0;
            }
            //CalIni - CalFin(RepIni)
            if (DateTime.Compare(dtpFechaFinCalibracion.Value, dtpFechaInicioCalibracion.Value) <= 0)
            {
                valIniC = 0; valFinC = 0; valIniR = 0;
            }
            //RepIni - RepFin
            if (DateTime.Compare(dtpFechaFinReportes.Value, dtpFechaInicioReportes.Value) <= 0)
            {
                valIniR = 0; valFinR = 0;
            }

            //Recordatorio planificacion
            if (DateTime.Compare(dtpFechaInicioPlanificacion.Value, dtpFechaNotificacionPlanificacion.Value) >= 0 ||
                DateTime.Compare(dtpFechaFinPlanificacion.Value, dtpFechaNotificacionPlanificacion.Value) <= 0)
            {
                valNotP = 0;
            }

            //Recordatorio evaluacion
            if (DateTime.Compare(dtpFechaInicioEvaluacion.Value, dtpFechaNotificacionEvaluacion.Value) >= 0 ||
                DateTime.Compare(dtpFechaFinEvaluacion.Value, dtpFechaNotificacionEvaluacion.Value) <= 0)
            {
                valNotE = 0;
            }

            //Recordatorio calibracion
            if (DateTime.Compare(dtpFechaInicioCalibracion.Value, dtpFechaNotificacionCalibracion.Value) >= 0 ||
                DateTime.Compare(dtpFechaFinCalibracion.Value, dtpFechaNotificacionCalibracion.Value) <= 0)
            {
                valNotC = 0;
            }

            //Recordatorio reporte
            if (DateTime.Compare(dtpFechaInicioReportes.Value, dtpFechaNotificacionReportes.Value) >= 0 ||
                DateTime.Compare(dtpFechaFinReportes.Value, dtpFechaNotificacionReportes.Value) <= 0)
            {
                valNotR = 0;
            }

            if (valIniP == 1) lblFechaInicioPlanificacion.ForeColor = Color.Black; else lblFechaInicioPlanificacion.ForeColor = Color.Red;
            if (valFinP == 1) lblFechaFinPlanificacion.ForeColor = Color.Black; else lblFechaFinPlanificacion.ForeColor = Color.Red;
            if (valNotP == 1) lblFechaNotificacionPlanificacion.ForeColor = Color.Black; else lblFechaNotificacionPlanificacion.ForeColor = Color.Red;
            if (valIniE == 1) lblFechaInicioEvaluacion.ForeColor = Color.Black; else lblFechaInicioEvaluacion.ForeColor = Color.Red;
            if (valFinE == 1) lblFechaFinEvaluacion.ForeColor = Color.Black; else lblFechaFinEvaluacion.ForeColor = Color.Red;
            if (valNotE == 1) lblFechaNotificacionEvaluacion.ForeColor = Color.Black; else lblFechaNotificacionEvaluacion.ForeColor = Color.Red;
            if (valIniC == 1) lblFechaInicioCalibracion.ForeColor = Color.Black; else lblFechaInicioCalibracion.ForeColor = Color.Red;
            if (valFinC == 1) lblFechaFinCalibracion.ForeColor = Color.Black; else lblFechaFinCalibracion.ForeColor = Color.Red;
            if (valNotC == 1) lblFechaNotificacionCalibracion.ForeColor = Color.Black; else lblFechaNotificacionCalibracion.ForeColor = Color.Red;
            if (valIniR == 1) lblFechaInicioReportes.ForeColor = Color.Black; else lblFechaInicioReportes.ForeColor = Color.Red;
            if (valFinR == 1) lblFechaFinReportes.ForeColor = Color.Black; else lblFechaFinReportes.ForeColor = Color.Red;
            if (valNotR == 1) lblFechaNotificacionReportes.ForeColor = Color.Black; else lblFechaNotificacionReportes.ForeColor = Color.Red;


            return valIniP + valIniE + valIniC + valIniR +
                valFinP + valFinE + valFinC + valFinR +
                valNotP + valNotE + valNotC + valNotR;
        }
        private void dtpFechaFinPlanificacion_ValueChanged(object sender, EventArgs e)
        {
            dtpFechaInicioEvaluacion.Value = dtpFechaFinPlanificacion.Value;
            VerificaFechas();
        }

        private void dtpFechaFinEvaluacion_ValueChanged(object sender, EventArgs e)
        {
            dtpFechaInicioCalibracion.Value = dtpFechaFinEvaluacion.Value;
            VerificaFechas();
        }

        private void dtpFechaFinCalibracion_ValueChanged(object sender, EventArgs e)
        {
            dtpFechaInicioReportes.Value = dtpFechaFinCalibracion.Value;
            VerificaFechas();
        }

        private void dtpFechaInicioPlanificacion_ValueChanged(object sender, EventArgs e)
        {
            VerificaFechas();
        }

        private void dtpFechaInicioEvaluacion_ValueChanged(object sender, EventArgs e)
        {
            VerificaFechas();
        }

        private void dtpFechaInicioCalibracion_ValueChanged(object sender, EventArgs e)
        {
            VerificaFechas();
        }

        private void dtpFechaInicioReportes_ValueChanged(object sender, EventArgs e)
        {
            VerificaFechas();
        }

        private void dtpFechaNotificacionPlanificacion_ValueChanged(object sender, EventArgs e)
        {
            VerificaFechas();
        }

        private void dtpFechaNotificacionEvaluacion_ValueChanged(object sender, EventArgs e)
        {
            VerificaFechas();
        }

        private void dtpFechaNotificacionCalibracion_ValueChanged(object sender, EventArgs e)
        {
            VerificaFechas();
        }

        private void dtpFechaNotificacionReportes_ValueChanged(object sender, EventArgs e)
        {
            VerificaFechas();
        }

        private void dtpFechaFinReportes_ValueChanged(object sender, EventArgs e)
        {
            VerificaFechas();
        }
    }
}
