﻿namespace AmongJavas
{
    partial class frmGestionarObjetivos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnAtras = new System.Windows.Forms.PictureBox();
            this.lblGestionarObjetivos = new System.Windows.Forms.Label();
            this.txtId = new System.Windows.Forms.TextBox();
            this.lblNombre = new System.Windows.Forms.Label();
            this.txtDescripcion = new System.Windows.Forms.TextBox();
            this.lblDescripcion = new System.Windows.Forms.Label();
            this.txtObservaciones = new System.Windows.Forms.TextBox();
            this.lblObservaciones = new System.Windows.Forms.Label();
            this.lblMeta = new System.Windows.Forms.Label();
            this.txtMeta = new System.Windows.Forms.TextBox();
            this.lblUnidad = new System.Windows.Forms.Label();
            this.txtUnidades = new System.Windows.Forms.TextBox();
            this.btnEditar = new System.Windows.Forms.Button();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.cbAprobado = new System.Windows.Forms.CheckBox();
            this.lblNota = new System.Windows.Forms.Label();
            this.lblNotaAuto = new System.Windows.Forms.Label();
            this.txtNota = new System.Windows.Forms.TextBox();
            this.txtNotaAuto = new System.Windows.Forms.TextBox();
            this.cbDenegado = new System.Windows.Forms.CheckBox();
            this.lblLogro = new System.Windows.Forms.Label();
            this.txtLogroPersonal = new System.Windows.Forms.TextBox();
            this.txtLogroEvaluador = new System.Windows.Forms.TextBox();
            this.lblLogroPer = new System.Windows.Forms.Label();
            this.lblMedida = new System.Windows.Forms.Label();
            this.lblCantidad = new System.Windows.Forms.Label();
            this.lblEstado = new System.Windows.Forms.Label();
            this.cbGenerado = new System.Windows.Forms.CheckBox();
            this.txtColaborador = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnAtras)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(4)))), ((int)(((byte)(119)))), ((int)(((byte)(205)))));
            this.panel1.Controls.Add(this.btnAtras);
            this.panel1.Controls.Add(this.lblGestionarObjetivos);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(850, 62);
            this.panel1.TabIndex = 44;
            // 
            // btnAtras
            // 
            this.btnAtras.Image = global::AmongJavas.Properties.Resources.IconoAtras2;
            this.btnAtras.Location = new System.Drawing.Point(27, 6);
            this.btnAtras.Name = "btnAtras";
            this.btnAtras.Size = new System.Drawing.Size(53, 53);
            this.btnAtras.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnAtras.TabIndex = 72;
            this.btnAtras.TabStop = false;
            this.btnAtras.Click += new System.EventHandler(this.btnAtras_Click);
            // 
            // lblGestionarObjetivos
            // 
            this.lblGestionarObjetivos.AutoSize = true;
            this.lblGestionarObjetivos.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.lblGestionarObjetivos.ForeColor = System.Drawing.Color.White;
            this.lblGestionarObjetivos.Location = new System.Drawing.Point(98, 16);
            this.lblGestionarObjetivos.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGestionarObjetivos.Name = "lblGestionarObjetivos";
            this.lblGestionarObjetivos.Size = new System.Drawing.Size(240, 28);
            this.lblGestionarObjetivos.TabIndex = 7;
            this.lblGestionarObjetivos.Text = "Gestionar Objetivos";
            // 
            // txtId
            // 
            this.txtId.Location = new System.Drawing.Point(230, 126);
            this.txtId.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(560, 26);
            this.txtId.TabIndex = 46;
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.lblNombre.ForeColor = System.Drawing.Color.DimGray;
            this.lblNombre.Location = new System.Drawing.Point(13, 126);
            this.lblNombre.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(148, 28);
            this.lblNombre.TabIndex = 45;
            this.lblNombre.Text = "ID Objetivo:";
            // 
            // txtDescripcion
            // 
            this.txtDescripcion.Location = new System.Drawing.Point(230, 182);
            this.txtDescripcion.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtDescripcion.Multiline = true;
            this.txtDescripcion.Name = "txtDescripcion";
            this.txtDescripcion.Size = new System.Drawing.Size(560, 75);
            this.txtDescripcion.TabIndex = 48;
            // 
            // lblDescripcion
            // 
            this.lblDescripcion.AutoSize = true;
            this.lblDescripcion.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.lblDescripcion.ForeColor = System.Drawing.Color.DimGray;
            this.lblDescripcion.Location = new System.Drawing.Point(13, 182);
            this.lblDescripcion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDescripcion.Name = "lblDescripcion";
            this.lblDescripcion.Size = new System.Drawing.Size(157, 28);
            this.lblDescripcion.TabIndex = 47;
            this.lblDescripcion.Text = "Descripcion:";
            // 
            // txtObservaciones
            // 
            this.txtObservaciones.Location = new System.Drawing.Point(230, 283);
            this.txtObservaciones.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtObservaciones.Multiline = true;
            this.txtObservaciones.Name = "txtObservaciones";
            this.txtObservaciones.Size = new System.Drawing.Size(560, 75);
            this.txtObservaciones.TabIndex = 50;
            // 
            // lblObservaciones
            // 
            this.lblObservaciones.AutoSize = true;
            this.lblObservaciones.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.lblObservaciones.ForeColor = System.Drawing.Color.DimGray;
            this.lblObservaciones.Location = new System.Drawing.Point(13, 283);
            this.lblObservaciones.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblObservaciones.Name = "lblObservaciones";
            this.lblObservaciones.Size = new System.Drawing.Size(194, 28);
            this.lblObservaciones.TabIndex = 49;
            this.lblObservaciones.Text = "Observaciones:";
            // 
            // lblMeta
            // 
            this.lblMeta.AutoSize = true;
            this.lblMeta.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.lblMeta.ForeColor = System.Drawing.Color.DimGray;
            this.lblMeta.Location = new System.Drawing.Point(13, 372);
            this.lblMeta.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMeta.Name = "lblMeta";
            this.lblMeta.Size = new System.Drawing.Size(79, 28);
            this.lblMeta.TabIndex = 51;
            this.lblMeta.Text = "Meta:";
            // 
            // txtMeta
            // 
            this.txtMeta.Location = new System.Drawing.Point(230, 384);
            this.txtMeta.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtMeta.Name = "txtMeta";
            this.txtMeta.Size = new System.Drawing.Size(126, 26);
            this.txtMeta.TabIndex = 52;
            // 
            // lblUnidad
            // 
            this.lblUnidad.AutoSize = true;
            this.lblUnidad.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.lblUnidad.ForeColor = System.Drawing.Color.DimGray;
            this.lblUnidad.Location = new System.Drawing.Point(13, 438);
            this.lblUnidad.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUnidad.Name = "lblUnidad";
            this.lblUnidad.Size = new System.Drawing.Size(95, 28);
            this.lblUnidad.TabIndex = 53;
            this.lblUnidad.Text = "Unidad";
            // 
            // txtUnidades
            // 
            this.txtUnidades.Location = new System.Drawing.Point(230, 465);
            this.txtUnidades.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtUnidades.Name = "txtUnidades";
            this.txtUnidades.Size = new System.Drawing.Size(126, 26);
            this.txtUnidades.TabIndex = 54;
            // 
            // btnEditar
            // 
            this.btnEditar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.btnEditar.FlatAppearance.BorderSize = 0;
            this.btnEditar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnEditar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditar.ForeColor = System.Drawing.Color.White;
            this.btnEditar.Location = new System.Drawing.Point(227, 624);
            this.btnEditar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnEditar.Name = "btnEditar";
            this.btnEditar.Size = new System.Drawing.Size(129, 35);
            this.btnEditar.TabIndex = 61;
            this.btnEditar.Text = "Editar";
            this.btnEditar.UseVisualStyleBackColor = false;
            this.btnEditar.Click += new System.EventHandler(this.btnEditar_Click);
            // 
            // btnGuardar
            // 
            this.btnGuardar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.btnGuardar.FlatAppearance.BorderSize = 0;
            this.btnGuardar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnGuardar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGuardar.ForeColor = System.Drawing.Color.White;
            this.btnGuardar.Location = new System.Drawing.Point(392, 624);
            this.btnGuardar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(129, 35);
            this.btnGuardar.TabIndex = 62;
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.UseVisualStyleBackColor = false;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // btnCancelar
            // 
            this.btnCancelar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(44)))), ((int)(((byte)(51)))));
            this.btnCancelar.FlatAppearance.BorderSize = 0;
            this.btnCancelar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCancelar.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancelar.ForeColor = System.Drawing.Color.White;
            this.btnCancelar.Location = new System.Drawing.Point(559, 624);
            this.btnCancelar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(129, 35);
            this.btnCancelar.TabIndex = 63;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = false;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // cbAprobado
            // 
            this.cbAprobado.AutoSize = true;
            this.cbAprobado.Enabled = false;
            this.cbAprobado.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.cbAprobado.ForeColor = System.Drawing.Color.DimGray;
            this.cbAprobado.Location = new System.Drawing.Point(632, 421);
            this.cbAprobado.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cbAprobado.Name = "cbAprobado";
            this.cbAprobado.Size = new System.Drawing.Size(158, 32);
            this.cbAprobado.TabIndex = 64;
            this.cbAprobado.Text = "Aprobado";
            this.cbAprobado.UseVisualStyleBackColor = true;
            this.cbAprobado.CheckedChanged += new System.EventHandler(this.cbAprobado_CheckedChanged);
            // 
            // lblNota
            // 
            this.lblNota.AutoSize = true;
            this.lblNota.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.lblNota.ForeColor = System.Drawing.Color.DimGray;
            this.lblNota.Location = new System.Drawing.Point(387, 558);
            this.lblNota.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNota.Name = "lblNota";
            this.lblNota.Size = new System.Drawing.Size(75, 28);
            this.lblNota.TabIndex = 65;
            this.lblNota.Text = "Nota:";
            // 
            // lblNotaAuto
            // 
            this.lblNotaAuto.AutoSize = true;
            this.lblNotaAuto.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.lblNotaAuto.ForeColor = System.Drawing.Color.DimGray;
            this.lblNotaAuto.Location = new System.Drawing.Point(387, 514);
            this.lblNotaAuto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNotaAuto.Name = "lblNotaAuto";
            this.lblNotaAuto.Size = new System.Drawing.Size(266, 28);
            this.lblNotaAuto.TabIndex = 66;
            this.lblNotaAuto.Text = "Nota Autoevaluacion:";
            // 
            // txtNota
            // 
            this.txtNota.Location = new System.Drawing.Point(664, 564);
            this.txtNota.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtNota.Name = "txtNota";
            this.txtNota.Size = new System.Drawing.Size(126, 26);
            this.txtNota.TabIndex = 67;
            // 
            // txtNotaAuto
            // 
            this.txtNotaAuto.Location = new System.Drawing.Point(664, 518);
            this.txtNotaAuto.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtNotaAuto.Name = "txtNotaAuto";
            this.txtNotaAuto.Size = new System.Drawing.Size(126, 26);
            this.txtNotaAuto.TabIndex = 68;
            // 
            // cbDenegado
            // 
            this.cbDenegado.AutoSize = true;
            this.cbDenegado.Enabled = false;
            this.cbDenegado.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.cbDenegado.ForeColor = System.Drawing.Color.DimGray;
            this.cbDenegado.Location = new System.Drawing.Point(632, 461);
            this.cbDenegado.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cbDenegado.Name = "cbDenegado";
            this.cbDenegado.Size = new System.Drawing.Size(162, 32);
            this.cbDenegado.TabIndex = 69;
            this.cbDenegado.Text = "Denegado";
            this.cbDenegado.UseVisualStyleBackColor = true;
            this.cbDenegado.CheckedChanged += new System.EventHandler(this.cbDenegado_CheckedChanged);
            // 
            // lblLogro
            // 
            this.lblLogro.AutoSize = true;
            this.lblLogro.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.lblLogro.ForeColor = System.Drawing.Color.DimGray;
            this.lblLogro.Location = new System.Drawing.Point(13, 560);
            this.lblLogro.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLogro.Name = "lblLogro";
            this.lblLogro.Size = new System.Drawing.Size(207, 28);
            this.lblLogro.TabIndex = 55;
            this.lblLogro.Text = "Logro Evaluador:";
            // 
            // txtLogroPersonal
            // 
            this.txtLogroPersonal.Location = new System.Drawing.Point(230, 514);
            this.txtLogroPersonal.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtLogroPersonal.Name = "txtLogroPersonal";
            this.txtLogroPersonal.Size = new System.Drawing.Size(126, 26);
            this.txtLogroPersonal.TabIndex = 56;
            this.txtLogroPersonal.TextChanged += new System.EventHandler(this.txtLogroPersonal_TextChanged);
            // 
            // txtLogroEvaluador
            // 
            this.txtLogroEvaluador.Location = new System.Drawing.Point(230, 562);
            this.txtLogroEvaluador.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtLogroEvaluador.Name = "txtLogroEvaluador";
            this.txtLogroEvaluador.Size = new System.Drawing.Size(126, 26);
            this.txtLogroEvaluador.TabIndex = 71;
            this.txtLogroEvaluador.TextChanged += new System.EventHandler(this.txtLogroEvaluador_TextChanged);
            // 
            // lblLogroPer
            // 
            this.lblLogroPer.AutoSize = true;
            this.lblLogroPer.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.lblLogroPer.ForeColor = System.Drawing.Color.DimGray;
            this.lblLogroPer.Location = new System.Drawing.Point(13, 514);
            this.lblLogroPer.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLogroPer.Name = "lblLogroPer";
            this.lblLogroPer.Size = new System.Drawing.Size(189, 28);
            this.lblLogroPer.TabIndex = 70;
            this.lblLogroPer.Text = "Logro Personal:";
            // 
            // lblMedida
            // 
            this.lblMedida.AutoSize = true;
            this.lblMedida.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.lblMedida.ForeColor = System.Drawing.Color.DimGray;
            this.lblMedida.Location = new System.Drawing.Point(13, 464);
            this.lblMedida.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMedida.Name = "lblMedida";
            this.lblMedida.Size = new System.Drawing.Size(149, 28);
            this.lblMedida.TabIndex = 53;
            this.lblMedida.Text = "de medida:";
            // 
            // lblCantidad
            // 
            this.lblCantidad.AutoSize = true;
            this.lblCantidad.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Bold);
            this.lblCantidad.ForeColor = System.Drawing.Color.DimGray;
            this.lblCantidad.Location = new System.Drawing.Point(13, 402);
            this.lblCantidad.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCantidad.Name = "lblCantidad";
            this.lblCantidad.Size = new System.Drawing.Size(114, 23);
            this.lblCantidad.TabIndex = 72;
            this.lblCantidad.Text = "(cantidad)";
            // 
            // lblEstado
            // 
            this.lblEstado.AutoSize = true;
            this.lblEstado.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.lblEstado.ForeColor = System.Drawing.Color.DimGray;
            this.lblEstado.Location = new System.Drawing.Point(497, 379);
            this.lblEstado.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEstado.Name = "lblEstado";
            this.lblEstado.Size = new System.Drawing.Size(96, 28);
            this.lblEstado.TabIndex = 73;
            this.lblEstado.Text = "Estado:";
            // 
            // cbGenerado
            // 
            this.cbGenerado.AutoSize = true;
            this.cbGenerado.Enabled = false;
            this.cbGenerado.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.cbGenerado.ForeColor = System.Drawing.Color.DimGray;
            this.cbGenerado.Location = new System.Drawing.Point(632, 379);
            this.cbGenerado.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cbGenerado.Name = "cbGenerado";
            this.cbGenerado.Size = new System.Drawing.Size(154, 32);
            this.cbGenerado.TabIndex = 74;
            this.cbGenerado.Text = "Sin revisar";
            this.cbGenerado.UseVisualStyleBackColor = true;
            this.cbGenerado.CheckedChanged += new System.EventHandler(this.cbGenerado_CheckedChanged);
            // 
            // txtColaborador
            // 
            this.txtColaborador.Enabled = false;
            this.txtColaborador.Location = new System.Drawing.Point(227, 79);
            this.txtColaborador.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtColaborador.Name = "txtColaborador";
            this.txtColaborador.Size = new System.Drawing.Size(563, 26);
            this.txtColaborador.TabIndex = 76;
            this.txtColaborador.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.DimGray;
            this.label3.Location = new System.Drawing.Point(13, 75);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(169, 28);
            this.label3.TabIndex = 75;
            this.label3.Text = "Colaborador:";
            this.label3.Visible = false;
            // 
            // frmGestionarObjetivos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(246)))), ((int)(((byte)(245)))), ((int)(((byte)(247)))));
            this.ClientSize = new System.Drawing.Size(850, 698);
            this.Controls.Add(this.txtColaborador);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cbGenerado);
            this.Controls.Add(this.lblEstado);
            this.Controls.Add(this.lblCantidad);
            this.Controls.Add(this.txtLogroEvaluador);
            this.Controls.Add(this.lblLogroPer);
            this.Controls.Add(this.cbDenegado);
            this.Controls.Add(this.txtNotaAuto);
            this.Controls.Add(this.txtNota);
            this.Controls.Add(this.lblNotaAuto);
            this.Controls.Add(this.lblNota);
            this.Controls.Add(this.cbAprobado);
            this.Controls.Add(this.btnCancelar);
            this.Controls.Add(this.btnGuardar);
            this.Controls.Add(this.btnEditar);
            this.Controls.Add(this.txtLogroPersonal);
            this.Controls.Add(this.lblLogro);
            this.Controls.Add(this.txtUnidades);
            this.Controls.Add(this.lblMedida);
            this.Controls.Add(this.lblUnidad);
            this.Controls.Add(this.txtMeta);
            this.Controls.Add(this.lblMeta);
            this.Controls.Add(this.txtObservaciones);
            this.Controls.Add(this.lblObservaciones);
            this.Controls.Add(this.txtDescripcion);
            this.Controls.Add(this.lblDescripcion);
            this.Controls.Add(this.txtId);
            this.Controls.Add(this.lblNombre);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "frmGestionarObjetivos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GestionarObjetivos";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.btnAtras)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblGestionarObjetivos;
        private System.Windows.Forms.TextBox txtId;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.TextBox txtDescripcion;
        private System.Windows.Forms.Label lblDescripcion;
        private System.Windows.Forms.TextBox txtObservaciones;
        private System.Windows.Forms.Label lblObservaciones;
        private System.Windows.Forms.Label lblMeta;
        private System.Windows.Forms.TextBox txtMeta;
        private System.Windows.Forms.Label lblUnidad;
        private System.Windows.Forms.TextBox txtUnidades;
        private System.Windows.Forms.Button btnEditar;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.CheckBox cbAprobado;
        private System.Windows.Forms.Label lblNota;
        private System.Windows.Forms.Label lblNotaAuto;
        private System.Windows.Forms.TextBox txtNota;
        private System.Windows.Forms.TextBox txtNotaAuto;
        private System.Windows.Forms.CheckBox cbDenegado;
        private System.Windows.Forms.Label lblLogro;
        private System.Windows.Forms.TextBox txtLogroPersonal;
        private System.Windows.Forms.TextBox txtLogroEvaluador;
        private System.Windows.Forms.Label lblLogroPer;
        private System.Windows.Forms.PictureBox btnAtras;
        private System.Windows.Forms.Label lblMedida;
        private System.Windows.Forms.Label lblCantidad;
        private System.Windows.Forms.Label lblEstado;
        private System.Windows.Forms.CheckBox cbGenerado;
        private System.Windows.Forms.TextBox txtColaborador;
        private System.Windows.Forms.Label label3;
    }
}