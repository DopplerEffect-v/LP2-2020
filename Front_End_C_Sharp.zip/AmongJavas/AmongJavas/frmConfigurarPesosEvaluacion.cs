﻿using AmongJavas.PesosEvaluacionWS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AmongJavas
{
    public partial class frmConfigurarPesosEvaluacion : Form
    {
        private frmInicioSesion panelInicioSesion;
        private frmMenuPlanificacion menuPlanificacion;
        private PuestoTrabajoWS.PuestoTrabajoWSClient daoPuestoTrabajo;
        private PesosEvaluacionWS.PesosEvaluacionWSClient daoPesos;
        private PesosEvaluacionWS.pesosEvaluacion pesos;
        private PuestoTrabajoWS.puestoTrabajo puesto;

        public frmConfigurarPesosEvaluacion(frmInicioSesion panelInicioSesion, frmMenuPlanificacion menuPlanificacion)
        {
            InitializeComponent();
            txtNombre.Enabled = false;
            txtArea.Enabled = false;
            txtCorreo.Enabled = false;

            this.panelInicioSesion = panelInicioSesion;
            this.menuPlanificacion = menuPlanificacion;
            daoPesos = new PesosEvaluacionWS.PesosEvaluacionWSClient();
            cbPuesto.ValueMember = "id_Puesto_Trabajo";
            cbPuesto.DisplayMember = "nombre";
            daoPuestoTrabajo = new PuestoTrabajoWS.PuestoTrabajoWSClient();
            cbPuesto.DataSource = daoPuestoTrabajo.listarPuestoTrabajo();
            establecerComponentes(Estado.Inicial);
            deshabilitaEtapa();
        }
        public void deshabilitaEtapa()
        {
            if (Program.cronograma.etapa != 0)
            {
                btnAsignar.Visible = false;
                btnGuardar.Visible = false;
                btnCancelar.Visible = false;
            }
        }
        public void establecerComponentes(Estado estado)
        {
            switch (estado)
            {
                case Estado.Inicial:
                    txtObjetivos.Enabled = false;
                    txtCompetencias.Enabled = false;

                    habilitaBoton(btnAsignar, true);
                    habilitaBoton(btnGuardar, false);
                    habilitaBoton(btnCancelar,false);
                    break;

                case Estado.Nuevo:
                    txtObjetivos.Enabled = true;
                    txtCompetencias.Enabled = true;

                    habilitaBoton(btnAsignar, false);
                    habilitaBoton(btnGuardar, true);
                    habilitaBoton(btnCancelar, true);
                    break;

            }
        }
        private void habilitaBoton(Button boton, bool estado)
        {
            boton.Enabled = estado;
            if (estado == true)
                boton.BackColor = Color.FromArgb(46, 44, 51);
            if (estado == false)
                boton.BackColor = Color.FromArgb(246, 245, 247);

        }
        private void btnAtras_Click(object sender, EventArgs e)
        {
            this.menuPlanificacion.Show();
            this.Close();
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnCerrarSesion_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.panelInicioSesion.Show();
            this.Close();
        }
        private void btnGuardar_Click(object sender, EventArgs e)
        {
            double suma;
            try
            {
                suma = Double.Parse(txtObjetivos.Text) + Double.Parse(txtCompetencias.Text);
                if (suma != 100)
                    MessageBox.Show("Los pesos deben sumar 100", "Error", MessageBoxButtons.OK);
                else
                if (MessageBox.Show("¿Desea registrar los Pesos?", "Mensaje de confirmación", MessageBoxButtons.YesNo) == DialogResult.Yes)
                    {
                        pesos.pesoObjetivos = Double.Parse(txtObjetivos.Text);
                        pesos.pesoCompetencias = Double.Parse(txtCompetencias.Text);
                        daoPesos.actualizarPesos(pesos);
                        MessageBox.Show("Pesos registrados", "Confirmación", MessageBoxButtons.OK);
                        establecerComponentes(Estado.Inicial);
                    }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Ingrese números válidos", "Error", MessageBoxButtons.OK);
            }
            
        }

        private void btnAsignar_Click(object sender, EventArgs e)
        {
            establecerComponentes(Estado.Nuevo);
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            establecerComponentes(Estado.Inicial);
        }

        private void btnCronograma_Click(object sender, EventArgs e)
        {
            frmConfigurarCronograma panelConfigurarCronograma =
                new frmConfigurarCronograma(this.panelInicioSesion, this.menuPlanificacion);

            panelConfigurarCronograma.llenarUsuario();
            panelConfigurarCronograma.Show();
            this.Close();
        }

        public void llenarUsuario()
        {
            txtNombre.Text = Program.colaborador.nombres + " " + Program.colaborador.apellidos;
            txtArea.Text = Program.colaborador.area.nombre;
            txtCorreo.Text = Program.colaborador.correo;
        }

        private void cbPuesto_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbPuesto.DataSource != null)
            {
                puesto = (PuestoTrabajoWS.puestoTrabajo)cbPuesto.SelectedItem;
                pesos = daoPesos.buscarPesos(puesto.id_Puesto_Trabajo);
                txtObjetivos.Text = pesos.pesoObjetivos.ToString();
                txtCompetencias.Text = pesos.pesoCompetencias.ToString();
            }
            
        }

        private void txtObjetivos_TextChanged(object sender, EventArgs e)
        {
            double num;
            try {
                num = Double.Parse(txtObjetivos.Text);
                if (num>=0 && num <= 100) {
                    txtCompetencias.Text = (100 - num).ToString();
                    txtObjetivos.ForeColor = Color.Black;
                }
                else
                    txtObjetivos.ForeColor = Color.Red;
            }
            catch(Exception ex)
            {
                txtObjetivos.ForeColor = Color.Red;
            }
        }

        private void txtCompetencias_TextChanged(object sender, EventArgs e)
        {
            double num;
            try
            {
                num = Double.Parse(txtCompetencias.Text);
                if (num >= 0 && num <= 100)
                {
                    txtObjetivos.Text = (100 - num).ToString();
                    txtCompetencias.ForeColor = Color.Black;
                }
                else
                    txtCompetencias.ForeColor = Color.Red;
            }
            catch (Exception ex)
            {
                txtCompetencias.ForeColor = Color.Red;
            }
        }
    }
}
