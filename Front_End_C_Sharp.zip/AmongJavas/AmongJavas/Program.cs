﻿using AmongJavas.AreaWS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AmongJavas
{
    class Program
    {
        public static PeriodoWS.periodo periodo = new PeriodoWS.periodo();
        public static CuentaWS.colaborador colaborador = new CuentaWS.colaborador();
        public static EvaluacionTotalWS.evaluacionTotal evaluacion = new EvaluacionTotalWS.evaluacionTotal();
        public static CronogramaWS.cronograma cronograma = new CronogramaWS.cronograma();
        
        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new frmInicioSesion());
        }
    }
}
