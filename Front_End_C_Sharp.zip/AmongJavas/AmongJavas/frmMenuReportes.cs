﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AmongJavas
{
    public partial class frmMenuReportes : Form
    {
        private frmInicioSesion panelInicioSesion;
        private PlanDesarrolloIndividualWS.PlanDesarrolloIndividualWSClient daoPdi;
        private BindingList<PlanDesarrolloIndividualWS.planDesarrolloIndividual> listaPDI;
        private PlanDesarrolloIndividualWS.planDesarrolloIndividual pdiSeleccionado;
        private ReporteWS.ReporteWSClient daoReporte;
        private PeriodoWS.PeriodoWSClient daoPeriodo;
        private PeriodoWS.periodo periodoSeleccionado;
        private ColaboradorWS.ColaboradorWSClient daoColaborador;
        private int colaboradorSeleccionado;
        private BindingList<PeriodoWS.periodo> listaPeriodos;
        public frmCargando cargando;
        public frmOscuro oscuro;
        public frmMenuReportes(frmInicioSesion panelInicioSesion)
        {
            InitializeComponent();
            txtNombre.Enabled = false;
            txtArea.Enabled = false;
            txtCorreo.Enabled = false;
            daoPdi = new PlanDesarrolloIndividualWS.PlanDesarrolloIndividualWSClient();
            daoReporte = new ReporteWS.ReporteWSClient();
            daoPeriodo = new PeriodoWS.PeriodoWSClient();
            daoColaborador = new ColaboradorWS.ColaboradorWSClient();
            sfdReporte.Filter = "Archivos pdf(*.pdf)|*.pdf|Todo tipo de archivo (*.*)|*.*";
            this.panelInicioSesion = panelInicioSesion;
            panelSolo.Height = 300;
            //Oscuro cargando
            oscuro = new frmOscuro();
            oscuro.SetBounds(0, 0, this.Width, this.Height);

            deshabilitarMenus();
            deshabilitarBotones();
            llenarUsuario();
            llenarEmpleados();
            llenarMiPeriodos();
            llenarGrupoPeriodos();
            deshabilitaEtapa();
        }
        public void deshabilitaEtapa()
        {
            //Etapa
            switch (Program.cronograma.etapa)
            {
                case 0: txtEtapa.Text = "Planificación"; break;
                case 1: txtEtapa.Text = "Evaluación"; break;
                case 2: txtEtapa.Text = "Calibración"; break;
                case 3: txtEtapa.Text = "Reporte"; break;
                default: txtEtapa.Text = ""; break;
            }
            //Periodo
            txtPeriodo.Text = Program.periodo.fechaFin.Year.ToString();
        }
        public void deshabilitarMenus()
        {
            if (Program.colaborador.cuenta.permiso.permisoRRHH == false)
            {
                btnOjetivos.Location = new Point(0, 18);
                btnEvaluacion.Location = new Point(0, 68);
                btnReportes.Location = new Point(0, 118);
                pictureBox5.Location = new Point(10, 18);
                pictureBox4.Location = new Point(10, 68);
                pictureBox6.Location = new Point(10, 118);

                pictureBox3.Visible = false;
                pictureBox7.Visible = false;
                btnPlanificacion.Visible = false;
                btnCalibracion.Visible = false;
            }
            else
            {
                btnPlanificacion.Location = new Point(0, 18);
                btnOjetivos.Location = new Point(0, 68);
                btnEvaluacion.Location = new Point(0, 118);
                btnCalibracion.Location = new Point(0, 168);
                btnReportes.Location = new Point(0, 218);
                pictureBox3.Location = new Point(10, 18);
                pictureBox5.Location = new Point(10, 68);
                pictureBox4.Location = new Point(10, 118);
                pictureBox7.Location = new Point(10, 168);
                pictureBox6.Location = new Point(10, 218);

                pictureBox3.Visible = true;
                pictureBox7.Visible = true;
                btnPlanificacion.Visible = true;
                btnCalibracion.Visible = true;

            }
        }
        public void deshabilitarBotones()
        {
            if (Program.colaborador.cuenta.permiso.permisoJefe == false) //No es jefe
            {
                tabPage1.Controls.Remove(panelMi);
                panelSolo.Controls.Add(panelMi);
                tabControl1.Visible = false;
                panelSolo.Visible = true;
            }
            else
            {
                panelSolo.Controls.Remove(panelMi);
                tabPage1.Controls.Add(panelMi);
                tabControl1.Visible = true;
                panelSolo.Visible = false;
            }

        }
        private void quitaPeridoActual()
        {
            foreach(PeriodoWS.periodo p in listaPeriodos)
            {
                if (p.id_Periodo == Program.periodo.id_Periodo)
                {
                    if (Program.cronograma.etapa < 3) {
                        listaPeriodos.Remove(p);
                        break;
                    }
                }
                    
            }
        }
        public void llenarMiPeriodos()
        {
            try
            {
                listaPeriodos = new BindingList<PeriodoWS.periodo>(daoPeriodo.listar_Periodos_Colaborador(Program.colaborador.idColaborador).ToList());
                quitaPeridoActual();
                dgvMisPeriodos.AutoGenerateColumns = false;
                dgvMisPeriodos.DataSource = new BindingList<PeriodoWS.periodo>(listaPeriodos);
            }
            catch(Exception ex)
            {
                listaPeriodos = new BindingList<PeriodoWS.periodo>();
                dgvMisPeriodos.DataSource = null;
            }
        }
        public void llenarEvPeriodos()
        {
            ColaboradorWS.colaborador cola = (ColaboradorWS.colaborador)cbEmpleados.SelectedItem;
            if (cola != null)
            {
                try
                {
                    listaPeriodos = new BindingList<PeriodoWS.periodo>(daoPeriodo.listar_Periodos_Colaborador(cola.idColaborador).ToList());
                    quitaPeridoActual();
                    dgvEvPeriodos.AutoGenerateColumns = false;
                    dgvEvPeriodos.DataSource = new BindingList<PeriodoWS.periodo>(listaPeriodos);
                }
                catch (Exception ex)
                {
                    listaPeriodos = new BindingList<PeriodoWS.periodo>();
                    dgvEvPeriodos.DataSource = null;
                }
            }
        }
        public void llenarGrupoPeriodos()
        {
            try
            {
                listaPeriodos = new BindingList<PeriodoWS.periodo>(daoPeriodo.listar_Periodos_Evaluador(Program.colaborador.idColaborador).ToList());
                quitaPeridoActual();
                dgvResumen.AutoGenerateColumns = false;
                dgvResumen.DataSource = new BindingList<PeriodoWS.periodo>(listaPeriodos);
            }
            catch (Exception ex)
            {
                listaPeriodos = new BindingList<PeriodoWS.periodo>();
                dgvResumen.DataSource = null;
            }
        }
        public void llenarEmpleados()
        {
            cbEmpleados.ValueMember = "idColaborador";
            cbEmpleados.DisplayMember = "nombreCompleto";
            cbEmpleados.DataSource = daoColaborador.listar_subordinados(Program.colaborador.idColaborador);
        }
        private void btnCerrarSesion_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Close();
            panelInicioSesion.Show();
        }

        private void btnPlanificacion_Click(object sender, EventArgs e)
        {
            this.Close();
            frmMenuPlanificacion panel = new frmMenuPlanificacion(panelInicioSesion);
            panel.Show();
        }

        private void btnOjetivos_Click(object sender, EventArgs e)
        {
            this.Close();
            frmMenuObjetivos panel = new frmMenuObjetivos(panelInicioSesion);
            panel.Show();
        }

        private void btnEvaluacion_Click(object sender, EventArgs e)
        {
            this.Close();
            frmMenuEvaluacion panel = new frmMenuEvaluacion(panelInicioSesion);
            panel.Show();
        }

        private void btnCalibracion_Click(object sender, EventArgs e)
        {
            this.Close();
            frmMenuCalibracion panel = new frmMenuCalibracion(panelInicioSesion);
            panel.Show();
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        public void llenarUsuario()
        {
            txtNombre.Text = Program.colaborador.nombres + " " + Program.colaborador.apellidos;
            txtArea.Text = Program.colaborador.area.nombre;
            txtCorreo.Text = Program.colaborador.correo;
        }

        private void dgvMisPeriodos_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            PeriodoWS.periodo data = dgvMisPeriodos.Rows[e.RowIndex].DataBoundItem as PeriodoWS.periodo;
            dgvMisPeriodos.Rows[e.RowIndex].Cells[0].Value = data.fechaFin.Year;
        }


        private void btnVerMiPDI_Click(object sender, EventArgs e)
        {
            if (dgvMisPeriodos.RowCount>0)
            {
                periodoSeleccionado = (PeriodoWS.periodo)dgvMisPeriodos.CurrentRow.DataBoundItem;
                frmOscuro pp = new frmOscuro();
                pp.SetBounds(0, 0, this.Width, this.Height);
                pp.Show();
                if (Program.colaborador.cuenta.permiso.permisoJefe == false)
                {
                    pdiSeleccionado = daoPdi.buscar_mi_pdi(Program.colaborador.idColaborador, periodoSeleccionado.id_Periodo);
                    frmGestionarPDI panelPDI = new frmGestionarPDI(pdiSeleccionado, Estado.Revisar);
                    if (panelPDI.ShowDialog() == DialogResult.OK)
                    {
                    }
                }
                pp.Close();
            }
        }

        private void btnVerEvPDI_Click(object sender, EventArgs e)
        {
            if (dgvEvPeriodos.RowCount > 0)
            {
                periodoSeleccionado = (PeriodoWS.periodo)dgvEvPeriodos.CurrentRow.DataBoundItem;
                frmOscuro pp = new frmOscuro();
                pp.SetBounds(0, 0, this.Width, this.Height);
                pp.Show();
                ColaboradorWS.colaborador cola = (ColaboradorWS.colaborador)cbEmpleados.SelectedItem;
                pdiSeleccionado = daoPdi.buscar_mi_pdi(cola.idColaborador, periodoSeleccionado.id_Periodo);
                frmGestionarPDI panelPDI;
                if (periodoSeleccionado.id_Periodo==Program.periodo.id_Periodo) //Si es el actual
                    panelPDI = new frmGestionarPDI(pdiSeleccionado, Estado.Actualizar);
                else
                    panelPDI = new frmGestionarPDI(pdiSeleccionado, Estado.Revisar);
                if (panelPDI.ShowDialog() == DialogResult.OK)
                {
                }

                pp.Close();
            }
        }

        private void cbEmpleados_SelectedIndexChanged(object sender, EventArgs e)
        {
            llenarEvPeriodos();
        }

        private void SetLoading(bool displayLoader)
        {
            if (displayLoader)
            {
                this.Invoke((MethodInvoker)delegate
                {
                    oscuro.Show();
                    cargando = new frmCargando();
                    cargando.Show();
                    this.Cursor = System.Windows.Forms.Cursors.WaitCursor;
                });
            }
            else
            {
                this.Invoke((MethodInvoker)delegate
                {
                    oscuro.Hide();
                    cargando.Close();
                    this.Cursor = System.Windows.Forms.Cursors.Default;
                });
            }
        }
        private void hiloPDI()
        {
            //Crea cargando
            SetLoading(true);

            //Hace operaciones
            byte[] arreglo = daoReporte.generarPDI(pdiSeleccionado.idColaborador, periodoSeleccionado.id_Periodo);
            try {
                File.WriteAllBytes(sfdReporte.FileName, arreglo);
                //Oculta cargando
                SetLoading(false);
                MessageBox.Show("Reporte generado", "Mensaje confirmacion", MessageBoxButtons.OK);
            }
            catch(Exception ex)
            {
                SetLoading(false);
                MessageBox.Show("No se puede guardar el archivo. Puede que el archivo pdf este abierto.", "Mensaje de error", MessageBoxButtons.OK);
            }
            
        }
        private void hiloREI()
        {
            //Crea cargando
            SetLoading(true);

            //Hace operaciones
            byte[] arreglo = daoReporte.generarREI(colaboradorSeleccionado, periodoSeleccionado.id_Periodo);
            try
            {
                File.WriteAllBytes(sfdReporte.FileName, arreglo);
                //Oculta cargando
                SetLoading(false);
                MessageBox.Show("Reporte Individual generado", "Mensaje confirmacion", MessageBoxButtons.OK);
            }
            catch (Exception ex)
            {
                SetLoading(false);
                MessageBox.Show("No se puede guardar el archivo. Puede que el archivo pdf este abierto.", "Mensaje de error", MessageBoxButtons.OK);
            }

        }
        private void hiloRER()
        {
            //Crea cargando
            SetLoading(true);

            //Hace operaciones
            byte[] arreglo = daoReporte.generarRER(colaboradorSeleccionado, periodoSeleccionado.fechaFin.Year.ToString(), periodoSeleccionado.id_Periodo);
            try
            {
                File.WriteAllBytes(sfdReporte.FileName, arreglo);
                //Oculta cargando
                SetLoading(false);
                MessageBox.Show("Reporte Resumen generado", "Mensaje confirmacion", MessageBoxButtons.OK);
            }
            catch (Exception ex)
            {
                SetLoading(false);
                MessageBox.Show("No se puede guardar el archivo. Puede que el archivo pdf este abierto.", "Mensaje de error", MessageBoxButtons.OK);
            }

        }
                    
        private void btnGenerarMiPDI_Click(object sender, EventArgs e)
        {
            if (dgvMisPeriodos.RowCount > 0)
            {
                colaboradorSeleccionado = Program.colaborador.idColaborador;
                periodoSeleccionado = (PeriodoWS.periodo)dgvMisPeriodos.CurrentRow.DataBoundItem;
                pdiSeleccionado = daoPdi.buscar_mi_pdi(Program.colaborador.idColaborador, periodoSeleccionado.id_Periodo);
                sfdReporte.Title = "Generar Mi Plan Desarrollo Individual";
                sfdReporte.ShowDialog();
                if (sfdReporte != null && sfdReporte.FileName != "")
                {
                    Thread hilo = new Thread(hiloPDI);
                    hilo.Start();
                }
            }
        }
        private void btnGenerarEvPDI_Click(object sender, EventArgs e)
        {
            if (dgvEvPeriodos.RowCount > 0)
            {
                periodoSeleccionado = (PeriodoWS.periodo)dgvEvPeriodos.CurrentRow.DataBoundItem;
                ColaboradorWS.colaborador cola = (ColaboradorWS.colaborador)cbEmpleados.SelectedItem;
                colaboradorSeleccionado = cola.idColaborador;
                sfdReporte.Title = "Generar Plan Desarrollo Individual de " + cola.nombreCompleto;
                sfdReporte.ShowDialog(); 
                pdiSeleccionado = daoPdi.buscar_mi_pdi(cola.idColaborador, periodoSeleccionado.id_Periodo);
                if (sfdReporte.FileName != null && sfdReporte.FileName != "")
                {
                    Thread hilo = new Thread(hiloPDI);
                    hilo.Start();
                }
            }
        }

        private void btnGenerarMiRI_Click(object sender, EventArgs e)
        {
            if (dgvMisPeriodos.RowCount > 0)
            {
                colaboradorSeleccionado = Program.colaborador.idColaborador;
                sfdReporte.Title = "Generar Mi Reporte Individual";
                sfdReporte.ShowDialog();
                periodoSeleccionado = (PeriodoWS.periodo)dgvMisPeriodos.CurrentRow.DataBoundItem;
                if (sfdReporte.FileName != null && sfdReporte.FileName != "")
                {
                    Thread hilo = new Thread(hiloREI);
                    hilo.Start();
                }
            }
        }
        private void btnGenerarEvRI_Click(object sender, EventArgs e)
        {
            if (dgvEvPeriodos.RowCount > 0)
            {
                ColaboradorWS.colaborador cola = (ColaboradorWS.colaborador)cbEmpleados.SelectedItem;
                colaboradorSeleccionado = cola.idColaborador;
                sfdReporte.Title = "Generar Reporte Individual de "+cola.nombreCompleto;
                
                sfdReporte.ShowDialog();
                periodoSeleccionado = (PeriodoWS.periodo)dgvEvPeriodos.CurrentRow.DataBoundItem;
                if (sfdReporte.FileName != null && sfdReporte.FileName != "")
                {
                    Thread hilo = new Thread(hiloREI);
                    hilo.Start();
                }
            }
        }

        private void dgvEvPeriodos_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            PeriodoWS.periodo data = dgvEvPeriodos.Rows[e.RowIndex].DataBoundItem as PeriodoWS.periodo;
            dgvEvPeriodos.Rows[e.RowIndex].Cells[0].Value = data.fechaFin.Year;
        }

        private void btnGenerarRS_Click(object sender, EventArgs e)
        {
            if (dgvResumen.RowCount > 0)
            {
                colaboradorSeleccionado = Program.colaborador.idColaborador;
                sfdReporte.Title = "Generar Reporte Resumen";
                sfdReporte.ShowDialog();
                periodoSeleccionado = (PeriodoWS.periodo)dgvResumen.CurrentRow.DataBoundItem;
                if (sfdReporte.FileName != null && sfdReporte.FileName != "")
                {
                    Thread hilo = new Thread(hiloRER);
                    hilo.Start();
                }
            }
        }

        private void dgvResumen_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            PeriodoWS.periodo data = dgvResumen.Rows[e.RowIndex].DataBoundItem as PeriodoWS.periodo;
            dgvResumen.Rows[e.RowIndex].Cells[0].Value = data.fechaFin.Year;
        }
    }
}
