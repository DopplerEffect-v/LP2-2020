﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AmongJavas
{
    public partial class frmConfigurarPesosPotenciales : Form
    {
        private frmInicioSesion panelInicioSesion;
        private frmMenuPlanificacion menuPlanificacion;
        private PuestoTrabajoWS.PuestoTrabajoWSClient daoPuestoTrabajo;
        private LineaCriterioWS.LineaCriterioWSClient daoLineaCriterio;
        private LineaCriterioWS.lineaCriterio lineaSeleccionada;
        public frmConfigurarPesosPotenciales(frmInicioSesion panelInicioSesion, frmMenuPlanificacion menuPlanificacion)
        {
            InitializeComponent();

            txtNombre.Enabled = false;
            txtArea.Enabled = false;
            txtCorreo.Enabled = false;

            this.panelInicioSesion = panelInicioSesion;
            this.menuPlanificacion = menuPlanificacion;
            //Llena combobox
            cbPuesto.ValueMember = "id_Puesto_Trabajo";
            cbPuesto.DisplayMember = "nombre";
            daoPuestoTrabajo = new PuestoTrabajoWS.PuestoTrabajoWSClient();
            cbPuesto.DataSource = daoPuestoTrabajo.listarPuestoTrabajo();
        }
        private void llenarTabla()
        {
            PuestoTrabajoWS.puestoTrabajo puesto = (PuestoTrabajoWS.puestoTrabajo)cbPuesto.SelectedItem;
            //Llena datagridview
            daoLineaCriterio = new LineaCriterioWS.LineaCriterioWSClient();
            dgvCompetencias.AutoGenerateColumns = false;
            if (daoLineaCriterio.listarLineaCriterio(puesto.id_Puesto_Trabajo, Program.periodo.id_Periodo, 2) != null)
                dgvCompetencias.DataSource = new BindingList<LineaCriterioWS.lineaCriterio>(daoLineaCriterio.listarLineaCriterio(puesto.id_Puesto_Trabajo, Program.periodo.id_Periodo, 2).ToArray());
        }
        private void btnAtras_Click(object sender, EventArgs e)
        {
            this.Hide();
            this.menuPlanificacion.Show();
        }

        private void btnCerrarSesion_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            this.panelInicioSesion.Show();
        }

        private void btnConfigurarPotenciales_Click(object sender, EventArgs e)
        {
            this.Hide();

            frmConfigurarPotenciales menuConfigurarPoteciales =
                new frmConfigurarPotenciales(this.panelInicioSesion, this.menuPlanificacion);

            menuConfigurarPoteciales.llenarUsuario();
            menuConfigurarPoteciales.Show();
        }

        private void btnAsignar_Click(object sender, EventArgs e)
        {
            if (dgvCompetencias.RowCount > 0)
            {
                lineaSeleccionada = (LineaCriterioWS.lineaCriterio)dgvCompetencias.CurrentRow.DataBoundItem;
                frmOscuro pp = new frmOscuro();
                pp.SetBounds(0, 0, this.Width, this.Height);
                pp.Show();
                frmGestionarPesosPotencial panelGestionarPesosPotencial = new frmGestionarPesosPotencial(lineaSeleccionada, cbPuesto.Text);
                if (panelGestionarPesosPotencial.ShowDialog() == DialogResult.OK)
                {

                }
                pp.Close();
                llenarTabla();
            }
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        public void llenarUsuario()
        {
            txtNombre.Text = Program.colaborador.nombres + " " + Program.colaborador.apellidos;
            txtArea.Text = Program.colaborador.area.nombre;
            txtCorreo.Text = Program.colaborador.correo;
        }

        private void cbPuesto_SelectedIndexChanged(object sender, EventArgs e)
        {
            llenarTabla();
        }
    }
}
