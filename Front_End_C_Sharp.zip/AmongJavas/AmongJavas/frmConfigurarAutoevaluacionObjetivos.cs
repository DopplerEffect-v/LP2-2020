﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AmongJavas
{
    public partial class frmConfigurarAutoevaluacionObjetivos : Form
    {
        private frmInicioSesion panelInicioSesion;
        private frmMenuEvaluacion menuEvaluacion;
        private ObjetivoWS.ObjetivoWSClient daoObjetivo;
        private ObjetivoWS.objetivo objetivoSeleccionado;
        public frmConfigurarAutoevaluacionObjetivos(frmInicioSesion panelInicioSesion, frmMenuEvaluacion menuEvaluacion)
        {
            InitializeComponent();
            this.panelInicioSesion = panelInicioSesion;
            this.menuEvaluacion = menuEvaluacion;
            daoObjetivo = new ObjetivoWS.ObjetivoWSClient();
            llenarTabla();
            deshabilitaEtapa();
        }
        public void deshabilitaEtapa()
        {
            if (Program.cronograma.etapa != 1) //No es etapa Evaluacion
            {
                panelIndi.Visible = false;
            }
        }
        private void llenarTabla()
        {
            dgvCompetencias.AutoGenerateColumns = false;
            if (daoObjetivo.listarPorColaborador_Y_Periodo(Program.colaborador.idColaborador, Program.periodo.id_Periodo, "") != null)
            {
                BindingList<ObjetivoWS.objetivo> listaObjetivos, listaTemp;
                listaTemp = new BindingList<ObjetivoWS.objetivo>(daoObjetivo.listarPorColaborador_Y_Periodo(Program.colaborador.idColaborador, Program.periodo.id_Periodo, "").ToArray());
                listaObjetivos = new BindingList<ObjetivoWS.objetivo>();
                foreach (ObjetivoWS.objetivo obj in listaTemp)
                {
                    if (obj.estado != 0 && obj.estado != 2)
                        listaObjetivos.Add(obj);
                }
                dgvCompetencias.DataSource = listaObjetivos;
            }
            else
                dgvCompetencias.DataSource = null;
        }
        private void btnAtras_Click(object sender, EventArgs e)
        {
            this.menuEvaluacion.Show();
            this.Close();
        }

        private void btnCerrarSesion_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.panelInicioSesion.Show();
            this.Close();
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            if (dgvCompetencias.RowCount > 0)
            {
                objetivoSeleccionado = (ObjetivoWS.objetivo)dgvCompetencias.CurrentRow.DataBoundItem;
                frmOscuro pp = new frmOscuro();
                pp.SetBounds(0, 0, this.Width, this.Height);
                pp.Show();
                frmGestionarObjetivos panelGestionarObjetivos = new frmGestionarObjetivos(Estado.Autoevaluar,objetivoSeleccionado);
                if (panelGestionarObjetivos.ShowDialog() == DialogResult.OK)
                {

                }
                llenarTabla();
                pp.Close();
            }
        }

        private void btnEvaluarCompetencias_Click(object sender, EventArgs e)
        {
            frmConfigurarAutoevaluacionCompetencias panelVecino =
                new frmConfigurarAutoevaluacionCompetencias(this.panelInicioSesion, this.menuEvaluacion);

            panelVecino.llenarUsuario();
            panelVecino.Show();
            this.Close();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Desea registrar la Autoevaluación?", "Mensaje de confirmación", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                MessageBox.Show("Autoevaluación registrada", "Confirmación", MessageBoxButtons.OK);
            }
        }
        public void llenarUsuario()
        {
            txtNombre.Text = Program.colaborador.nombres + " " + Program.colaborador.apellidos;
            txtArea.Text = Program.colaborador.area.nombre;
            txtCorreo.Text = Program.colaborador.correo;
        }


    }
}
