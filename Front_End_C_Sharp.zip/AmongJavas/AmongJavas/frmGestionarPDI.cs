﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AmongJavas
{
    public partial class frmGestionarPDI : Form
    {
        PlanDesarrolloIndividualWS.planDesarrolloIndividual pdi;
        PlanDesarrolloIndividualWS.PlanDesarrolloIndividualWSClient daoPDI;
        public frmGestionarPDI(PlanDesarrolloIndividualWS.planDesarrolloIndividual pdi,Estado estado)
        {
            InitializeComponent();
            this.pdi = pdi;
            txtid.Text = pdi.idColaborador.ToString();
            txtNombre.Text = pdi.nombreCompleto;
            txtComentarioObj.Text = pdi.observacionesObj;
            txtComentarioPoten.Text = pdi.observacionesPot;
            txtCometarioCompe.Text = pdi.observacionesComp;
            daoPDI = new PlanDesarrolloIndividualWS.PlanDesarrolloIndividualWSClient();
            establecerComponentes(Estado.Inicial);
            if (estado == Estado.Revisar)
            {
                btnGuardar.Visible = false;
                btnCancelar.Visible = false;
                btnEditar.Visible = false;
            }
        }

        public void establecerComponentes(Estado estado)
        {
            switch (estado)
            {
                case Estado.Inicial:
                    txtid.Enabled = false;
                    txtNombre.Enabled = false;
                    txtComentarioObj.Enabled = false;
                    txtCometarioCompe.Enabled = false;
                    txtComentarioPoten.Enabled = false;
                    habilitaBoton(btnGuardar,false);
                    habilitaBoton(btnCancelar, false);
                    habilitaBoton(btnEditar, true);
                    break;

                case Estado.Actualizar:
                    txtid.Enabled = false;
                    txtNombre.Enabled = false;
                    txtComentarioObj.Enabled = true;
                    txtCometarioCompe.Enabled = true;
                    txtComentarioPoten.Enabled = true;
                    habilitaBoton(btnGuardar, true);
                    habilitaBoton(btnCancelar, true);
                    habilitaBoton(btnEditar, false);
                    break;

            }
        }
        private void habilitaBoton(Button boton, bool estado)
        {
            boton.Enabled = estado;
            if (estado == true)
                boton.BackColor = Color.FromArgb(46, 44, 51);
            if (estado == false)
                boton.BackColor = Color.FromArgb(246, 245, 247);

        }
        private void btnEditar_Click(object sender, EventArgs e)
        {
            establecerComponentes(Estado.Actualizar);
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Desea registrar el Plan?", "Mensaje de confirmación", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                MessageBox.Show("Plan registrado", "Confirmación", MessageBoxButtons.OK);
                pdi.observacionesComp = txtCometarioCompe.Text;
                pdi.observacionesObj = txtComentarioObj.Text;
                pdi.observacionesPot = txtComentarioPoten.Text;
                //pdi.observacionesComp = txtCometarioCompe.Text;
                daoPDI.actualizarPlan(pdi);
                this.DialogResult = DialogResult.OK;
                //establecerComponentes(Estado.Inicial);
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            establecerComponentes(Estado.Inicial);
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnAtras_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }

    
}
