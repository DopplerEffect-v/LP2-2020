﻿using AmongJavas.CriterioWS;
using AmongJavas.CuentaWS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AmongJavas
{
    public partial class frmInicioSesion : Form
    {

        private CuentaWS.CuentaWSClient _daoCuenta;
        private EvaluacionTotalWS.EvaluacionTotalWSClient _daoEvaluacion;
        private CronogramaWS.CronogramaWSClient _daoCronograma;
        private PeriodoWS.PeriodoWSClient _daoPeriodo;
        
        public frmInicioSesion()
        {
            InitializeComponent();
            _daoCuenta = new CuentaWS.CuentaWSClient();
            _daoEvaluacion = new EvaluacionTotalWS.EvaluacionTotalWSClient();
            _daoCronograma = new CronogramaWS.CronogramaWSClient();
            _daoPeriodo = new PeriodoWS.PeriodoWSClient();

            //txtUsuario.Text = "admin";
            //txtContrasena.Text = "1234";
        }

        private void btnIngresar_Click(object sender, EventArgs e)
        {
            if (txtUsuario.Text == "")
                MessageBox.Show("Fala ingresar el Usuario", "Error", MessageBoxButtons.OK);
            else if (txtContrasena.Text == "")
                MessageBox.Show("Fala ingresar la Contraseña", "Error", MessageBoxButtons.OK);
            else { 
                Program.colaborador = _daoCuenta.buscarCuenta(txtUsuario.Text, txtContrasena.Text);
                if (Program.colaborador != null)
                {
                    //Periodo************************************************************
                    Program.periodo = _daoPeriodo.buscarPeriodoActual();
                    Program.evaluacion = _daoEvaluacion.buscarEvaluacion(Program.colaborador.idColaborador, Program.periodo.id_Periodo);
                    Program.cronograma = _daoCronograma.buscarCronograma(Program.periodo.id_Periodo);
                    this.Hide();

                    if (cbRecordarme.Checked == false)
                    {
                        txtUsuario.Text = "";
                        txtContrasena.Text = "";
                    }

                    if (Program.colaborador.cuenta.permiso.permisoRRHH == true)
                    {
                        frmMenuPlanificacion panel = new frmMenuPlanificacion(this);
                        panel.Show();
                    }
                    else
                    {
                        frmMenuObjetivos panel = new frmMenuObjetivos(this);
                        panel.Show();
                    }

                }
                else
                {
                    MessageBox.Show("Datos incorrectos", "Error", MessageBoxButtons.OK);
                }
            }
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();            
        }

        private void btnOlvidarContrasena_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }
    }        
}
