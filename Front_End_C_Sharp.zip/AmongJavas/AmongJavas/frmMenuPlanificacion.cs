﻿using AmongJavas.CuentaWS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AmongJavas
{
    public partial class frmMenuPlanificacion : Form
    {

        private frmInicioSesion panelInicioSesion;
        private NotificacionesWS.NotificacionesWSClient daoNotificaciones;
        private bool panelEsVisible;
        public frmCargando cargando;
        public frmOscuro oscuro;
        public frmMenuPlanificacion(frmInicioSesion panelInicioSesion)
        {
            InitializeComponent();

            txtNombre.Enabled = false;
            txtArea.Enabled = false;
            txtCorreo.Enabled = false;
            daoNotificaciones = new NotificacionesWS.NotificacionesWSClient();
            this.panelInicioSesion = panelInicioSesion;
            ocultaTest(false);
            llenarUsuario();
            deshabilitarMenus();
            deshabilitaEtapa();
            //Oscuro cargando
            oscuro = new frmOscuro();
            oscuro.SetBounds(0, 0, this.Width, this.Height);
        }

        public void deshabilitaEtapa()
        {
            //Etapa
            switch (Program.cronograma.etapa)
            {
                case 0: txtEtapa.Text = "Planificación"; break;
                case 1: txtEtapa.Text = "Evaluación"; break;
                case 2: txtEtapa.Text = "Calibración"; break;
                case 3: txtEtapa.Text = "Reporte"; break;
                default: txtEtapa.Text = ""; break;
            }
            //Periodo
            txtPeriodo.Text = Program.periodo.fechaFin.Year.ToString();
        }
        public void deshabilitarMenus()
        {
            if (Program.colaborador.cuenta.permiso.permisoRRHH == false)
            {
                btnOjetivos.Location = new Point(0, 18);
                btnEvaluacion.Location = new Point(0, 68);
                btnReportes.Location = new Point(0, 118);
                pictureBox5.Location = new Point(10, 18);
                pictureBox4.Location = new Point(10, 68);
                pictureBox6.Location = new Point(10, 118);

                pictureBox3.Visible = false;
                pictureBox7.Visible = false;
                btnPlanificacion.Visible = false;
                btnCalibracion.Visible = false;
            }
            else
            {
                btnPlanificacion.Location = new Point(0, 18);
                btnOjetivos.Location = new Point(0, 68);
                btnEvaluacion.Location = new Point(0, 118);
                btnCalibracion.Location = new Point(0, 168);
                btnReportes.Location = new Point(0, 218);
                pictureBox3.Location = new Point(10, 18);
                pictureBox5.Location = new Point(10, 68);
                pictureBox4.Location = new Point(10, 118);
                pictureBox7.Location = new Point(10, 168);
                pictureBox6.Location = new Point(10, 218);

                pictureBox3.Visible = true;
                pictureBox7.Visible = true;
                btnPlanificacion.Visible = true;
                btnCalibracion.Visible = true;

            }
        }
        private void btnCerrarSesion_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Close();
            panelInicioSesion.Show();
        }

        private void btnOjetivos_Click(object sender, EventArgs e)
        {
            this.Close();
            frmMenuObjetivos panel = new frmMenuObjetivos(panelInicioSesion);
            panel.Show();
        }

        private void btnEvaluacion_Click(object sender, EventArgs e)
        {
            this.Close();
            frmMenuEvaluacion panel = new frmMenuEvaluacion(panelInicioSesion);
            panel.Show();
        }

        private void btnCalibracion_Click(object sender, EventArgs e)
        {
            this.Close();
            frmMenuCalibracion panel = new frmMenuCalibracion(panelInicioSesion);
            panel.Show();
        }

        private void btnReportes_Click(object sender, EventArgs e)
        {
            this.Close();
            frmMenuReportes panel = new frmMenuReportes(panelInicioSesion);
            panel.Show();

        }
        private Boolean tienePermisos()
        {
            if (Program.colaborador.cuenta.permiso.permisoRRHH == false)
            {
                MessageBox.Show("Usted no tiene permiso para entrar a esta opción", "Acceso Denegado", MessageBoxButtons.OK);
                return false;
            }
            return true;
        }

        private void btnConfigCompetencia_Click(object sender, EventArgs e)
        {
            if (tienePermisos()==true)
            {
                this.Hide();
                frmConfigurarCompetencias panelConfigurarCompetencias = 
                    new frmConfigurarCompetencias(this.panelInicioSesion,this);

                panelConfigurarCompetencias.llenarUsuario();
                panelConfigurarCompetencias.Show();
            }
        }

        private void btnConfigPesoCompetencia_Click(object sender, EventArgs e)
        {
            if (tienePermisos() == true)
            {
                this.Hide();
                frmConfigurarPesosCompetencias panelConfigurarPesosCompetencias =
                    new frmConfigurarPesosCompetencias(this.panelInicioSesion, this);

                panelConfigurarPesosCompetencias.llenarUsuario();
                panelConfigurarPesosCompetencias.Show();
            }
        }

        private void btnConfigPotencial_Click(object sender, EventArgs e)
        {
            if (tienePermisos() == true)
            {
                this.Hide();
                frmConfigurarPotenciales panelConfigurarPotenciales =
                    new frmConfigurarPotenciales(this.panelInicioSesion, this);

                panelConfigurarPotenciales.llenarUsuario();
                panelConfigurarPotenciales.Show();
            }
        }

        private void btnConfigPesoPotencial_Click(object sender, EventArgs e)
        {
            if (tienePermisos() == true)
            {
                this.Hide();
                frmConfigurarPesosPotenciales panelConfigurarPesosPotenciales =
                    new frmConfigurarPesosPotenciales(this.panelInicioSesion, this);

                panelConfigurarPesosPotenciales.llenarUsuario();
                panelConfigurarPesosPotenciales.Show();
            }
        }

        private void btnCronogramaObjetivos_Click(object sender, EventArgs e)
        {
            if (tienePermisos() == true)
            {
                this.Hide();
                frmConfigurarCronograma panelConfigurarCronograma =
                    new frmConfigurarCronograma(this.panelInicioSesion, this);

                panelConfigurarCronograma.llenarUsuario();
                panelConfigurarCronograma.Show();
            }
        }

        private void btnConfCuadrantes_Click(object sender, EventArgs e)
        {
            if (tienePermisos() == true)
            {
                this.Hide();
                frmConfigurarCuadrantes panelConfigurarCronograma =
                    new frmConfigurarCuadrantes(Estado.Inicial, this, this.panelInicioSesion);

                panelConfigurarCronograma.llenarUsuario();
                panelConfigurarCronograma.Show();
            }
        }

        private void btnConfigurarCupos_Click(object sender, EventArgs e)
        {
            if (tienePermisos() == true)
            {
                this.Hide();
                frmConfigurarCuposMapaTalento pannelConfCupos =
                    new frmConfigurarCuposMapaTalento(Estado.Inicial, this, this.panelInicioSesion);

                pannelConfCupos.llenarUsuario();
                pannelConfCupos.Show();
            }
        }

        private void btnConfPesos_Click(object sender, EventArgs e)
        {
            if (tienePermisos() == true)
            {
                this.Hide();
                frmConfigurarPesosEvaluacion panelConfigurarPesosEvaluacion =
                    new frmConfigurarPesosEvaluacion(this.panelInicioSesion, this);

                panelConfigurarPesosEvaluacion.llenarUsuario();
                panelConfigurarPesosEvaluacion.Show();
            }
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        public void llenarUsuario()
        {
            txtNombre.Text = Program.colaborador.nombres + " " + Program.colaborador.apellidos;
            txtArea.Text = Program.colaborador.area.nombre;
            txtCorreo.Text = Program.colaborador.correo;
        }
        private void finPlanificacion()
        {
            if (MessageBox.Show("¿Desea finalizar la etapa de planificación?\nEsta acción no será retroactiva\nEsta es una función de tester", "Mensaje de confirmación", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                oscuro.Show();
                CronogramaWS.CronogramaWSClient daoCronograma = new CronogramaWS.CronogramaWSClient();
                daoCronograma.actualizarEtapa(Program.periodo.id_Periodo, 1);
                NotaCriterioWS.NotaCriterioWSClient daoNota = new NotaCriterioWS.NotaCriterioWSClient();
                daoNota.crearNotasCriterio(Program.periodo.id_Periodo, 1);
                daoNota.crearNotasCriterio(Program.periodo.id_Periodo, 2);
                //daoObjetivo.desactivoNoAprobados(Program.periodo.id_Periodo);
                Program.cronograma.etapa = 1;
                deshabilitaEtapa();
                MessageBox.Show("Etapa de Planificación finalizada", "Mensaje confirmacion", MessageBoxButtons.OK);
                oscuro.Hide();
            }
        }
        private void finEvaluacion()
        {
            if (MessageBox.Show("¿Desea finalizar la etapa de evaluación?\nEsta acción no será retroactiva\nEsta es una función de tester", "Mensaje de confirmación", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                oscuro.Show();
                //Hace operaciones
                EvaluacionTotalWS.EvaluacionTotalWSClient daoEvaluacion = new EvaluacionTotalWS.EvaluacionTotalWSClient();
                NotaCriterioWS.NotaCriterioWSClient daoNotaCriterio = new NotaCriterioWS.NotaCriterioWSClient();
                CuadranteWS.CuadranteWSClient daoCuadrante = new CuadranteWS.CuadranteWSClient();
                ObjetivoWS.ObjetivoWSClient daoObjetivo = new ObjetivoWS.ObjetivoWSClient();
                PesosEvaluacionWS.PesosEvaluacionWSClient daoPesos = new PesosEvaluacionWS.PesosEvaluacionWSClient();
                BindingList<EvaluacionTotalWS.evaluacionTotal> listaEvaluaciones;
                BindingList<NotaCriterioWS.notaCriterio> listaNotas;
                BindingList<ObjetivoWS.objetivo> listaObjetivos;
                PesosEvaluacionWS.pesosEvaluacion pesos;
                CuadranteWS.cuadrante cuadrante;
                double notaCompAuto, notaCompJefe, notaObjeAuto, notaObjeJefe,
                    notaPote, notaDeseJefe, total;

                try
                {
                    listaEvaluaciones = new BindingList<EvaluacionTotalWS.evaluacionTotal>(daoEvaluacion.listar_Evaluaciones());
                    foreach (EvaluacionTotalWS.evaluacionTotal eva in listaEvaluaciones)
                    {
                        notaCompAuto = 0; notaCompJefe = 0;
                        notaObjeAuto = 0; notaObjeJefe = 0;
                        notaDeseJefe = 0;
                        notaPote = 0;
                        try
                        {
                            //Competencias
                            try { 
                                total = 0;
                                listaNotas = new BindingList<NotaCriterioWS.notaCriterio>(daoNotaCriterio.listarNotaPorColaborador(eva.colaborador.idColaborador, 1));
                                foreach (NotaCriterioWS.notaCriterio nota in listaNotas)
                                {
                                    notaCompAuto += nota.notaEvaluado * nota.linea_criterio.peso;
                                    notaCompJefe += nota.notaEvaluador * nota.linea_criterio.peso;
                                    total += nota.linea_criterio.peso;
                                }
                                notaCompAuto /= total;
                                notaCompJefe /= total;
                            }catch(Exception ex)
                            {
                                notaCompAuto = 0;
                                notaCompJefe = 0;
                            }


                            //Potenciales
                            try
                            {
                                total = 0;
                                listaNotas = new BindingList<NotaCriterioWS.notaCriterio>(daoNotaCriterio.listarNotaPorColaborador(eva.colaborador.idColaborador, 2));
                                foreach (NotaCriterioWS.notaCriterio nota in listaNotas)
                                {
                                    notaPote += nota.notaEvaluador * nota.linea_criterio.peso;
                                    total += nota.linea_criterio.peso;
                                }
                                notaPote /= total;
                            }catch(Exception ex)
                            {
                                notaPote = 0;
                            }

                            //Objetivos
                            total = 0;
                            try
                            {
                                listaObjetivos = new BindingList<ObjetivoWS.objetivo>(daoObjetivo.listarPorColaborador_Y_Periodo(eva.colaborador.idColaborador, Program.periodo.id_Periodo, ""));
                                foreach (ObjetivoWS.objetivo obj in listaObjetivos)
                                {
                                    if (obj.porcentajeEvaluado > 1)
                                        notaObjeAuto += 1;
                                    else
                                        notaObjeAuto += obj.porcentajeEvaluado;

                                    if (obj.porcentajeEvaluador > 1)
                                        notaObjeJefe += 1;
                                    else
                                        notaObjeJefe += obj.porcentajeEvaluador;
                                    total++;
                                }
                                notaObjeAuto /= total;
                                notaObjeJefe /= total;
                            }
                            catch (Exception ex)
                            {
                                notaObjeAuto = 0;
                                notaObjeJefe = 0;
                                eva.observaciones = "No tiene objetivos a evaluar.";
                            }


                            //Guarda notas en evaluacion
                            eva.notaCompEvaluado = notaCompAuto;
                            eva.notaCompEvaluador = notaCompJefe;
                            eva.notaObjEvaluado = notaObjeAuto;
                            eva.notaObjEvaluador = notaObjeJefe;
                            eva.notaPotencial = notaPote;

                            //Periodo
                            eva.periodo = new EvaluacionTotalWS.periodo();
                            eva.periodo.id_Periodo = Program.periodo.id_Periodo;

                            //Obtiene pesos evaluacion
                            pesos = daoPesos.buscarPesos(eva.colaborador.puesto.id_Puesto_Trabajo);
                            eva.pesos = new EvaluacionTotalWS.pesosEvaluacion();
                            eva.pesos.id_Pesos = pesos.id_Pesos;
                            notaDeseJefe = notaCompJefe/5* pesos.pesoCompetencias + notaObjeJefe * pesos.pesoObjetivos;
                            notaDeseJefe /= 100;

                            cuadrante = daoCuadrante.buscarCuadrante(notaDeseJefe * 100, notaPote * 100, eva.colaborador.area.id_Area);
                            eva.calibracionAutomatica = new EvaluacionTotalWS.cuadrante();
                            eva.calibracionAutomatica.id_cuadrante = cuadrante.id_cuadrante;

                            //Actualiza Evaluacion
                            daoEvaluacion.actualizarEvaluacion(eva);
                        }
                        catch (Exception ex)
                        {

                        }
                    }
                }
                catch (Exception ex)
                {
                    listaEvaluaciones = new BindingList<EvaluacionTotalWS.evaluacionTotal>();
                }
                MessageBox.Show("Etapa de Evaluación finalizada", "Mensaje confirmacion", MessageBoxButtons.OK);
                //Actualiza etapa
                CronogramaWS.CronogramaWSClient daoCronograma = new CronogramaWS.CronogramaWSClient();
                daoCronograma.actualizarEtapa(Program.periodo.id_Periodo, 2);
                Program.cronograma.etapa = 2;
                deshabilitaEtapa();
                oscuro.Hide();
            }
        }
        private void finCalibracion()
        {
            if (MessageBox.Show("¿Desea finalizar la etapa de calibración?\nEsta acción no será retroactiva\nEsta es una función de tester", "Mensaje de confirmación", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                oscuro.Show();
                //Hace operaciones
                CronogramaWS.CronogramaWSClient daoCronograma = new CronogramaWS.CronogramaWSClient();
                daoCronograma.actualizarEtapa(Program.periodo.id_Periodo, 3);
                EvaluacionTotalWS.EvaluacionTotalWSClient daoEvaluacion = new EvaluacionTotalWS.EvaluacionTotalWSClient();
                PlanDesarrolloIndividualWS.PlanDesarrolloIndividualWSClient daoPdi = new PlanDesarrolloIndividualWS.PlanDesarrolloIndividualWSClient();
                daoEvaluacion.corregirCal(Program.periodo.id_Periodo);
                daoPdi.generarPlanes();
                Program.cronograma.etapa = 3;
                deshabilitaEtapa();
                MessageBox.Show("Etapa de Calibración finalizada", "Mensaje confirmacion", MessageBoxButtons.OK);
                oscuro.Hide();
            }
        }
        private void finReporte()
        {
            if (MessageBox.Show("¿Desea finalizar la etapa de reporte?\nEsta acción no será retroactiva\nEsta es una función de tester", "Mensaje de confirmación", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                oscuro.Show();
                HiloWS.HiloWSClient daoHilo = new HiloWS.HiloWSClient();
                daoHilo.nuevoPeriodo();

                //Actualizo datos del prediodo actual global
                CronogramaWS.CronogramaWSClient daoCronograma = new CronogramaWS.CronogramaWSClient();
                PeriodoWS.PeriodoWSClient daoPeriodo = new PeriodoWS.PeriodoWSClient();
                EvaluacionTotalWS.EvaluacionTotalWSClient daoEvaluacion = new EvaluacionTotalWS.EvaluacionTotalWSClient();
                Program.periodo = daoPeriodo.buscarPeriodoActual();
                Program.evaluacion = daoEvaluacion.buscarEvaluacion(Program.colaborador.idColaborador, Program.periodo.id_Periodo);
                Program.cronograma = daoCronograma.buscarCronograma(Program.periodo.id_Periodo);
                //Actualiza etapa
                daoCronograma.actualizarEtapa(Program.periodo.id_Periodo, 0);
                deshabilitaEtapa();

                MessageBox.Show("Etapa de Reporte finalizada\nNuevo Periodo Generado", "Mensaje confirmacion", MessageBoxButtons.OK);
                oscuro.Hide();
            }
        }
        private void btnFinalizar_Click(object sender, EventArgs e)
        {
            switch (Program.cronograma.etapa)
            {
                case 0: finPlanificacion(); break;
                case 1: finEvaluacion(); break;
                case 2: finCalibracion(); break;
                case 3: finReporte(); break;
            }
        }

        private void btnEtP_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Desea cambiar a la etapa de Planificación?\nEsta es una función de tester", "Mensaje de confirmación", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                CronogramaWS.CronogramaWSClient daoCronograma = new CronogramaWS.CronogramaWSClient();
                daoCronograma.actualizarEtapa(Program.periodo.id_Periodo, 0);
                Program.cronograma.etapa = 0;
                deshabilitaEtapa();
                MessageBox.Show("Planificación iniciada", "Mensaje confirmacion", MessageBoxButtons.OK);   
            }
        }

        private void btnEtE_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Desea cambiar a la etapa de Evaluación?\nEsta es una función de tester", "Mensaje de confirmación", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                CronogramaWS.CronogramaWSClient daoCronograma = new CronogramaWS.CronogramaWSClient();
                daoCronograma.actualizarEtapa(Program.periodo.id_Periodo, 1);
                Program.cronograma.etapa = 1;
                deshabilitaEtapa();
                MessageBox.Show("Evaluación iniciada", "Mensaje confirmacion", MessageBoxButtons.OK);
            }
        }

        private void btnEtC_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Desea cambiar a la etapa de Calibración?\nEsta es una función de tester", "Mensaje de confirmación", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                CronogramaWS.CronogramaWSClient daoCronograma = new CronogramaWS.CronogramaWSClient();
                daoCronograma.actualizarEtapa(Program.periodo.id_Periodo, 2);
                Program.cronograma.etapa = 2;
                deshabilitaEtapa();
                MessageBox.Show("Calibración iniciada", "Mensaje confirmacion", MessageBoxButtons.OK);
            }
        }

        private void btnEtR_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Desea cambiar a la etapa de Reporte?\nEsta es una función de tester", "Mensaje de confirmación", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                CronogramaWS.CronogramaWSClient daoCronograma = new CronogramaWS.CronogramaWSClient();
                daoCronograma.actualizarEtapa(Program.periodo.id_Periodo, 3);
                Program.cronograma.etapa = 3;
                deshabilitaEtapa();
                MessageBox.Show("Reporte iniciada", "Mensaje confirmacion", MessageBoxButtons.OK);
            }
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void btnNotPla_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Desea realizar la notificación de la etapa de Planificación?\nEsta es una función de tester", "Mensaje de confirmación", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Thread hilo = new Thread(hiloNotPlan);
                hilo.Start();
            }
        }

        private void btnNotEva_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Desea realizar la notificación de la etapa de Evaluación?\nEsta es una función de tester", "Mensaje de confirmación", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Thread hilo = new Thread(hiloNotEval);
                hilo.Start();
            }
        }

        private void btnNotCal_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Desea realizar la notificación de la etapa de Calibración?\nEsta es una función de tester", "Mensaje de confirmación", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Thread hilo = new Thread(hiloNotCali);
                hilo.Start();
            }
        }

        private void btnNotRep_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("¿Desea realizar la notificación de la etapa de Reportes?\nEsta es una función de tester", "Mensaje de confirmación", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Thread hilo = new Thread(hiloNotRepo);
                hilo.Start();
            }
        }

        private void ocultaTest(bool modo)
        {
            if (modo == true)
                panelTest.Width = 545;
            else
                panelTest.Width = 55;
            panelEsVisible = !modo;
        }
        private void btnTest_Click(object sender, EventArgs e)
        {
            ocultaTest(panelEsVisible);
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            
        }
        private void SetLoading(bool displayLoader)
        {
            if (displayLoader)
            {
                this.Invoke((MethodInvoker)delegate
                {
                    oscuro.Show();
                    cargando = new frmCargando();
                    cargando.Show();
                    this.Cursor = System.Windows.Forms.Cursors.WaitCursor;
                });
            }
            else
            {
                this.Invoke((MethodInvoker)delegate
                {
                    oscuro.Hide();
                    cargando.Close();
                    this.Cursor = System.Windows.Forms.Cursors.Default;
                });
            }
        }
        private void hiloNotPlan()
        {
            //Crea cargando
            SetLoading(true);

            //Hace operaciones
            double numDias = (Program.cronograma.FECHA_FIN_P - Program.cronograma.FECHA_NOTIFICACION_P).TotalDays;
            daoNotificaciones.notificarPlanificacion((int)numDias);
            MessageBox.Show("Notificaciones de Etapa de Planificación enviadas", "Mensaje confirmacion", MessageBoxButtons.OK);

            //Oculta cargando
            SetLoading(false);
        }

        private void hiloNotEval()
        {
            //Crea cargando
            SetLoading(true);

            //Hace operaciones
            double numDias = (Program.cronograma.FECHA_FIN_E - Program.cronograma.FECHA_NOTIFICACION_E).TotalDays;
            daoNotificaciones.notificarEvaluacion((int)numDias);
            MessageBox.Show("Notificaciones de Etapa de Evaluación enviadas", "Mensaje confirmacion", MessageBoxButtons.OK);

            //Oculta cargando
            SetLoading(false);
        }

        private void hiloNotCali()
        {
            //Crea cargando
            SetLoading(true);

            //Hace operaciones
            double numDias = (Program.cronograma.FECHA_FIN_C - Program.cronograma.FECHA_NOTIFICACION_C).TotalDays;
            daoNotificaciones.notificarCalibracion((int)numDias);
            MessageBox.Show("Notificaciones de Etapa de Calibración enviadas", "Mensaje confirmacion", MessageBoxButtons.OK);

            //Oculta cargando
            SetLoading(false);
        }

        private void hiloNotRepo()
        {
            //Crea cargando
            SetLoading(true);

            //Hace operaciones
            double numDias = (Program.cronograma.FECHA_FIN_R - Program.cronograma.FECHA_NOTIFICACION_R).TotalDays;
            daoNotificaciones.notificarReportes((int)numDias);
            MessageBox.Show("Notificaciones de Etapa de Reportes enviadas", "Mensaje confirmacion", MessageBoxButtons.OK);

            //Oculta cargando
            SetLoading(false);
        }
        
    }
}
