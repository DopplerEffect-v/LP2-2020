﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AmongJavas
{
    public partial class frmConfigurarCompetencias : Form
    {
        private frmInicioSesion panelInicioSesion;
        private frmMenuPlanificacion menuPlanificacion;
        private CriterioWS.CriterioWSClient daoCriterio;
        private CriterioWS.criterio criterioSeleccionado;
        public frmConfigurarCompetencias(frmInicioSesion panelInicioSesion, frmMenuPlanificacion menuPlanificacion)
        {
            InitializeComponent();

            txtNombre.Enabled = false;
            txtArea.Enabled = false;
            txtCorreo.Enabled = false;

            this.panelInicioSesion = panelInicioSesion;
            this.menuPlanificacion = menuPlanificacion;

            daoCriterio = new CriterioWS.CriterioWSClient();
            llenarTabla();
            deshabilitaEtapa();
            criterioSeleccionado = null;

        }
        public void deshabilitaEtapa()
        {
            if (Program.cronograma.etapa != 0)
            {
                btnBorrar.Visible = false;
                btnAnadir.Visible = false;
            }
        }
        private void llenarTabla()
        {
            dgvCompetencias.AutoGenerateColumns = false;
            if (daoCriterio.listar_por_nombre_Criterio("", 1, Program.periodo.id_Periodo) != null)
                dgvCompetencias.DataSource = new BindingList<CriterioWS.criterio>
                    (daoCriterio.listar_por_nombre_Criterio("", 1, Program.periodo.id_Periodo).ToArray());
            else
                dgvCompetencias.DataSource = null;

        }
        private void btnCerrarSesion_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            this.panelInicioSesion.Show();
        }

        private void btnAtras_Click(object sender, EventArgs e)
        {
            this.Hide();
            this.menuPlanificacion.Show();
        }

        private void btnCofigurarPesos_Click(object sender, EventArgs e)
        {
            this.Hide();

            frmConfigurarPesosCompetencias panelConfigurarPesosCompetencias =
                new frmConfigurarPesosCompetencias(this.panelInicioSesion, this.menuPlanificacion);

            panelConfigurarPesosCompetencias.llenarUsuario();
            panelConfigurarPesosCompetencias.Show();

        }

        private void btnVer_Click(object sender, EventArgs e)
        {

            if (dgvCompetencias.RowCount > 0)
            {
                criterioSeleccionado = (CriterioWS.criterio)dgvCompetencias.CurrentRow.DataBoundItem;
                frmOscuro pp = new frmOscuro();
                pp.SetBounds(0, 0, this.Width, this.Height);
                pp.Show();

                frmGestionarCompetencias panelGestionarCompetencias = new frmGestionarCompetencias(panelInicioSesion, Estado.Inicial, criterioSeleccionado);
                if (panelGestionarCompetencias.ShowDialog() == DialogResult.OK)
                {

                }
                pp.Close();
            }
        }

        private void btnAnadir_Click(object sender, EventArgs e)
        {
            frmOscuro pp = new frmOscuro();
            pp.SetBounds(0, 0, this.Width, this.Height);
            pp.Show();
            frmGestionarCompetencias panelGestionarCompetencias = new frmGestionarCompetencias(panelInicioSesion,Estado.Nuevo);
            if (panelGestionarCompetencias.ShowDialog() == DialogResult.OK)
            {
                //llenarTabla();
            }
            llenarTabla();
            pp.Close();
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            if (dgvCompetencias.RowCount > 0)
            {
                criterioSeleccionado = (CriterioWS.criterio)dgvCompetencias.CurrentRow.DataBoundItem;
                if (MessageBox.Show("¿Desea eliminar la Competencia?", "Mensaje de confirmación", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    daoCriterio.eliminarCriterio(criterioSeleccionado);
                    llenarTabla();
                    MessageBox.Show("Competencia eliminada", "Confirmación", MessageBoxButtons.OK); 
                }
            }
        }

        public void llenarUsuario()
        {
            txtNombre.Text = Program.colaborador.nombres + " " + Program.colaborador.apellidos;
            txtArea.Text = Program.colaborador.area.nombre;
            txtCorreo.Text = Program.colaborador.correo;
        }

    }
}
