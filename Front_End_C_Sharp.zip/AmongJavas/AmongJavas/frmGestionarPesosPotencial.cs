﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AmongJavas
{
    public partial class frmGestionarPesosPotencial : Form
    {
        private LineaCriterioWS.LineaCriterioWSClient daoLineaCriterio;
        private LineaCriterioWS.lineaCriterio linea;
        public frmGestionarPesosPotencial(LineaCriterioWS.lineaCriterio linea,String puestoT)
        {
            InitializeComponent();
            establecerComponentes(Estado.Inicial);
            this.linea = linea;
            txtId.Text = linea.criterio.id_criterio.ToString();
            txtNombre.Text = linea.criterio.nombre;
            txtDescripcion.Text = linea.criterio.descripcion;
            txtPeso.Text = linea.peso.ToString();
            txtPuesto.Text = puestoT;
            daoLineaCriterio = new LineaCriterioWS.LineaCriterioWSClient();
            //Llena tabla
            dgvCompetencias.AutoGenerateColumns = false;
            if (linea.lineas_subcriterio != null)
                dgvCompetencias.DataSource = linea.lineas_subcriterio.ToArray();
            else
                dgvCompetencias.DataSource = null;
            deshabilitaEtapa();
        }

        public void deshabilitaEtapa()
        {
            if (Program.cronograma.etapa != 0) //Si no es planificacion
            {
                btnEditar.Visible = false;
                btnGuardar.Visible = false;
                btnCancelar.Visible = false;
            }
        }
        public void establecerComponentes(Estado estado)
        {
            switch (estado)
            {
                case Estado.Inicial:
                    txtPeso.Enabled = false;
                    habilitaBoton(btnEditar, true);
                    habilitaBoton(btnGuardar, false);
                    habilitaBoton(btnCancelar, false);
                    dgvCompetencias.Columns["Peso"].ReadOnly = true;
                    dgvCompetencias.Columns["Peso"].DefaultCellStyle.BackColor = Color.FromArgb(224, 224, 224);
                    dgvCompetencias.Columns["Peso"].DefaultCellStyle.ForeColor = Color.DimGray;
                    break;

                case Estado.Nuevo:
                    txtPeso.Enabled = true;
                    habilitaBoton(btnEditar, false);
                    habilitaBoton(btnGuardar, true);
                    habilitaBoton(btnCancelar, true);
                    dgvCompetencias.Columns["Peso"].ReadOnly = false;
                    dgvCompetencias.Columns["Peso"].DefaultCellStyle.BackColor = Color.White;
                    dgvCompetencias.Columns["Peso"].DefaultCellStyle.ForeColor = Color.Black;
                    break;
            }
        }
        private void habilitaBoton(Button boton, bool estado)
        {
            boton.Enabled = estado;
            if (estado == true)
                boton.BackColor = Color.FromArgb(46, 44, 51);
            if (estado == false)
                boton.BackColor = Color.FromArgb(246, 245, 247);

        }
        private void btnCerrar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            establecerComponentes(Estado.Nuevo);
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            double num;
            try {
                num = Double.Parse(txtPeso.Text);
                if (num<0)
                    MessageBox.Show("El peso debe ser positivo", "Error", MessageBoxButtons.OK);
                else
                if (MessageBox.Show("¿Desea registrar el Peso?", "Mensaje de confirmación", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    linea.peso = Double.Parse(txtPeso.Text);
                    //Las sublineas ya estan anexadas al BidingList
                    daoLineaCriterio.actualizarLineaCriterio(linea);
                    MessageBox.Show("Peso registrado", "Confirmación", MessageBoxButtons.OK);
                    this.DialogResult = DialogResult.OK;
                }
            }catch(Exception ex)
            {
                MessageBox.Show("Debe ingresar un peso positivo", "Mensaje de error", MessageBoxButtons.OK);
            }


}

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            establecerComponentes(Estado.Inicial);
        }

        private void frmGestionarPesosPotencial_Load(object sender, EventArgs e)
        {

        }

        private void btnAtras_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }

        private void dgvCompetencias_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            if (e.ColumnIndex == 2) // 1 should be your column index
            {
                double i;
                String nuevo = Convert.ToString(e.FormattedValue);
                if (!Double.TryParse(nuevo, out i) ||
                    !(i >= 0))
                {
                    e.Cancel = true;
                    MessageBox.Show("Ingrese un número positivo como peso", "Peso Incorrecto", MessageBoxButtons.OK);
                }
                else
                {
                    // the input is numeric 
                }
            }
        }

        private void txtPeso_TextChanged(object sender, EventArgs e)
        {
            double num;
            try
            {
                num = Double.Parse(txtPeso.Text);
                if (num >= 0)
                {
                    txtPeso.ForeColor = Color.Black;
                }
                else
                    txtPeso.ForeColor = Color.Red;
            }
            catch (Exception ex)
            {
                txtPeso.ForeColor = Color.Red;
            }
        }
    }
}
