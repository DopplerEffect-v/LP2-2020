﻿using AmongJavas.CriterioWS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AmongJavas
{
    public partial class frmGestionarPotenciales : Form
    {

        private frmInicioSesion panelInicioSesion;
        private CriterioWS.CriterioWSClient daoCriterio;
        private SubCriterioWS.SubCriterioWSClient daoSubCriterio;
        private CriterioWS.criterio criterio;
        private Estado estado;
        private BindingList<CriterioWS.subCriterio> lista;
        private CriterioWS.subCriterio subcriterioSeleccionado;

        public BindingList<subCriterio> Lista { get => lista; set => lista = value; }
        public subCriterio SubcriterioSeleccionado { get => subcriterioSeleccionado; set => subcriterioSeleccionado = value; }

        public frmGestionarPotenciales(frmInicioSesion panelInicioSesion, Estado estado)
        {
            InitializeComponent();
            establecerComponentes(estado);
            this.panelInicioSesion = panelInicioSesion;
            this.estado = estado;
            daoCriterio = new CriterioWS.CriterioWSClient();
            daoSubCriterio = new SubCriterioWS.SubCriterioWSClient();
            criterio = new CriterioWS.criterio(); //Crea criterio nuevo vacio
            Lista = new BindingList<CriterioWS.subCriterio>();
            deshabilitaEtapa();
        }

        public frmGestionarPotenciales(frmInicioSesion panelInicioSesion, Estado estado, CriterioWS.criterio criterioTraido)
        {
            InitializeComponent();
            establecerComponentes(estado);

            criterio = criterioTraido;
            txtId.Text = criterio.id_criterio.ToString();
            txtNombre.Text = criterio.nombre;
            txtDescripcion.Text = criterio.descripcion;

            this.panelInicioSesion = panelInicioSesion;
            this.estado = estado;
            daoCriterio = new CriterioWS.CriterioWSClient();
            daoSubCriterio = new SubCriterioWS.SubCriterioWSClient();

            Lista = new BindingList<CriterioWS.subCriterio>();
            if (criterio.subcriterios != null)
            {
                BindingList<CriterioWS.subCriterio> listaReadOnly;
                listaReadOnly = new BindingList<CriterioWS.subCriterio>(criterio.subcriterios);
                foreach (CriterioWS.subCriterio s in listaReadOnly)
                {
                    s.accion = 3;
                    Lista.Add(s);
                }
            }
            deshabilitaEtapa();
            //Llena el grid
            llenarTabla();
        }

        public void deshabilitaEtapa()
        {
            if (Program.cronograma.etapa != 0)
            {
                btnBorrar.Visible = false;
                btnEditar.Visible = false;
                btnGuardar.Visible = false;
                btnCancelar.Visible = false;
                btnAnadir.Visible = false;
                btnEditar2.Text = "Ver";
                habilitaBoton(btnEditar2, true); 
            }
        }
        public void llenarTabla()
        {
            if (Lista != null)
            {
                dgvPotenciales.AutoGenerateColumns = false;
                dgvPotenciales.DataSource = new BindingList<CriterioWS.subCriterio>
                    (Lista);
            }
        }

        public void establecerComponentes(Estado estado)
        {
            switch (estado)
            {
                case Estado.Inicial:
                    txtId.Enabled = false;
                    txtNombre.Enabled = false;
                    txtDescripcion.Enabled = false;

                    habilitaBoton(btnEditar,true);
                    habilitaBoton(btnGuardar, false);
                    habilitaBoton(btnCancelar, false);

                    habilitaBoton(btnEditar2, false);
                    habilitaBoton(btnAnadir, false);
                    habilitaBoton(btnBorrar, false);
                    break;

                case Estado.Nuevo:
                    txtId.Enabled = false;
                    txtNombre.Enabled = true;
                    txtDescripcion.Enabled = true;

                    habilitaBoton(btnEditar, false);
                    habilitaBoton(btnGuardar,true);
                    habilitaBoton(btnCancelar, true);

                    habilitaBoton(btnEditar2, true);
                    habilitaBoton(btnAnadir, true);
                    habilitaBoton(btnBorrar, true);
                    break;

                case Estado.Actualizar:
                    txtId.Enabled = false;
                    txtNombre.Enabled = true;
                    txtDescripcion.Enabled = true;

                    habilitaBoton(btnEditar,false);
                    habilitaBoton(btnGuardar, true);
                    habilitaBoton(btnCancelar, true);

                    habilitaBoton(btnEditar2,true);
                    habilitaBoton(btnAnadir, true);
                    habilitaBoton(btnBorrar, true);
                    break;


            }
        }
        private void habilitaBoton(Button boton, bool estado)
        {
            boton.Enabled = estado;
            if (estado == true)
                boton.BackColor = Color.FromArgb(46, 44, 51);
            if (estado == false)
                boton.BackColor = Color.FromArgb(246, 245, 247);

        }
        private void btnEditar_Click(object sender, EventArgs e)
        {
            establecerComponentes(Estado.Actualizar);
        }

        public bool esCadenaEnBlanco(String cadena)
        {
            int i;
            for (i = 0; i < cadena.Length; i++)
                if (cadena[i] != ' ')
                    break;
            if (i == cadena.Length)
                return true;
            return false;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            //Verificacion
            if (!daoCriterio.validarCriterio(txtNombre.Text, Program.periodo.id_Periodo))
                MessageBox.Show("El potencial " + txtNombre.Text + " ya existe. Ingrese otro diferente", "Mensaje de error", MessageBoxButtons.OK);
            else if (txtNombre.Text == "")
                MessageBox.Show("Falta ingresar el Nombre del Potencial", "Mensaje de error", MessageBoxButtons.OK);
            else if (txtDescripcion.Text == "")
                MessageBox.Show("Falta ingresar la Descripcion del Potencial", "Mensaje de error", MessageBoxButtons.OK);
            else if (esCadenaEnBlanco(txtNombre.Text))
                MessageBox.Show("Nombre de potencial no puede ser cadena blanco", "Mensaje de error", MessageBoxButtons.OK);
            else if (esCadenaEnBlanco(txtDescripcion.Text))
                MessageBox.Show("Descripcion de potencial no puede ser cadena en blanco", "Mensaje de error", MessageBoxButtons.OK);
            else if (dgvPotenciales.RowCount == 0)
                MessageBox.Show("Falta ingresar algun subpotencial", "Mensaje de error", MessageBoxButtons.OK);
            else if (estado == Estado.Nuevo)
            {
                if (MessageBox.Show("¿Desea registrar el Potencial?", "Mensaje de confirmación", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    CriterioWS.tipoCriterio tipo = new CriterioWS.tipoCriterio();
                    tipo.id_tipo_criterio = 2;
                    criterio.tipo = tipo;
                    CriterioWS.periodo periodoTemp = new CriterioWS.periodo();
                    periodoTemp.id_Periodo = Program.periodo.id_Periodo;
                    criterio.periodo = periodoTemp;
                    criterio.nombre = txtNombre.Text;
                    criterio.descripcion = txtDescripcion.Text;
                    criterio.subcriterios = lista.ToArray();

                    daoCriterio.insertarCriterio(criterio);
                    MessageBox.Show("Potencial registrado", "Confirmación", MessageBoxButtons.OK);
                    this.DialogResult = DialogResult.OK;
                }
            }
            else
            {
                if (MessageBox.Show("¿Desea modificar el Potencial?", "Mensaje de confirmación", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    criterio.nombre = txtNombre.Text;
                    criterio.descripcion = txtDescripcion.Text;
                    criterio.subcriterios = lista.ToArray();

                    daoCriterio.actualizarCriterio(criterio);
                    MessageBox.Show("Potencial modificado", "Confirmación", MessageBoxButtons.OK);
                    this.DialogResult = DialogResult.OK;
                }

            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            establecerComponentes(Estado.Inicial);
        }

        private void btnAnadir_Click(object sender, EventArgs e)
        {
            frmOscuro pp = new frmOscuro();
            pp.SetBounds(0, 0, this.Width, this.Height);
            pp.Show();
            frmGestionarSubpotencial panelGestionarSubpotencial = new frmGestionarSubpotencial(Estado.Nuevo, this);
            if (panelGestionarSubpotencial.ShowDialog() == DialogResult.OK)
            {

            }
            llenarTabla();
            pp.Close();
        }

        private void btnEditar2_Click(object sender, EventArgs e)
        {
            subcriterioSeleccionado = (CriterioWS.subCriterio)dgvPotenciales.CurrentRow.DataBoundItem;
            frmOscuro pp = new frmOscuro();
            pp.SetBounds(0, 0, this.Width, this.Height);
            pp.Show();
            frmGestionarSubpotencial panelGestionarSubpotencial;
            if (Program.cronograma.etapa == 0)    //Planificacion
                panelGestionarSubpotencial = new frmGestionarSubpotencial(Estado.Actualizar, this);
            else
                panelGestionarSubpotencial = new frmGestionarSubpotencial(Estado.Revisar, this);
            if (panelGestionarSubpotencial.ShowDialog() == DialogResult.OK)
            {

            }
            llenarTabla();
            pp.Close();
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            subcriterioSeleccionado = (CriterioWS.subCriterio)dgvPotenciales.CurrentRow.DataBoundItem;
            if (MessageBox.Show("¿Desea eliminar el SubPotencial?", "Mensaje de confirmación", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                if (subcriterioSeleccionado.accion > 0)//No delete al INSERT
                {
                    SubCriterioWS.subCriterio subcri = new SubCriterioWS.subCriterio();
                    subcri.id_subcriterio = subcriterioSeleccionado.id_subcriterio;
                    daoSubCriterio.eliminarSubCriterio(subcri);
                }

                lista.Remove(subcriterioSeleccionado);
                llenarTabla();

                MessageBox.Show("Subpotencial eliminido", "Confirmación", MessageBoxButtons.OK);
            }
        }

        private void btnAtras_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
        }
    }
}
